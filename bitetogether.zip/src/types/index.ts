export interface Profile {
  id: string;
  name: string;
  studentId: string;
  email: string;
  hostelTower: 'Tower 3';
  roomNumber: string;
  avatarUrl?: string;
  phone?: string;
  createdAt: string;
}

export type OrderStatus =
  | 'collecting'       // Collecting food items from group
  | 'threshold_met'    // ₹300 minimum reached, checkout unlocked
  | 'checkout_locked'  // Cart frozen while participants pay
  | 'paid'             // All active participants have paid
  | 'placed'           // Order dispatched to Grains & Gossip cafe
  | 'preparing'        // Kitchen is preparing food
  | 'ready_pickup'     // Food arrived at Tower 3 reception
  | 'completed';       // Order fulfilled

export interface GroupOrder {
  id: string;
  code: string; // e.g. T3-9281
  name: string; // e.g. "Floor 3 Late Night Bites"
  cafeName: 'Grains and Gossip';
  creatorId: string;
  creatorName: string;
  creatorRoom: string;
  deadline: string; // ISO string
  participantLimit?: number;
  status: OrderStatus;
  minThreshold: number; // ₹300 fixed
  totalAmount: number;
  pickupPoint: string; // e.g. "Tower 3 Ground Security Desk"
  createdAt: string;
  lockedAt?: string;
  cafeTokenNumber?: string; // e.g. "GG-3091"
  estimatedDeliveryMins?: number;
}

export interface GroupParticipant {
  id: string;
  groupId: string;
  userId: string;
  userName: string;
  roomNumber: string;
  avatarUrl?: string;
  joinedAt: string;
  paymentStatus: 'pending' | 'processing' | 'paid' | 'failed';
  totalIndividualAmount: number;
}

export interface MenuItem {
  id: string;
  name: string;
  category: 'rice_noodles' | 'burgers' | 'sandwiches' | 'pizza' | 'starters_sides' | 'pasta' | 'beverages' | 'desserts' | string;
  subCategory?: string; // e.g. "Veg Starter", "Non Veg Starter", "Rice / Noodles", "Fresh Juicy Joy", "Pick-Me-Up"
  description: string;
  price: number; // in INR
  isVeg: boolean;
  spicyLevel?: 0 | 1 | 2 | 3;
  imageUrl: string;
  available: boolean;
  preparationTimeMins: number;
  tags?: string[];
}

export interface CartItem {
  id: string;
  groupId: string;
  userId: string;
  userName: string;
  roomNumber: string;
  menuItemId: string;
  itemName: string;
  price: number;
  quantity: number;
  specialInstructions?: string;
  addedAt: string;
}

export interface Payment {
  id: string;
  groupId: string;
  userId: string;
  userName: string;
  amount: number;
  paymentMethod: 'upi' | 'qr' | 'razorpay_demo';
  status: 'pending' | 'processing' | 'paid' | 'failed';
  transactionRef?: string;
  upiId?: string;
  paidAt?: string;
  failureReason?: string;
}

export interface Notification {
  id: string;
  userId: string;
  groupId?: string;
  title: string;
  message: string;
  type: 'group_joined' | 'food_added' | 'threshold_reached' | 'payment_pending' | 'order_placed' | 'food_ready' | 'info';
  isRead: boolean;
  createdAt: string;
}

export interface OrderStatusHistory {
  id: string;
  groupId: string;
  status: OrderStatus;
  note: string;
  timestamp: string;
}
