import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { OrderStatus } from '../types';
import {
  CheckCircle2,
  Clock,
  MapPin,
  UtensilsCrossed,
  PackageCheck,
  AlertCircle,
  Play,
  RotateCcw,
  Sparkles,
  Users
} from 'lucide-react';

export const OrderTrackerView: React.FC = () => {
  const {
    activeGroup,
    groups,
    setActiveGroupId,
    statusHistory,
    activeGroupCartItems,
    activeGroupParticipants,
    progressOrderStatus,
    setCurrentTab
  } = useApp();

  const [isSimulating, setIsSimulating] = useState(false);

  // If no active group or selected group is in early collecting stage, allow picking another or active
  const order = activeGroup;

  const steps: { key: OrderStatus; label: string; desc: string }[] = [
    { key: 'collecting', label: 'Collecting Orders', desc: 'Roommates adding food items' },
    { key: 'threshold_met', label: 'Minimum ₹300 Reached', desc: 'Grains & Gossip threshold achieved' },
    { key: 'checkout_locked', label: 'Cart Frozen', desc: 'Individual payments in progress' },
    { key: 'paid', label: 'Payments Completed', desc: 'All roommate shares paid via UPI/QR' },
    { key: 'placed', label: 'Order Dispatched', desc: 'Transmitted to Grains & Gossip cafe' },
    { key: 'preparing', label: 'Kitchen Preparing', desc: 'Grilling burgers & baking paninis' },
    { key: 'ready_pickup', label: 'Ready for Pickup', desc: 'Arrived at Tower 3 Security Desk' },
    { key: 'completed', label: 'Delivered & Enjoyed', desc: 'Food collected by roommates' }
  ];

  const getStepIndex = (status: OrderStatus) => {
    return steps.findIndex(s => s.key === status);
  };

  const currentStepIndex = order ? getStepIndex(order.status) : 0;

  const handleSimulateNextStep = async () => {
    if (!order) return;
    setIsSimulating(true);

    const progression: Record<OrderStatus, OrderStatus> = {
      collecting: 'threshold_met',
      threshold_met: 'checkout_locked',
      checkout_locked: 'paid',
      paid: 'placed',
      placed: 'preparing',
      preparing: 'ready_pickup',
      ready_pickup: 'completed',
      completed: 'completed'
    };

    const next = progression[order.status];
    if (next && next !== order.status) {
      await progressOrderStatus(next);
    }
    setIsSimulating(false);
  };

  if (!order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <h2 className="font-heading text-xl font-bold text-[#202020]">No Active Order Selected</h2>
        <p className="text-xs text-[#202020]/60 mt-1 mb-4">
          Select an active group order from Tower 3 to track its real-time preparation status.
        </p>
        <button
          onClick={() => setCurrentTab('groups')}
          className="px-4 py-2 bg-[#FF7A1A] text-white rounded-lg text-xs font-semibold"
        >
          View Tower 3 Groups
        </button>
      </div>
    );
  }

  const groupHistory = statusHistory.filter(h => h.groupId === order.id);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      
      {/* Tracker Hero Card */}
      <div className="bg-white rounded-2xl border border-[#202020]/10 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#202020]/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
              <span>Live Order Tracker</span>
              <span className="text-[#202020]/30">·</span>
              <span className="font-mono">{order.code}</span>
            </div>
            <h1 className="font-heading text-2xl font-extrabold text-[#202020] mt-0.5">
              {order.name}
            </h1>
            <p className="text-xs text-[#202020]/60 mt-0.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#FF7A1A]" />
              Pickup: <strong className="text-[#202020]">{order.pickupPoint}</strong>
            </p>
          </div>

          {/* Cafe Token */}
          <div className="bg-[#FFF9F3] border border-[#202020]/10 rounded-xl p-3 text-right">
            <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block">
              Grains &amp; Gossip Token
            </span>
            <span className="font-mono font-bold text-lg text-[#FF7A1A] block">
              #{order.cafeTokenNumber || 'PENDING'}
            </span>
            <span className="text-[11px] text-[#202020]/60">
              Est: {order.estimatedDeliveryMins || 25} mins
            </span>
          </div>
        </div>

        {/* Interactive Testing Simulation Control */}
        <div className="my-4 p-3 bg-amber-50 border border-amber-200 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
          <div>
            <span className="font-semibold text-amber-900">Prototype Demo Controls:</span>
            <span className="text-amber-800 ml-1">
              Advance through late-night kitchen &amp; delivery stages
            </span>
          </div>
          <button
            onClick={handleSimulateNextStep}
            disabled={isSimulating || order.status === 'completed'}
            className="px-3 py-1.5 bg-[#202020] hover:bg-[#333] text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 shadow-2xs disabled:opacity-50"
          >
            <Play className="w-3 h-3 text-[#FF7A1A]" />
            <span>Simulate Next Cafe Step</span>
          </button>
        </div>

        {/* 7-Step Progress Timeline */}
        <div className="py-6">
          <div className="space-y-4">
            {steps.map((step, idx) => {
              const isPast = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              const isUpcoming = idx > currentStepIndex;

              return (
                <div key={step.key} className="flex items-start gap-3.5 relative">
                  {/* Connector Line */}
                  {idx < steps.length - 1 && (
                    <div
                      className={`absolute left-3.5 top-8 w-0.5 h-8 -ml-[1px] transition-colors ${
                        isPast ? 'bg-[#10B981]' : 'bg-[#202020]/10'
                      }`}
                    />
                  )}

                  {/* Step Dot */}
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-bold transition-all ${
                      isPast
                        ? 'bg-[#10B981] text-white'
                        : isCurrent
                        ? 'bg-[#FF7A1A] text-white ring-4 ring-[#FF7A1A]/20 scale-105'
                        : 'bg-[#202020]/10 text-[#202020]/40'
                    }`}
                  >
                    {isPast ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                  </div>

                  {/* Step Details */}
                  <div className="flex-1 pb-4">
                    <div className="flex items-center gap-2">
                      <h4
                        className={`font-heading font-semibold text-sm ${
                          isCurrent
                            ? 'text-[#FF7A1A]'
                            : isPast
                            ? 'text-[#202020]'
                            : 'text-[#202020]/40'
                        }`}
                      >
                        {step.label}
                      </h4>
                      {isCurrent && (
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#FF7A1A] bg-[#FF7A1A]/10 px-2 py-0.5 rounded">
                          Current Stage
                        </span>
                      )}
                    </div>
                    <p
                      className={`text-xs mt-0.5 ${
                        isCurrent || isPast ? 'text-[#202020]/70' : 'text-[#202020]/40'
                      }`}
                    >
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order Details & Roommate Breakdown */}
        <div className="mt-6 pt-5 border-t border-[#202020]/10 grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Items Summary */}
          <div className="p-4 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl space-y-2 text-xs">
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-[#202020]">
              Food In This Order ({activeGroupCartItems.length} items)
            </h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {activeGroupCartItems.map(item => (
                <div key={item.id} className="flex justify-between items-center text-xs">
                  <div>
                    <span className="font-medium text-[#202020]">{item.itemName}</span>
                    <span className="text-[#202020]/50 ml-1">×{item.quantity}</span>
                    <span className="text-[#202020]/40 text-[10px] block">
                      For: {item.userName} (Rm {item.roomNumber})
                    </span>
                  </div>
                  <span className="font-mono tabular-nums font-semibold text-[#202020]">
                    ₹{item.price * item.quantity}
                  </span>
                </div>
              ))}
            </div>
            <div className="pt-2 border-t border-[#202020]/10 flex justify-between font-bold text-xs text-[#202020]">
              <span>Combined Total</span>
              <span className="font-mono text-[#FF7A1A]">₹{order.totalAmount}</span>
            </div>
          </div>

          {/* Live Activity Log */}
          <div className="p-4 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl space-y-2 text-xs">
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-[#202020]">
              Real-Time Log
            </h4>
            <div className="space-y-2 max-h-48 overflow-y-auto text-[11px]">
              {groupHistory.length === 0 ? (
                <div className="text-[#202020]/50 italic">No events logged yet.</div>
              ) : (
                groupHistory.map(h => (
                  <div key={h.id} className="border-l-2 border-[#FF7A1A] pl-2.5 py-0.5">
                    <p className="text-[#202020] font-medium">{h.note}</p>
                    <span className="text-[10px] text-[#202020]/50 font-mono">
                      {new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
