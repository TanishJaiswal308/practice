import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GroupCard } from './GroupCard';
import {
  Users,
  PlusCircle,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  ShoppingBag,
  Clock,
  CheckCircle2,
  Lock,
  Search,
  KeyRound,
  UtensilsCrossed,
  Flame,
  Star
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const {
    groups,
    setIsCreateGroupOpen,
    joinGroup,
    setIsCartOpen,
    setCurrentTab,
    menuItems,
    addToCart,
    activeGroup
  } = useApp();

  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [joinError, setJoinError] = useState<string | null>(null);

  const activeGroups = groups.filter(g => g.status !== 'completed');
  
  // Pick 3 top highlights from the exact menu (Juicy Cheese Burger, Margaritta Pizza, Burned Chilly Garlic Fried Rice)
  const featuredDishes = [
    menuItems.find(m => m.id === 'gg-bg-2') || menuItems[0],
    menuItems.find(m => m.id === 'gg-pz-2') || menuItems[1],
    menuItems.find(m => m.id === 'gg-rn-1') || menuItems[2]
  ];

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setJoinError(null);
    const cleaned = joinCodeInput.trim().toUpperCase();
    const match = groups.find(g => g.code.toUpperCase() === cleaned);
    if (!match) {
      setJoinError(`No active Tower 3 order found for code "${cleaned}". Check with your roommate!`);
      return;
    }
    const res = await joinGroup(match.id);
    if (res.success) {
      setCurrentTab('menu');
      setJoinCodeInput('');
    } else {
      setJoinError(res.message);
    }
  };

  return (
    <div className="space-y-14 pb-20">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-white via-[#FFF9F3] to-[#FFF4E8] border-b border-[#202020]/10 pt-6 pb-14 sm:py-16">
        
        {/* Ambient background decorative glow circles */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#FF7A1A]/10 rounded-full blur-3xl pointer-events-none -z-0" />
        <div className="absolute bottom-0 left-10 w-72 h-72 bg-amber-200/20 rounded-full blur-2xl pointer-events-none -z-0" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
          
          {/* Left Hero Content */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/90 border border-[#FF7A1A]/20 shadow-xs text-xs font-semibold text-[#FF7A1A]">
              <span className="w-2 h-2 rounded-full bg-[#FF7A1A] animate-ping" />
              <span>Hostel Mess Closed at 9 PM</span>
              <span className="text-[#202020]/25">·</span>
              <span className="text-[#202020]/80">Tower 3 Late-Night Solution</span>
            </div>

            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-black text-[#202020] tracking-tight leading-[1.08]">
              Don&apos;t order alone. <br />
              <span className="bg-gradient-to-r from-[#FF7A1A] via-[#FF5500] to-[#E04400] bg-clip-text text-transparent">
                Bite together.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#202020]/75 max-w-xl leading-relaxed">
              Grains &amp; Gossip requires a ₹300 minimum order. Don&apos;t spend ₹300 when you only crave a ₹99 toastie or ₹89 cold brew. Pool with Tower 3 roommates into one shared cart and pay <strong className="text-[#202020] font-bold">strictly for your own food</strong>.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setIsCreateGroupOpen(true)}
                className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] hover:brightness-105 active:scale-95 text-white font-heading font-extrabold text-sm transition-all shadow-[0_4px_20px_rgba(255,122,26,0.35)] flex items-center gap-2 ring-2 ring-[#FF7A1A]/30"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Start a Group Order</span>
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('active-groups-section');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-6 py-3.5 rounded-2xl bg-[#202020] hover:bg-[#333] active:scale-95 text-white font-heading font-bold text-sm transition-all shadow-md flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                <span>Join An Existing Order</span>
              </button>
            </div>

            {/* Trust Bullet Grid (Unboxed clean text per §1.A) */}
            <div className="pt-4 border-t border-[#202020]/10 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-[#202020]/70 font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
                <span>No equal-split penalty</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
                <span>Fixed Grains &amp; Gossip</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
                <span>Delivered to Tower 3 Gate</span>
              </div>
            </div>

          </div>

          {/* Right Hero Visual Card with High-Impact Badges */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden border border-[#202020]/15 shadow-2xl bg-[#202020]/5 aspect-[4/3] group">
              <img
                src="/src/assets/images/hero_cafe_spread_1793732218121.jpg"
                alt="Grains & Gossip Late-Night Cafe Feast"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent flex flex-col justify-end p-6 text-white">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#FF7A1A] bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                    Grains &amp; Gossip Kitchen
                  </span>
                  <span className="text-xs text-amber-300 flex items-center gap-1 font-semibold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" /> 4.9 (1.2k+ reviews)
                  </span>
                </div>
                <div className="font-heading text-xl sm:text-2xl font-black">
                  Late-Night Campus Cafe Spread
                </div>
                <div className="text-xs text-white/80 mt-1 flex items-center gap-2">
                  <span>Minimum Cart: ₹300</span>
                  <span>·</span>
                  <span>Average roommate share: ₹110</span>
                </div>
              </div>
            </div>

            {/* Floating Live Metric Card */}
            <div className="absolute -bottom-4 -left-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-[#202020]/10 shadow-[0_10px_25px_rgba(0,0,0,0.1)] text-xs flex items-center gap-3 animate-fade-in">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FF7A1A] to-[#E04400] text-white flex items-center justify-center font-bold text-sm shadow-sm">
                ₹300
              </div>
              <div>
                <div className="font-bold text-[#202020]">Group Cart Threshold</div>
                <div className="text-[11px] text-[#10B981] font-semibold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Unlocked in 4 mins avg
                </div>
              </div>
            </div>

            {/* Floating Top Right Tag */}
            <div className="absolute -top-3 -right-3 bg-[#202020] text-white px-3 py-1.5 rounded-xl border border-white/20 shadow-lg text-[11px] font-bold flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-[#FF7A1A]" />
              <span>Tower 3 Exclusive</span>
            </div>
          </div>

        </div>
      </section>

      {/* Active Groups & Join by Code Section */}
      <section id="active-groups-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#FF7A1A] uppercase tracking-wider">
              <Users className="w-3.5 h-3.5" />
              <span>Tower 3 Shared Lobby</span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-black text-[#202020] mt-0.5">
              Active Hostel Group Orders
            </h2>
            <p className="text-xs sm:text-sm text-[#202020]/65 mt-1">
              Join your floor roommates or wings to hit the ₹300 threshold before the cafe timer expires.
            </p>
          </div>

          {/* Quick Join by Code Form */}
          <form onSubmit={handleJoinByCode} className="flex gap-2">
            <div className="relative">
              <KeyRound className="w-3.5 h-3.5 text-[#202020]/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Enter Code (e.g. T3-MUNCH)"
                value={joinCodeInput}
                onChange={e => setJoinCodeInput(e.target.value)}
                className="pl-9 pr-3 py-2 text-xs bg-white border border-[#202020]/15 rounded-xl focus:outline-none focus:border-[#FF7A1A] font-mono uppercase w-52 sm:w-64 shadow-2xs font-semibold"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-[#202020] hover:bg-[#333] text-white text-xs font-bold rounded-xl transition-all whitespace-nowrap shadow-xs"
            >
              Join Group
            </button>
          </form>
        </div>

        {joinError && (
          <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-medium">
            {joinError}
          </div>
        )}

        {/* Groups Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeGroups.map(group => (
            <GroupCard key={group.id} group={group} />
          ))}

          {/* Quick Create Group Prompt Card */}
          <div
            onClick={() => setIsCreateGroupOpen(true)}
            className="border-2 border-dashed border-[#202020]/20 hover:border-[#FF7A1A] rounded-3xl p-6 flex flex-col items-center justify-center text-center cursor-pointer bg-white/60 hover:bg-white transition-all group min-h-[220px] shadow-2xs hover:shadow-md hover:-translate-y-1"
          >
            <div className="w-14 h-14 rounded-2xl bg-[#FF7A1A]/10 text-[#FF7A1A] group-hover:bg-[#FF7A1A] group-hover:text-white flex items-center justify-center transition-all mb-3 shadow-xs group-hover:scale-105">
              <PlusCircle className="w-7 h-7" />
            </div>
            <h3 className="font-heading font-black text-lg text-[#202020]">
              Start Your Own Group Order
            </h3>
            <p className="text-xs text-[#202020]/65 max-w-xs mt-1 mb-3">
              Order from Grains &amp; Gossip and invite your Tower 3 roommates to pitch in.
            </p>
            <span className="text-xs font-bold text-[#FF7A1A] group-hover:underline flex items-center gap-1">
              Create in 30 Seconds →
            </span>
          </div>
        </div>

      </section>

      {/* How It Works (Crystal Clear 3-Step Math & Flow) */}
      <section className="bg-white border-y border-[#202020]/10 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-bold text-[#FF7A1A] uppercase tracking-wider">
              The Problem &amp; The Fix
            </span>
            <h2 className="font-heading text-3xl font-black text-[#202020] mt-1">
              How BiteTogether Solves The ₹300 Dilemma
            </h2>
            <p className="text-xs sm:text-sm text-[#202020]/65 mt-1">
              Never pay for an entire ₹300 minimum cart when you just want a quick ₹99 study snack.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="p-6 bg-[#FFF9F3] border border-[#202020]/10 rounded-3xl space-y-3 relative hover:shadow-sm transition-all">
              <div className="w-10 h-10 rounded-2xl bg-[#202020] text-white flex items-center justify-center font-bold text-sm font-mono shadow-xs">
                01
              </div>
              <h3 className="font-heading font-extrabold text-lg text-[#202020]">
                One Shared Cart
              </h3>
              <p className="text-xs text-[#202020]/70 leading-relaxed">
                Tower 3 roommates add food items to a single shared cart for Grains &amp; Gossip. No need to order ₹300 alone.
              </p>
            </div>

            <div className="p-6 bg-[#FFF9F3] border border-[#FF7A1A]/30 rounded-3xl space-y-3 relative shadow-xs hover:shadow-md transition-all ring-1 ring-[#FF7A1A]/10">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] text-white flex items-center justify-center font-bold text-sm font-mono shadow-xs">
                02
              </div>
              <h3 className="font-heading font-extrabold text-lg text-[#202020]">
                ₹300 Unlocks Checkout
              </h3>
              <p className="text-xs text-[#202020]/70 leading-relaxed">
                As soon as the combined total hits ₹300, checkout unlocks! The server freezes the cart so nobody can tamper with items while you pay.
              </p>
            </div>

            <div className="p-6 bg-[#FFF9F3] border border-[#202020]/10 rounded-3xl space-y-3 relative hover:shadow-sm transition-all">
              <div className="w-10 h-10 rounded-2xl bg-[#202020] text-white flex items-center justify-center font-bold text-sm font-mono shadow-xs">
                03
              </div>
              <h3 className="font-heading font-extrabold text-lg text-[#202020]">
                Pay For Your Food Only
              </h3>
              <p className="text-xs text-[#202020]/70 leading-relaxed">
                If you ordered a ₹99 toastie, you pay exactly ₹99 via UPI. No messy split calculations or IOUs between roommates.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* Featured Late-Night Food Highlights with mouth-watering photography */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-[#FF7A1A] uppercase tracking-wider">
              Hostel Favorites
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-black text-[#202020]">
              Tonight&apos;s Late-Night Fuel
            </h2>
          </div>
          <button
            onClick={() => setCurrentTab('menu')}
            className="text-xs font-bold text-[#FF7A1A] hover:underline flex items-center gap-1"
          >
            <span>See Full Menu ({menuItems.length} items)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredDishes.map(dish => (
            <div
              key={dish.id}
              className="bg-white rounded-3xl border border-[#202020]/10 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
            >
              <div className="h-52 w-full bg-[#202020]/5 overflow-hidden relative">
                <img
                  src={dish.imageUrl}
                  alt={dish.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/65 text-white text-[10px] font-bold backdrop-blur-xs uppercase tracking-wider">
                  {dish.category}
                </div>
                <div className="absolute bottom-3 right-3 px-2.5 py-0.5 rounded-md bg-black/65 text-white text-[11px] font-mono font-bold backdrop-blur-xs flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#FF7A1A]" />
                  <span>{dish.preparationTimeMins} mins</span>
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-heading font-extrabold text-base sm:text-lg text-[#202020] group-hover:text-[#FF7A1A] transition-colors">
                      {dish.name}
                    </h3>
                    <span className="font-mono tabular-nums font-extrabold text-base text-[#202020] shrink-0">
                      ₹{dish.price}
                    </span>
                  </div>
                  <p className="text-xs text-[#202020]/65 mt-1.5 line-clamp-2 leading-relaxed">
                    {dish.description}
                  </p>
                </div>

                <div className="mt-5 pt-3.5 border-t border-[#202020]/5 flex items-center justify-between">
                  <span className="text-[11px] text-[#202020]/50 font-medium">
                    Grains &amp; Gossip Special
                  </span>
                  <button
                    onClick={() => {
                      addToCart(dish.id, 1);
                      setIsCartOpen(true);
                    }}
                    className="px-4 py-2 bg-[#FF7A1A] hover:bg-[#e86b12] text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 shadow-xs hover:shadow-md active:scale-95"
                  >
                    <span>Add to Group Cart</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
