import React from 'react';
import { GroupOrder } from '../types';
import { useApp } from '../context/AppContext';
import {
  Users,
  Clock,
  ArrowRight,
  Lock,
  Unlock,
  CheckCircle2,
  Share2,
  ShoppingBag,
  Sparkles
} from 'lucide-react';

interface GroupCardProps {
  group: GroupOrder;
}

export const GroupCard: React.FC<GroupCardProps> = ({ group }) => {
  const {
    currentUser,
    activeGroupId,
    setActiveGroupId,
    setIsCartOpen,
    joinGroup,
    setCurrentTab,
    participants
  } = useApp();

  const isSelected = activeGroupId === group.id;
  const isCreator = group.creatorId === currentUser.id;
  const total = group.totalAmount;
  const threshold = group.minThreshold || 300;
  const progressPercent = Math.min(100, Math.round((total / threshold) * 100));
  const remaining = Math.max(0, threshold - total);
  const isUnlocked = total >= threshold;

  // Deadline countdown estimate
  const deadlineDate = new Date(group.deadline);
  const diffMinutes = Math.max(0, Math.round((deadlineDate.getTime() - Date.now()) / (60 * 1000)));

  // Group participants avatars
  const groupParts = participants.filter(p => p.groupId === group.id);

  const handleSelectAndExplore = async () => {
    setActiveGroupId(group.id);
    await joinGroup(group.id);
  };

  const handleOpenCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveGroupId(group.id);
    setIsCartOpen(true);
  };

  return (
    <div
      onClick={handleSelectAndExplore}
      className={`bg-white rounded-3xl border p-5 sm:p-6 transition-all duration-300 cursor-pointer relative flex flex-col justify-between group hover:-translate-y-1 ${
        isSelected
          ? 'border-[#FF7A1A] ring-2 ring-[#FF7A1A]/20 shadow-[0_10px_30px_rgba(255,122,26,0.12)]'
          : isUnlocked
          ? 'border-emerald-300/80 hover:border-emerald-400 shadow-sm hover:shadow-md'
          : 'border-[#202020]/10 hover:border-[#FF7A1A]/40 shadow-xs hover:shadow-md'
      }`}
    >
      <div>
        {/* Top Kicker & Code */}
        <div className="flex items-center justify-between text-xs text-[#202020]/60 mb-2">
          <div className="flex items-center gap-1.5">
            <span className="font-mono font-extrabold text-[#FF7A1A] bg-[#FF7A1A]/10 px-2 py-0.5 rounded-md">
              {group.code}
            </span>
            <span aria-hidden="true" className="text-[#202020]/30">·</span>
            <span className="font-medium text-[#202020]/75">Grains &amp; Gossip</span>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#202020]/75 bg-[#FFF9F3] px-2.5 py-1 rounded-full border border-[#202020]/5">
            <Clock className="w-3.5 h-3.5 text-[#FF7A1A]" />
            <span>{diffMinutes > 0 ? `${diffMinutes}m remaining` : 'Closing soon'}</span>
          </div>
        </div>

        {/* Group Name */}
        <h3 className="font-heading font-extrabold text-lg text-[#202020] leading-snug group-hover:text-[#FF7A1A] transition-colors">
          {group.name}
        </h3>

        {/* Creator & Room Unboxed Metadata */}
        <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-xs text-[#202020]/65">
          <span>Host: <strong className="text-[#202020]">{group.creatorName}</strong></span>
          <span aria-hidden="true" className="text-[#202020]/30">·</span>
          <span>Room {group.creatorRoom} (Tower 3)</span>
          {isCreator && (
            <>
              <span aria-hidden="true" className="text-[#202020]/30">·</span>
              <span className="text-[#FF7A1A] font-bold">Your Group</span>
            </>
          )}
        </div>

        {/* ₹300 Rule Progress Meter */}
        <div className={`mt-4 p-3.5 rounded-2xl border transition-all ${
          isUnlocked 
            ? 'bg-emerald-50/70 border-emerald-200' 
            : 'bg-[#FFF9F3] border-[#202020]/10'
        }`}>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-[#202020] flex items-center gap-1.5">
              {isUnlocked ? (
                <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                  <Unlock className="w-3 h-3" />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full bg-[#FF7A1A]/15 text-[#FF7A1A] flex items-center justify-center">
                  <Lock className="w-3 h-3" />
                </div>
              )}
              <span>{isUnlocked ? 'Goal Reached!' : '₹300 Minimum Cart'}</span>
            </span>
            <span className="font-mono tabular-nums font-bold text-sm text-[#202020]">
              ₹{total} <span className="text-xs font-normal text-[#202020]/50">/ ₹300</span>
            </span>
          </div>

          {/* Animated Glowing Progress Bar */}
          <div className="w-full h-2.5 bg-[#202020]/10 rounded-full overflow-hidden relative">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                isUnlocked 
                  ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' 
                  : 'bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] animate-shimmer'
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="mt-2 flex items-center justify-between text-[11px]">
            {isUnlocked ? (
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                Checkout unlocked for all roommates
              </span>
            ) : (
              <span className="text-[#202020]/75">
                Add <strong className="text-[#FF7A1A] font-mono">₹{remaining}</strong> more to place order
              </span>
            )}
            <span className="text-[#202020]/60 font-mono font-bold">{progressPercent}%</span>
          </div>
        </div>
      </div>

      {/* Footer Action Strip */}
      <div className="mt-5 pt-3.5 border-t border-[#202020]/5 flex items-center justify-between gap-2">
        {/* Roommate Avatars Stack */}
        <div className="flex items-center gap-1.5">
          <div className="flex -space-x-2">
            {groupParts.slice(0, 3).map((p, idx) => (
              <div
                key={p.userId}
                className="w-6 h-6 rounded-full bg-gradient-to-br from-[#FF7A1A] to-[#E04400] text-white border-2 border-white flex items-center justify-center text-[10px] font-bold shadow-xs"
                title={`${p.userName} (Room ${p.roomNumber})`}
              >
                {p.userName.charAt(0)}
              </div>
            ))}
          </div>
          <span className="text-[11px] text-[#202020]/60 font-medium">
            {groupParts.length} in cart
          </span>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenCart}
            className="px-2.5 py-1.5 text-xs font-semibold bg-[#FFF9F3] hover:bg-[#202020]/5 border border-[#202020]/10 rounded-xl text-[#202020] transition-colors flex items-center gap-1"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#FF7A1A]" />
            <span>Cart</span>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleSelectAndExplore();
              setCurrentTab('menu');
            }}
            className="px-3.5 py-1.5 text-xs font-bold bg-[#FF7A1A] hover:bg-[#e86b12] text-white rounded-xl transition-all shadow-sm flex items-center gap-1 group-hover:shadow-[0_4px_12px_rgba(255,122,26,0.3)]"
          >
            <span>Add Food</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
