import React, { useState, useEffect } from 'react';
import { Moon, Sparkles, CheckCircle2, Flame, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LateNightBanner: React.FC = () => {
  const { activeGroup } = useApp();
  const [timeRemaining, setTimeRemaining] = useState<string>('24m 15s');

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const mins = 59 - now.getMinutes();
      const secs = 59 - now.getSeconds();
      setTimeRemaining(`${mins}m ${secs.toString().padStart(2, '0')}s`);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const total = activeGroup ? activeGroup.totalAmount : 0;
  const needed = Math.max(0, 300 - total);
  const isUnlocked = total >= 300;

  return (
    <div className="bg-gradient-to-r from-[#181818] via-[#241E1A] to-[#181818] text-white py-3 px-4 border-b border-white/10 shadow-xs relative overflow-hidden">
      
      {/* Subtle top edge glow */}
      <div className="absolute top-0 left-1/3 w-96 h-1 bg-gradient-to-r from-transparent via-[#FF7A1A]/40 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs sm:text-sm">
        
        {/* Left: Mess Closure & Cafe Context */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#FF7A1A]/30 to-[#FF5500]/20 text-[#FF7A1A] border border-[#FF7A1A]/30 flex items-center justify-center shrink-0 shadow-xs">
            <Moon className="w-4 h-4" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2 font-medium">
              <span className="text-white/80">Hostel Mess Closed (9:00 PM)</span>
              <span className="text-white/30 hidden xs:inline">·</span>
              <span className="text-[#FF7A1A] font-bold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-[#FF7A1A]" />
                Grains &amp; Gossip Late-Night Kitchen Active
              </span>
            </div>
            <p className="text-xs text-white/60 hidden sm:block mt-0.5">
              Solo ordering requires ₹300 minimum cart. Pool with Tower 3 roommates to order your ₹80–₹150 snack!
            </p>
          </div>
        </div>

        {/* Right: Live ₹300 Status */}
        {activeGroup && (
          <div className="flex items-center gap-3 shrink-0 self-end md:self-auto bg-white/10 backdrop-blur-md border border-white/15 px-3.5 py-1.5 rounded-xl shadow-xs">
            <div className="text-right">
              <div className="text-[11px] text-white/60 font-medium">
                {activeGroup.name} (Code: <span className="font-mono text-[#FFA14A] font-bold">{activeGroup.code}</span>)
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="font-mono tabular-nums font-black text-sm text-white">
                  ₹{total}
                </span>
                <span className="text-xs text-white/50 font-mono">/ ₹300</span>
                {isUnlocked ? (
                  <span className="text-emerald-400 font-bold flex items-center gap-1 text-xs">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Unlocked
                  </span>
                ) : (
                  <span className="text-[#FF7A1A] font-bold text-xs">
                    ₹{needed} remaining
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
