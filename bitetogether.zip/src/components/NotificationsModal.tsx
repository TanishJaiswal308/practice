import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Bell,
  CheckCircle2,
  Clock,
  Sparkles,
  ShoppingBag,
  CreditCard,
  UtensilsCrossed
} from 'lucide-react';

export const NotificationsModal: React.FC = () => {
  const {
    isNotificationsOpen,
    setIsNotificationsOpen,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    currentUser,
    setActiveGroupId,
    setIsCartOpen,
    setCurrentTab
  } = useApp();

  if (!isNotificationsOpen) return null;

  const userNotifs = notifications.filter(n => n.userId === currentUser.id);

  const getIcon = (type: string) => {
    switch (type) {
      case 'threshold_reached':
        return <Sparkles className="w-4 h-4 text-[#FF7A1A]" />;
      case 'group_joined':
        return <CheckCircle2 className="w-4 h-4 text-[#10B981]" />;
      case 'food_added':
        return <ShoppingBag className="w-4 h-4 text-[#FF7A1A]" />;
      case 'payment_pending':
        return <CreditCard className="w-4 h-4 text-amber-500" />;
      case 'order_placed':
      case 'food_ready':
        return <UtensilsCrossed className="w-4 h-4 text-emerald-600" />;
      default:
        return <Bell className="w-4 h-4 text-[#202020]/60" />;
    }
  };

  const handleClickNotif = (notif: any) => {
    markNotificationRead(notif.id);
    if (notif.groupId) {
      setActiveGroupId(notif.groupId);
      if (notif.type === 'food_ready' || notif.type === 'order_placed') {
        setCurrentTab('tracking');
      } else {
        setIsCartOpen(true);
      }
      setIsNotificationsOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#202020]/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FFF9F3] rounded-2xl max-w-md w-full border border-[#202020]/10 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#202020]/10 bg-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#FF7A1A]" />
            <h2 className="font-heading text-lg font-bold text-[#202020]">
              Notifications
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={markAllNotificationsRead}
              className="text-xs text-[#FF7A1A] hover:underline font-semibold"
            >
              Mark all read
            </button>
            <button
              onClick={() => setIsNotificationsOpen(false)}
              className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-lg transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {userNotifs.length === 0 ? (
            <div className="text-center py-10 text-xs text-[#202020]/50">
              No notifications yet for {currentUser.name}.
            </div>
          ) : (
            userNotifs.map(n => (
              <div
                key={n.id}
                onClick={() => handleClickNotif(n)}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex items-start gap-3 ${
                  n.isRead
                    ? 'bg-white/70 border-[#202020]/5 opacity-80 hover:bg-white'
                    : 'bg-white border-[#FF7A1A]/30 shadow-2xs ring-1 ring-[#FF7A1A]/10'
                }`}
              >
                <div className="mt-0.5 p-1.5 rounded-lg bg-[#FFF9F3] border border-[#202020]/10 shrink-0">
                  {getIcon(n.type)}
                </div>
                <div className="flex-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#202020]">{n.title}</span>
                    <span className="text-[10px] text-[#202020]/40 font-mono">
                      {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[#202020]/70 mt-0.5 leading-relaxed">{n.message}</p>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
