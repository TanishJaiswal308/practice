import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  ShieldCheck,
  Building,
  User,
  Mail,
  KeyRound,
  Check,
  AlertTriangle,
  ArrowRight
} from 'lucide-react';

export const Tower3AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    allUsers,
    currentUser,
    switchUser,
    registerStudent
  } = useApp();

  const [activeTab, setActiveTab] = useState<'switch' | 'register'>('switch');
  const [name, setName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [email, setEmail] = useState('');
  const [roomNumber, setRoomNumber] = useState('');
  const [towerSelection, setTowerSelection] = useState<'Tower 3' | 'Other'>('Tower 3');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Business Rule: Restrict access to Tower 3 only!
    if (towerSelection !== 'Tower 3') {
      setErrorMsg('Access Restricted: BiteTogether is exclusively for Tower 3 hostel students.');
      return;
    }

    if (!roomNumber.startsWith('3')) {
      setErrorMsg('Invalid Room: Tower 3 rooms start with digit 3 (e.g. 301, 314, 325).');
      return;
    }

    const success = await registerStudent(
      name.trim(),
      studentId.trim().toUpperCase(),
      email.trim(),
      roomNumber.trim()
    );

    if (success) {
      setSuccessMsg(`Welcome, ${name}! Logged in as Tower 3 resident.`);
      setTimeout(() => {
        setIsAuthModalOpen(false);
        setSuccessMsg(null);
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#202020]/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FFF9F3] rounded-2xl max-w-md w-full border border-[#202020]/10 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-[#202020]/10 bg-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
              <Building className="w-3.5 h-3.5" />
              <span>Hostel Access Control</span>
            </div>
            <h2 className="font-heading text-lg font-bold text-[#202020]">
              Tower 3 Student Identity
            </h2>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Prototype Demo Banner */}
        <div className="px-5 py-2.5 bg-amber-50 border-b border-amber-200 text-amber-900 text-xs flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
          <span>
            <strong>Prototype Demo Auth:</strong> Switch seamlessly between Tower 3 roommates or register a new resident.
          </span>
        </div>

        {/* Tab Toggle */}
        <div className="p-2 bg-[#202020]/5 border-b border-[#202020]/10 flex gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('switch')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'switch' ? 'bg-white text-[#202020] shadow-xs' : 'text-[#202020]/60 hover:text-[#202020]'
            }`}
          >
            Switch Roommate Account
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('register')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'register' ? 'bg-white text-[#202020] shadow-xs' : 'text-[#202020]/60 hover:text-[#202020]'
            }`}
          >
            Register Tower 3 Student
          </button>
        </div>

        <div className="p-5">
          {activeTab === 'switch' ? (
            <div className="space-y-3">
              <p className="text-xs text-[#202020]/70">
                Click any roommate below to test multi-student ordering and cart splitting:
              </p>

              <div className="space-y-2">
                {allUsers.map(user => {
                  const isCurrent = user.id === currentUser.id;
                  return (
                    <button
                      key={user.id}
                      onClick={() => {
                        switchUser(user.id);
                        setIsAuthModalOpen(false);
                      }}
                      className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                        isCurrent
                          ? 'bg-white border-[#FF7A1A] ring-2 ring-[#FF7A1A]/20 shadow-xs'
                          : 'bg-white/80 border-[#202020]/10 hover:bg-white hover:border-[#202020]/25'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            isCurrent ? 'bg-[#FF7A1A] text-white' : 'bg-[#202020]/10 text-[#202020]'
                          }`}
                        >
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-xs text-[#202020] flex items-center gap-1.5">
                            <span>{user.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] text-[#FF7A1A] font-bold uppercase">
                                (Active)
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-[#202020]/60">
                            Tower 3 · Room {user.roomNumber} · {user.studentId}
                          </div>
                        </div>
                      </div>

                      {isCurrent ? (
                        <Check className="w-4 h-4 text-[#FF7A1A]" />
                      ) : (
                        <span className="text-[11px] font-medium text-[#202020]/50">
                          Switch →
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3 text-xs">
              {errorMsg && (
                <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div>
                <label className="block font-semibold text-[#202020] mb-1">Full Student Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Siddharth Rao"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-[#202020] mb-1">Student ID / Roll No</label>
                  <input
                    type="text"
                    required
                    placeholder="2023CSB1090"
                    value={studentId}
                    onChange={e => setStudentId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A] font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#202020] mb-1">Room Number</label>
                  <input
                    type="text"
                    required
                    placeholder="318"
                    value={roomNumber}
                    onChange={e => setRoomNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#202020] mb-1">College Email ID</label>
                <input
                  type="email"
                  required
                  placeholder="siddharth.r@college.edu"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#202020] mb-1">Hostel Tower</label>
                <select
                  value={towerSelection}
                  onChange={e => setTowerSelection(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A]"
                >
                  <option value="Tower 3">Tower 3 (Eligible for BiteTogether)</option>
                  <option value="Other">Tower 1 / Tower 2 (Ineligible)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-[#FF7A1A] hover:bg-[#e86b12] text-white font-heading font-bold text-xs rounded-xl transition-all shadow-md mt-2 flex items-center justify-center gap-1.5"
              >
                <span>Complete Tower 3 Verification</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
