import React from 'react';
import { useApp } from '../context/AppContext';
import { Users, Sparkles, PlusCircle } from 'lucide-react';

export const RoommateSwitcher: React.FC = () => {
  const { allUsers, currentUser, switchUser, setIsAuthModalOpen } = useApp();

  return (
    <aside aria-label="Roommate Switcher" className="bg-[#141414] text-white py-2 px-4 text-xs border-b border-white/5">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-white/80">
          <span className="font-bold text-[#FF7A1A] flex items-center gap-1.5 bg-[#FF7A1A]/10 px-2 py-0.5 rounded-md">
            <Users className="w-3.5 h-3.5" />
            Tower 3 Switcher:
          </span>
          <span className="hidden sm:inline text-white/50 text-[11px]">
            Switch roommates in 1-click to test multi-student cart pooling &amp; separate payments
          </span>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          {allUsers.slice(0, 4).map(user => {
            const isSelected = user.id === currentUser.id;
            return (
              <button
                key={user.id}
                onClick={() => switchUser(user.id)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] text-white shadow-[0_2px_10px_rgba(255,122,26,0.3)] ring-1 ring-white/20 scale-102'
                    : 'bg-white/10 text-white/75 hover:bg-white/20 hover:text-white'
                }`}
              >
                <span>{user.name.split(' ')[0]}</span>
                <span className={`text-[10px] ${isSelected ? 'text-white/90' : 'text-white/40'}`}>
                  (Rm {user.roomNumber})
                </span>
                {isSelected && <span className="text-[10px] text-white font-bold">✓</span>}
              </button>
            );
          })}

          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="px-2.5 py-1 rounded-xl text-xs text-white/70 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 transition-colors flex items-center gap-1 whitespace-nowrap"
            title="Register new student or manage demo accounts"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>More / Register</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
