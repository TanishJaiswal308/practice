import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { GroupOrder, CartItem } from '../types';
import { PastOrderReceiptModal } from './PastOrderReceiptModal';
import {
  User,
  ShoppingBag,
  TrendingUp,
  Receipt,
  Users,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Search,
  MapPin,
  Calendar,
  CreditCard,
  UtensilsCrossed,
  Check
} from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const {
    currentUser,
    groups,
    cartItems,
    setActiveGroupId,
    setIsCartOpen,
    setCurrentTab,
    addToCart
  } = useApp();

  const [expandedOrderId, setExpandedOrderId] = useState<string | null>('g-past-1');
  const [orderScope, setOrderScope] = useState<'my' | 'all'>('my');
  const [searchPastQuery, setSearchPastQuery] = useState<string>('');
  const [reorderNotice, setReorderNotice] = useState<string | null>(null);
  const [selectedReceiptGroup, setSelectedReceiptGroup] = useState<GroupOrder | null>(null);

  // Active groups for current user
  const activeUserGroups = useMemo(() => {
    return groups.filter(g => {
      if (g.status === 'completed') return false;
      const isCreator = g.creatorId === currentUser.id;
      const hasItems = cartItems.some(ci => ci.groupId === g.id && ci.userId === currentUser.id);
      return isCreator || hasItems;
    });
  }, [groups, cartItems, currentUser.id]);

  // All completed groups
  const allCompletedGroups = useMemo(() => {
    return groups.filter(g => g.status === 'completed');
  }, [groups]);

  // Completed groups where user participated or created
  const userCompletedGroups = useMemo(() => {
    return allCompletedGroups.filter(g => {
      const isCreator = g.creatorId === currentUser.id;
      const hasItems = cartItems.some(ci => ci.groupId === g.id && ci.userId === currentUser.id);
      return isCreator || hasItems;
    });
  }, [allCompletedGroups, cartItems, currentUser.id]);

  // Display list based on selected scope
  const targetCompletedGroups = orderScope === 'my' ? userCompletedGroups : allCompletedGroups;

  // Search filter
  const filteredPastOrders = useMemo(() => {
    return targetCompletedGroups.filter(g => {
      const q = searchPastQuery.toLowerCase();
      const matchName = g.name.toLowerCase().includes(q);
      const matchCode = g.code.toLowerCase().includes(q);
      const matchToken = (g.cafeTokenNumber || '').toLowerCase().includes(q);
      const matchItems = cartItems
        .filter(ci => ci.groupId === g.id)
        .some(ci => ci.itemName.toLowerCase().includes(q) || ci.userName.toLowerCase().includes(q));
      return matchName || matchCode || matchToken || matchItems;
    });
  }, [targetCompletedGroups, searchPastQuery, cartItems]);

  // Personal spending calculations across past orders
  const pastUserItems = useMemo(() => {
    return cartItems.filter(ci => {
      const isCompleted = allCompletedGroups.some(g => g.id === ci.groupId);
      return isCompleted && ci.userId === currentUser.id;
    });
  }, [cartItems, allCompletedGroups, currentUser.id]);

  const totalPastSpending = pastUserItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Total spending in current active orders
  const currentActiveUserItems = useMemo(() => {
    return cartItems.filter(ci => {
      const isActive = activeUserGroups.some(g => g.id === ci.groupId);
      return isActive && ci.userId === currentUser.id;
    });
  }, [cartItems, activeUserGroups, currentUser.id]);

  const totalCurrentActiveSpending = currentActiveUserItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  // Total late-night savings benchmark: each group order saved ~₹150 in minimum cart surcharges
  const totalCompletedOrdersCount = userCompletedGroups.length;
  const estimatedSavings = Math.max(150, totalCompletedOrdersCount * 175);

  const toggleExpandOrder = (id: string) => {
    setExpandedOrderId(prev => (prev === id ? null : id));
  };

  // Reorder student's items from a past completed order
  const handleReorder = async (group: GroupOrder) => {
    const myItemsInPast = cartItems.filter(ci => ci.groupId === group.id && ci.userId === currentUser.id);
    if (myItemsInPast.length === 0) return;

    for (const item of myItemsInPast) {
      await addToCart(item.menuItemId, item.quantity, item.specialInstructions);
    }

    setReorderNotice(`Added ${myItemsInPast.length} item(s) from "${group.name}" into your active cart!`);
    setTimeout(() => setReorderNotice(null), 3000);
    setIsCartOpen(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      
      {/* Reorder feedback notification */}
      {reorderNotice && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#202020] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 text-xs border border-white/10 animate-bounce">
          <Check className="w-4 h-4 text-[#10B981]" />
          <span>{reorderNotice}</span>
        </div>
      )}

      {/* Student Profile Card */}
      <div className="bg-white rounded-2xl border border-[#202020]/10 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-[#FF7A1A] text-white flex items-center justify-center font-heading font-extrabold text-2xl shadow-sm">
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading text-xl sm:text-2xl font-bold text-[#202020]">
                  {currentUser.name}
                </h1>
                <span className="text-[11px] font-semibold text-[#10B981] bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Tower 3 Verified
                </span>
              </div>
              <p className="text-xs text-[#202020]/65 mt-0.5">
                Room {currentUser.roomNumber} · Student ID: <span className="font-mono">{currentUser.studentId}</span> · {currentUser.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentTab('menu')}
              className="px-4 py-2 bg-[#FF7A1A] hover:bg-[#e86b12] text-white text-xs font-semibold rounded-xl transition-colors shadow-2xs flex items-center gap-1.5"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Browse Cafe Menu</span>
            </button>
          </div>
        </div>

        {/* Analytics KPI Strip */}
        <div className="mt-6 pt-5 border-t border-[#202020]/10 grid grid-cols-2 md:grid-cols-4 gap-4">
          
          <div className="p-3.5 bg-[#FFF9F3] border border-[#202020]/5 rounded-xl">
            <span className="text-[11px] text-[#202020]/60 block uppercase tracking-wider">
              Late-Night Savings
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="font-mono tabular-nums text-xl font-extrabold text-[#10B981]">
                ₹{estimatedSavings}
              </span>
              <span className="text-[10px] text-[#10B981] font-semibold">saved</span>
            </div>
            <span className="text-[10px] text-[#202020]/50 block mt-0.5">
              by pooling the ₹300 cafe minimum
            </span>
          </div>

          <div className="p-3.5 bg-[#FFF9F3] border border-[#202020]/5 rounded-xl">
            <span className="text-[11px] text-[#202020]/60 block uppercase tracking-wider">
              Past Orders Spending
            </span>
            <div className="font-mono tabular-nums text-xl font-extrabold text-[#202020] mt-1">
              ₹{totalPastSpending}
            </div>
            <span className="text-[10px] text-[#202020]/50 block mt-0.5">
              across {userCompletedGroups.length} completed orders
            </span>
          </div>

          <div className="p-3.5 bg-[#FFF9F3] border border-[#202020]/5 rounded-xl">
            <span className="text-[11px] text-[#202020]/60 block uppercase tracking-wider">
              Active Orders Share
            </span>
            <div className="font-mono tabular-nums text-xl font-extrabold text-[#FF7A1A] mt-1">
              ₹{totalCurrentActiveSpending}
            </div>
            <span className="text-[10px] text-[#202020]/50 block mt-0.5">
              in {activeUserGroups.length} ongoing group cart(s)
            </span>
          </div>

          <div className="p-3.5 bg-[#FFF9F3] border border-[#202020]/5 rounded-xl">
            <span className="text-[11px] text-[#202020]/60 block uppercase tracking-wider">
              Hostel Dining Hub
            </span>
            <div className="text-sm font-bold text-[#FF7A1A] mt-1 truncate">
              Grains &amp; Gossip
            </div>
            <span className="text-[10px] text-[#202020]/50 block mt-0.5">
              Open daily till 3:00 AM
            </span>
          </div>

        </div>
      </div>

      {/* Active Groups Section */}
      {activeUserGroups.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-heading text-lg font-bold text-[#202020] flex items-center gap-2">
              <Users className="w-4 h-4 text-[#FF7A1A]" />
              Your Ongoing Group Orders ({activeUserGroups.length})
            </h2>
            <button
              onClick={() => setCurrentTab('groups')}
              className="text-xs font-semibold text-[#FF7A1A] hover:underline"
            >
              Explore all groups →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeUserGroups.map(group => {
              const myItems = cartItems.filter(ci => ci.groupId === group.id && ci.userId === currentUser.id);
              const mySubtotal = myItems.reduce((s, i) => s + i.price * i.quantity, 0);

              return (
                <div
                  key={group.id}
                  className="bg-white rounded-2xl border border-[#202020]/10 p-4 shadow-2xs hover:border-[#FF7A1A]/40 transition-all"
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-mono font-bold text-[#FF7A1A]">{group.code}</span>
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-white bg-[#202020] px-2 py-0.5 rounded">
                      {group.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h3 className="font-heading font-bold text-base text-[#202020]">{group.name}</h3>
                  <div className="text-xs text-[#202020]/60 mt-0.5">
                    Host: {group.creatorName} (Room {group.creatorRoom}) · Combined Total: ₹{group.totalAmount}/₹300
                  </div>

                  <div className="mt-3 pt-3 border-t border-[#202020]/5 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[#202020]/50 block text-[10px]">Your Items Subtotal</span>
                      <span className="font-mono tabular-nums font-bold text-sm text-[#FF7A1A]">
                        ₹{mySubtotal}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setActiveGroupId(group.id);
                          setIsCartOpen(true);
                        }}
                        className="px-2.5 py-1.5 bg-[#FFF9F3] hover:bg-[#202020]/5 border border-[#202020]/10 rounded-lg text-xs font-medium text-[#202020]"
                      >
                        Shared Cart
                      </button>
                      <button
                        onClick={() => {
                          setActiveGroupId(group.id);
                          setCurrentTab('tracking');
                        }}
                        className="px-3 py-1.5 bg-[#FF7A1A] hover:bg-[#e86b12] text-white rounded-lg text-xs font-semibold shadow-2xs flex items-center gap-1"
                      >
                        <span>Live Tracking</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* EXTENDED: PAST ORDERS SECTION */}
      <section className="space-y-4 pt-2">
        
        {/* Section Header with Scope Filters & Search */}
        <div className="bg-white rounded-2xl border border-[#202020]/10 p-5 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
                <Receipt className="w-4 h-4" />
                <span>Order History &amp; Itemized Spending</span>
              </div>
              <h2 className="font-heading text-xl sm:text-2xl font-bold text-[#202020] mt-0.5">
                Past Orders
              </h2>
              <p className="text-xs text-[#202020]/65 mt-0.5">
                Review completed late-night group orders, total group costs, your personal spending, and itemized receipts.
              </p>
            </div>

            {/* Scope Toggle & Search */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
              {/* Segmented Scope Control (Interactive buttons per §1.A) */}
              <div className="flex items-center bg-[#FFF9F3] border border-[#202020]/10 rounded-xl p-1 text-xs">
                <button
                  type="button"
                  onClick={() => setOrderScope('my')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    orderScope === 'my'
                      ? 'bg-[#202020] text-white shadow-2xs font-semibold'
                      : 'text-[#202020]/70 hover:text-[#202020]'
                  }`}
                >
                  My Past Orders ({userCompletedGroups.length})
                </button>
                <button
                  type="button"
                  onClick={() => setOrderScope('all')}
                  className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
                    orderScope === 'all'
                      ? 'bg-[#202020] text-white shadow-2xs font-semibold'
                      : 'text-[#202020]/70 hover:text-[#202020]'
                  }`}
                >
                  All Tower 3 ({allCompletedGroups.length})
                </button>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-[#202020]/40 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter past orders..."
                  value={searchPastQuery}
                  onChange={e => setSearchPastQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs bg-[#FFF9F3] border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A] w-full sm:w-48"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Empty State */}
        {filteredPastOrders.length === 0 ? (
          <div className="bg-white rounded-2xl border border-[#202020]/10 p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#FFF9F3] border border-[#202020]/10 text-[#202020]/40 flex items-center justify-center mx-auto">
              <Receipt className="w-6 h-6" />
            </div>
            <h3 className="font-heading font-bold text-base text-[#202020]">
              No past orders found
            </h3>
            <p className="text-xs text-[#202020]/60 max-w-sm mx-auto">
              {orderScope === 'my'
                ? "You haven't participated in any completed group orders yet. Check out active Tower 3 orders or switch to 'All Tower 3' to view floor history."
                : 'No past orders matched your search criteria.'}
            </p>
            {orderScope === 'my' && (
              <button
                onClick={() => setOrderScope('all')}
                className="px-3.5 py-1.5 bg-[#FFF9F3] border border-[#202020]/15 hover:bg-[#202020]/5 text-xs font-semibold text-[#202020] rounded-lg transition-colors"
              >
                View All Tower 3 Completed Orders
              </button>
            )}
          </div>
        ) : (
          /* Past Orders List with Total Spending per Order */
          <div className="space-y-4">
            {filteredPastOrders.map(group => {
              const isExpanded = expandedOrderId === group.id;

              // Items in this completed order
              const groupItems = cartItems.filter(ci => ci.groupId === group.id);
              const myItems = groupItems.filter(ci => ci.userId === currentUser.id);

              // Total spendings
              const groupTotalSpending = group.totalAmount || groupItems.reduce((s, i) => s + i.price * i.quantity, 0);
              const myPersonalSpending = myItems.reduce((s, i) => s + i.price * i.quantity, 0);

              // Unique participants in this order
              const uniqueParticipantNames = Array.from(new Set(groupItems.map(i => i.userName)));

              // Formatted date
              const orderDateStr = new Date(group.createdAt).toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
              });

              return (
                <div
                  key={group.id}
                  className="bg-white rounded-2xl border border-[#202020]/10 shadow-2xs hover:shadow-xs transition-all overflow-hidden"
                >
                  {/* Summary Bar */}
                  <div
                    onClick={() => toggleExpandOrder(group.id)}
                    className="p-4 sm:p-5 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white hover:bg-[#FFF9F3]/60 transition-colors"
                  >
                    {/* Left: Code, Name, Cafe Token */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-bold text-[#FF7A1A]">
                          {group.code}
                        </span>
                        <span className="text-[#202020]/30">·</span>
                        <span className="font-mono text-[#202020]/75 font-semibold">
                          Token #{group.cafeTokenNumber || 'GG-2849'}
                        </span>
                        <span className="text-[#202020]/30">·</span>
                        <span className="text-[11px] text-[#202020]/60 flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#202020]/40" />
                          {orderDateStr}
                        </span>
                        <span className="text-[#10B981] font-semibold text-[11px] flex items-center gap-1 ml-1">
                          <CheckCircle2 className="w-3 h-3" /> Fulfilled
                        </span>
                      </div>

                      <h3 className="font-heading font-bold text-base sm:text-lg text-[#202020]">
                        {group.name}
                      </h3>

                      <div className="flex items-center gap-2 text-xs text-[#202020]/65">
                        <span>Host: <strong>{group.creatorName}</strong> (Room {group.creatorRoom})</span>
                        <span className="text-[#202020]/30">·</span>
                        <span>Pickup: {group.pickupPoint}</span>
                      </div>
                    </div>

                    {/* Right: TOTAL SPENDING PER ORDER (Group Spending & User Personal Spending) */}
                    <div className="flex items-center justify-between md:justify-end gap-6 pt-3 md:pt-0 border-t md:border-t-0 border-[#202020]/5">
                      
                      {/* Your Personal Spending in this order */}
                      <div className="text-left md:text-right">
                        <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block font-medium">
                          Your Spending
                        </span>
                        <span className="font-mono tabular-nums text-base sm:text-lg font-extrabold text-[#FF7A1A] block">
                          ₹{myPersonalSpending}
                        </span>
                        <span className="text-[10px] text-[#202020]/55 block">
                          {myItems.length > 0 ? `${myItems.length} item(s) selected` : 'Did not participate'}
                        </span>
                      </div>

                      {/* Total Group Spending in this order */}
                      <div className="text-right pl-4 border-l border-[#202020]/10">
                        <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block font-medium">
                          Total Group Spending
                        </span>
                        <span className="font-mono tabular-nums text-base sm:text-lg font-extrabold text-[#202020] block">
                          ₹{groupTotalSpending}
                        </span>
                        <span className="text-[10px] text-[#202020]/55 block">
                          Grains &amp; Gossip Total
                        </span>
                      </div>

                      {/* Direct View Receipt Modal Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedReceiptGroup(group);
                        }}
                        className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-[#FFF9F3] hover:bg-[#FF7A1A]/10 border border-[#202020]/15 hover:border-[#FF7A1A]/40 rounded-lg text-xs font-semibold text-[#202020] transition-colors shadow-2xs whitespace-nowrap"
                        title="View official itemized receipt"
                      >
                        <Receipt className="w-3.5 h-3.5 text-[#FF7A1A]" />
                        <span>Receipt</span>
                      </button>

                      {/* Toggle Chevron */}
                      <button
                        type="button"
                        className="p-1.5 rounded-lg text-[#202020]/40 hover:text-[#202020] hover:bg-[#202020]/5 transition-colors"
                        aria-label={isExpanded ? 'Collapse order' : 'Expand order receipt'}
                      >
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-[#FF7A1A]" />
                        ) : (
                          <ChevronDown className="w-5 h-5" />
                        )}
                      </button>

                    </div>
                  </div>

                  {/* Expanded Itemized Receipt Drawer */}
                  {isExpanded && (
                    <div className="border-t border-[#202020]/10 bg-[#FFF9F3]/40 p-4 sm:p-5 space-y-4">
                      
                      {/* Spending Overview Cards */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                        
                        <div className="p-3 bg-white border border-[#202020]/10 rounded-xl">
                          <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block">
                            Total Group Order Value
                          </span>
                          <div className="font-mono text-lg font-bold text-[#202020] mt-0.5">
                            ₹{groupTotalSpending}
                          </div>
                          <span className="text-[10px] text-[#10B981] font-medium mt-0.5 block">
                            ✓ Surpassed ₹300 minimum threshold
                          </span>
                        </div>

                        <div className="p-3 bg-white border border-[#202020]/10 rounded-xl">
                          <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block">
                            Your Net Payment
                          </span>
                          <div className="font-mono text-lg font-bold text-[#FF7A1A] mt-0.5">
                            ₹{myPersonalSpending}
                          </div>
                          <span className="text-[10px] text-[#202020]/60 mt-0.5 block">
                            Paid via UPI (No split penalty)
                          </span>
                        </div>

                        <div className="p-3 bg-white border border-[#202020]/10 rounded-xl">
                          <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block">
                            Late-Night Roommates
                          </span>
                          <div className="font-bold text-sm text-[#202020] mt-0.5 truncate">
                            {uniqueParticipantNames.join(', ') || `${group.creatorName}`}
                          </div>
                          <span className="text-[10px] text-[#202020]/60 mt-0.5 block">
                            {uniqueParticipantNames.length} Tower 3 students pooled
                          </span>
                        </div>

                      </div>

                      {/* Itemized Items Breakdown */}
                      <div className="bg-white border border-[#202020]/10 rounded-xl p-4 space-y-3">
                        <div className="flex items-center justify-between text-xs font-semibold text-[#202020] border-b border-[#202020]/5 pb-2">
                          <span className="flex items-center gap-1.5">
                            <UtensilsCrossed className="w-3.5 h-3.5 text-[#FF7A1A]" />
                            Itemized Group Bill Breakdown
                          </span>
                          <span className="font-mono tabular-nums text-[11px] text-[#202020]/60">
                            {groupItems.length} items ordered
                          </span>
                        </div>

                        <div className="space-y-2 text-xs divide-y divide-[#202020]/5">
                          {groupItems.map(item => {
                            const isMine = item.userId === currentUser.id;
                            return (
                              <div
                                key={item.id}
                                className={`pt-2 flex items-center justify-between ${
                                  isMine ? 'font-medium' : 'text-[#202020]/75'
                                }`}
                              >
                                <div className="space-y-0.5">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[#202020]">{item.itemName}</span>
                                    <span className="text-[#202020]/50 font-mono">×{item.quantity}</span>
                                    {isMine && (
                                      <span className="text-[10px] font-bold text-[#FF7A1A] bg-[#FF7A1A]/10 px-1.5 py-0.2 rounded">
                                        Your Item
                                      </span>
                                    )}
                                  </div>
                                  <span className="text-[11px] text-[#202020]/50 block">
                                    Ordered by {item.userName} (Room {item.roomNumber})
                                  </span>
                                </div>

                                <div className="text-right">
                                  <span className="font-mono tabular-nums font-semibold text-[#202020]">
                                    ₹{item.price * item.quantity}
                                  </span>
                                  <span className="text-[10px] text-[#202020]/40 block font-mono">
                                    ₹{item.price} each
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Total Spending Reconciliation Bar */}
                        <div className="pt-3 border-t border-[#202020]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                          <div className="flex items-center gap-3 text-[#202020]/70">
                            <span>Late-Night Delivery Fee: <strong className="text-[#10B981]">₹0 (Free)</strong></span>
                            <span>·</span>
                            <span>Payment Method: <strong className="font-mono">UPI / QR</strong></span>
                          </div>

                          <div className="flex items-center gap-4 text-xs">
                            <span className="text-[#202020]/70">
                              Combined Total: <strong className="font-mono text-[#202020] font-bold">₹{groupTotalSpending}</strong>
                            </span>
                            <span className="text-[#FF7A1A] font-bold font-mono">
                              Your Paid Share: ₹{myPersonalSpending}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action Strip: Reorder & Live Tracking View */}
                      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                        <div className="text-[11px] text-[#202020]/60 flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-[#FF7A1A]" />
                          <span>Delivered to: {group.pickupPoint}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedReceiptGroup(group)}
                            className="px-3 py-1.5 bg-white hover:bg-[#FF7A1A]/10 border border-[#FF7A1A]/40 text-[#FF7A1A] rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>Official Itemized Receipt</span>
                          </button>

                          {myItems.length > 0 && (
                            <button
                              type="button"
                              onClick={() => handleReorder(group)}
                              className="px-3 py-1.5 bg-[#FFF9F3] hover:bg-[#202020]/5 border border-[#202020]/15 text-[#202020] rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs"
                            >
                              <RotateCcw className="w-3.5 h-3.5 text-[#FF7A1A]" />
                              <span>Reorder My Bites</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              setActiveGroupId(group.id);
                              setCurrentTab('tracking');
                            }}
                            className="px-3 py-1.5 bg-[#202020] hover:bg-[#333] text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1"
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>Tracking Log</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

      </section>

      {/* Itemized Past Order Receipt Modal */}
      <PastOrderReceiptModal
        group={selectedReceiptGroup}
        isOpen={Boolean(selectedReceiptGroup)}
        onClose={() => setSelectedReceiptGroup(null)}
        onReorder={handleReorder}
        cartItems={cartItems}
        currentUser={currentUser}
      />

    </div>
  );
};
