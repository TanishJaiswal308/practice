import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GroupCard } from './GroupCard';
import {
  Users,
  PlusCircle,
  Search,
  Filter,
  KeyRound,
  CheckCircle2,
  Clock,
  Sparkles
} from 'lucide-react';

export const GroupsView: React.FC = () => {
  const {
    groups,
    setIsCreateGroupOpen,
    joinGroup,
    setCurrentTab
  } = useApp();

  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'collecting' | 'threshold_met' | 'completed'>('all');
  const [codeQuery, setCodeQuery] = useState('');
  const [codeMsg, setCodeMsg] = useState<string | null>(null);

  const filteredGroups = groups.filter(g => {
    const matchSearch =
      g.name.toLowerCase().includes(search.toLowerCase()) ||
      g.creatorName.toLowerCase().includes(search.toLowerCase()) ||
      g.creatorRoom.includes(search) ||
      g.code.toLowerCase().includes(search.toLowerCase());

    const matchStatus = filterStatus === 'all' || g.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleJoinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setCodeMsg(null);
    const cleaned = codeQuery.trim().toUpperCase();
    const match = groups.find(g => g.code.toUpperCase() === cleaned);
    if (!match) {
      setCodeMsg(`No group found with code "${cleaned}".`);
      return;
    }
    const res = await joinGroup(match.id);
    if (res.success) {
      setCurrentTab('menu');
      setCodeQuery('');
    } else {
      setCodeMsg(res.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-white rounded-2xl border border-[#202020]/10 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
            Hostel Group Directory
          </div>
          <h1 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#202020] mt-0.5">
            Tower 3 Group Orders
          </h1>
          <p className="text-xs sm:text-sm text-[#202020]/65 mt-1">
            Grains &amp; Gossip cafe orders currently pooling across Tower 3 wings and floors.
          </p>
        </div>

        <button
          onClick={() => setIsCreateGroupOpen(true)}
          className="px-4 py-2.5 bg-[#FF7A1A] hover:bg-[#e86b12] text-white text-xs font-semibold rounded-xl transition-all shadow-md flex items-center gap-2 self-start md:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Start New Group Order</span>
        </button>
      </div>

      {/* Filter and Code Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Status filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {[
            { id: 'all', label: 'All Groups' },
            { id: 'collecting', label: 'Collecting Orders' },
            { id: 'threshold_met', label: '₹300 Unlocked' },
            { id: 'completed', label: 'Past Fulfilled' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                filterStatus === tab.id
                  ? 'bg-[#202020] text-white shadow-2xs'
                  : 'bg-white text-[#202020]/75 border border-[#202020]/10 hover:bg-[#202020]/5'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-[#202020]/40 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by room, code or host..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#202020]/15 rounded-lg focus:outline-none focus:border-[#FF7A1A]"
            />
          </div>
        </div>
      </div>

      {/* Join Code Helper Box */}
      <div className="p-4 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 text-[#202020]">
          <KeyRound className="w-4 h-4 text-[#FF7A1A] shrink-0" />
          <span>Have a group code shared by your roommate? Enter it here to hop in immediately:</span>
        </div>
        <form onSubmit={handleJoinByCode} className="flex gap-2">
          <input
            type="text"
            placeholder="e.g. T3-MUNCH"
            value={codeQuery}
            onChange={e => setCodeQuery(e.target.value)}
            className="px-3 py-1.5 bg-white border border-[#202020]/15 rounded-lg text-xs font-mono uppercase focus:outline-none focus:border-[#FF7A1A] w-36"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-[#202020] hover:bg-[#333] text-white rounded-lg text-xs font-semibold"
          >
            Join
          </button>
        </form>
      </div>

      {codeMsg && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs">
          {codeMsg}
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGroups.map(group => (
          <GroupCard key={group.id} group={group} />
        ))}
      </div>

    </div>
  );
};
