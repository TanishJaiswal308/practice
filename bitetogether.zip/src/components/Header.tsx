import React from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Bell, User, Users, Compass, UtensilsCrossed, Clock, Sparkles } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentUser,
    activeGroup,
    activeGroupCartItems,
    setIsCartOpen,
    setIsNotificationsOpen,
    setIsAuthModalOpen,
    unreadNotificationsCount,
    currentTab,
    setCurrentTab
  } = useApp();

  const totalCartCount = activeGroupCartItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalCartAmount = activeGroup ? activeGroup.totalAmount : 0;
  const isThresholdMet = totalCartAmount >= 300;

  return (
    <header className="sticky top-0 z-40 bg-white/85 backdrop-blur-xl border-b border-[#202020]/8 shadow-xs transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setCurrentTab('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#FF7A1A] via-[#FF6A00] to-[#E55500] text-white flex items-center justify-center font-heading font-extrabold text-xl shadow-[0_4px_14px_rgba(255,122,26,0.35)] group-hover:scale-105 group-hover:rotate-1 transition-all">
              B
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-heading text-xl font-extrabold tracking-tight text-[#202020] block leading-none">
                  BiteTogether
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF7A1A]" />
              </div>
              <span className="text-[10px] font-semibold text-[#202020]/55 tracking-wider uppercase block mt-1">
                Tower 3 Hostel Hub
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Clean single line with subtle pill hover) */}
        <nav className="hidden md:flex items-center gap-2 text-sm font-medium text-[#202020]/75">
          <button
            onClick={() => setCurrentTab('home')}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl transition-all ${
              currentTab === 'home'
                ? 'bg-[#202020] text-white font-semibold shadow-xs'
                : 'hover:bg-[#202020]/5 hover:text-[#202020]'
            }`}
          >
            Explore
          </button>
          <button
            onClick={() => setCurrentTab('groups')}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              currentTab === 'groups'
                ? 'bg-[#202020] text-white font-semibold shadow-xs'
                : 'hover:bg-[#202020]/5 hover:text-[#202020]'
            }`}
          >
            <Users className="w-4 h-4 opacity-80" />
            Active Groups
          </button>
          <button
            onClick={() => setCurrentTab('menu')}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              currentTab === 'menu'
                ? 'bg-[#202020] text-white font-semibold shadow-xs'
                : 'hover:bg-[#202020]/5 hover:text-[#202020]'
            }`}
          >
            <UtensilsCrossed className="w-4 h-4 opacity-80" />
            Grains &amp; Gossip Menu
          </button>
          <button
            onClick={() => setCurrentTab('tracking')}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              currentTab === 'tracking'
                ? 'bg-[#202020] text-white font-semibold shadow-xs'
                : 'hover:bg-[#202020]/5 hover:text-[#202020]'
            }`}
          >
            <Clock className="w-4 h-4 opacity-80" />
            Live Tracking
          </button>
          <button
            onClick={() => setCurrentTab('dashboard')}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
              currentTab === 'dashboard'
                ? 'bg-[#202020] text-white font-semibold shadow-xs'
                : 'hover:bg-[#202020]/5 hover:text-[#202020]'
            }`}
          >
            <Compass className="w-4 h-4 opacity-80" />
            Dashboard
          </button>
        </nav>

        {/* Zone 3: Actions & Profile */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Notifications Button */}
          <button
            onClick={() => setIsNotificationsOpen(true)}
            className="relative p-2.5 text-[#202020]/70 hover:text-[#202020] hover:bg-[#202020]/5 rounded-xl transition-colors"
            title="Notifications"
            aria-label="View notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FF7A1A] ring-2 ring-white" />
            )}
          </button>

          {/* Student Profile Quick Switcher Trigger */}
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="flex items-center gap-2 px-2.5 py-1.5 text-xs font-medium text-[#202020] bg-[#FFF9F3] border border-[#202020]/10 rounded-xl hover:border-[#FF7A1A]/40 transition-all shadow-2xs hover:shadow-xs"
            title="Switch student profile (Tower 3)"
          >
            <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-[#FF7A1A] to-[#FFA14A] text-white flex items-center justify-center font-bold text-[11px] shadow-2xs">
              {currentUser.name.charAt(0)}
            </div>
            <div className="text-left hidden sm:block">
              <span className="block font-semibold truncate max-w-[105px] leading-tight">{currentUser.name}</span>
              <span className="block text-[10px] text-[#202020]/55 leading-none">Rm {currentUser.roomNumber}</span>
            </div>
          </button>

          {/* Primary Action: Shared Cart Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl transition-all shadow-sm ${
              isThresholdMet
                ? 'bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] text-white hover:brightness-105 shadow-[0_4px_15px_rgba(255,122,26,0.35)] ring-2 ring-[#FF7A1A]/30 glow-warm'
                : 'bg-[#202020] text-white hover:bg-[#303030]'
            }`}
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span className="tabular-nums font-mono font-bold">₹{totalCartAmount}</span>
            <span className="text-[11px] opacity-80 hidden xs:inline">
              {isThresholdMet ? '· Unlocked' : `/ ₹300`}
            </span>
            {totalCartCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-white/25 text-[10px] flex items-center justify-center font-mono font-bold">
                {totalCartCount}
              </span>
            )}
          </button>

        </div>

      </div>

      {/* Mobile Secondary Navigation Row */}
      <div className="flex md:hidden items-center justify-around px-2 py-2 border-t border-[#202020]/5 bg-white/95 text-xs font-medium text-[#202020]/70 overflow-x-auto">
        <button
          onClick={() => setCurrentTab('home')}
          className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${currentTab === 'home' ? 'bg-[#202020] text-white font-bold' : ''}`}
        >
          Explore
        </button>
        <button
          onClick={() => setCurrentTab('groups')}
          className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${currentTab === 'groups' ? 'bg-[#202020] text-white font-bold' : ''}`}
        >
          Groups
        </button>
        <button
          onClick={() => setCurrentTab('menu')}
          className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${currentTab === 'menu' ? 'bg-[#202020] text-white font-bold' : ''}`}
        >
          Menu
        </button>
        <button
          onClick={() => setCurrentTab('tracking')}
          className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${currentTab === 'tracking' ? 'bg-[#202020] text-white font-bold' : ''}`}
        >
          Tracking
        </button>
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${currentTab === 'dashboard' ? 'bg-[#202020] text-white font-bold' : ''}`}
        >
          Dashboard
        </button>
      </div>
    </header>
  );
};
