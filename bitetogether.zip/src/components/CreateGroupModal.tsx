import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Users, Clock, MapPin, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';

export const CreateGroupModal: React.FC = () => {
  const {
    isCreateGroupOpen,
    setIsCreateGroupOpen,
    currentUser,
    createGroup,
    setCurrentTab
  } = useApp();

  const [groupName, setGroupName] = useState<string>('Floor 3 Late Night Munchies');
  const [deadlineMinutes, setDeadlineMinutes] = useState<number>(30);
  const [participantLimit, setParticipantLimit] = useState<number>(6);
  const [pickupPoint, setPickupPoint] = useState<string>(
    `Tower 3 Room ${currentUser.roomNumber} or Security Desk`
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isCreateGroupOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const newId = await createGroup(
      groupName.trim() || `${currentUser.name}'s Late-Night Order`,
      deadlineMinutes,
      participantLimit,
      pickupPoint
    );
    setIsSubmitting(false);
    if (newId) {
      setIsCreateGroupOpen(false);
      setCurrentTab('menu');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#202020]/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FFF9F3] rounded-2xl max-w-md w-full border border-[#202020]/10 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-[#202020]/10 bg-white flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
              Tower 3 Exclusive
            </div>
            <h2 className="font-heading text-lg font-bold text-[#202020]">
              Start a Shared Group Order
            </h2>
          </div>
          <button
            onClick={() => setIsCreateGroupOpen(false)}
            className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          
          {/* Cafe Lock Note */}
          <div className="p-3 bg-white border border-[#202020]/10 rounded-xl flex items-start gap-2.5 text-xs">
            <div className="w-6 h-6 rounded-md bg-[#FF7A1A]/10 text-[#FF7A1A] flex items-center justify-center shrink-0 font-bold">
              G&amp;G
            </div>
            <div>
              <div className="font-semibold text-[#202020]">Cafe: Grains and Gossip</div>
              <div className="text-[#202020]/65 text-[11px]">
                Hostel mess closes at 9 PM. Cart unlocks once group reaches ₹300 total.
              </div>
            </div>
          </div>

          {/* Group Name */}
          <div>
            <label className="block text-xs font-semibold text-[#202020] mb-1">
              Group Order Name
            </label>
            <input
              type="text"
              required
              value={groupName}
              onChange={e => setGroupName(e.target.value)}
              placeholder="e.g. 3rd Floor Exam Prep Munchies"
              className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg text-xs text-[#202020] focus:outline-none focus:border-[#FF7A1A]"
            />
          </div>

          {/* Deadline Selector */}
          <div>
            <label className="block text-xs font-semibold text-[#202020] mb-1 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#FF7A1A]" />
              Order Deadline (When to freeze cart)
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[15, 30, 45, 60].map(mins => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => setDeadlineMinutes(mins)}
                  className={`py-2 px-1 text-center rounded-lg text-xs font-medium border transition-all ${
                    deadlineMinutes === mins
                      ? 'bg-[#202020] text-white border-[#202020] shadow-xs'
                      : 'bg-white text-[#202020]/75 border-[#202020]/15 hover:bg-[#202020]/5'
                  }`}
                >
                  {mins} mins
                </button>
              ))}
            </div>
          </div>

          {/* Participant Limit */}
          <div>
            <label className="block text-xs font-semibold text-[#202020] mb-1 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-[#FF7A1A]" />
              Max Roommate Limit (Optional)
            </label>
            <select
              value={participantLimit}
              onChange={e => setParticipantLimit(Number(e.target.value))}
              className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg text-xs text-[#202020] focus:outline-none focus:border-[#FF7A1A]"
            >
              <option value={4}>4 Roommates (Quick Snack)</option>
              <option value={6}>6 Roommates (Wing Standard)</option>
              <option value={8}>8 Roommates (Floor Jam)</option>
              <option value={12}>12 Roommates (Max Group)</option>
            </select>
          </div>

          {/* Pickup Point */}
          <div>
            <label className="block text-xs font-semibold text-[#202020] mb-1 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#FF7A1A]" />
              Hostel Pickup Point (Tower 3)
            </label>
            <input
              type="text"
              value={pickupPoint}
              onChange={e => setPickupPoint(e.target.value)}
              placeholder="e.g. Tower 3 Ground Security Desk"
              className="w-full px-3 py-2 bg-white border border-[#202020]/15 rounded-lg text-xs text-[#202020] focus:outline-none focus:border-[#FF7A1A]"
            />
          </div>

          {/* Host Info Box */}
          <div className="p-3 bg-white border border-[#202020]/5 rounded-lg text-[11px] text-[#202020]/70 flex items-center justify-between">
            <span>Created by: <strong>{currentUser.name}</strong></span>
            <span>Tower 3 · Room {currentUser.roomNumber}</span>
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 px-4 bg-[#FF7A1A] hover:bg-[#e86b12] text-white font-heading font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-2"
          >
            <span>Create Group &amp; Open Menu</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
