import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { MenuItem } from '../types';
import { OFFICIAL_MENU_NOTICE } from '../data/mockMenu';
import {
  Search,
  Plus,
  Minus,
  Check,
  ShoppingBag,
  Flame,
  Leaf,
  Clock,
  Sparkles,
  ArrowRight,
  Utensils,
  FileText,
  Phone,
  Truck,
  Package,
  X,
  ExternalLink,
  ZoomIn,
  ShieldCheck,
  HelpCircle,
  Tag
} from 'lucide-react';

export const MenuView: React.FC = () => {
  const {
    menuItems,
    addToCart,
    activeGroup,
    setIsCartOpen,
    currentUser,
    userCartItems
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dietFilter, setDietFilter] = useState<'all' | 'veg' | 'non-veg'>('all');
  const [under100Only, setUnder100Only] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'default' | 'price_asc' | 'price_desc'>('default');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [addedItemNotice, setAddedItemNotice] = useState<string | null>(null);
  const [isFlyerModalOpen, setIsFlyerModalOpen] = useState<boolean>(false);

  // Exact categories derived from the flyer
  const categories = [
    { id: 'all', label: 'All 58 Items', count: menuItems.length },
    { id: 'rice_noodles', label: 'Rice & Noodles', count: menuItems.filter(i => i.category === 'rice_noodles').length },
    { id: 'burgers', label: 'Burgers', count: menuItems.filter(i => i.category === 'burgers').length },
    { id: 'sandwiches', label: 'Sandwiches', count: menuItems.filter(i => i.category === 'sandwiches').length },
    { id: 'pizza', label: '8" Pizzas', count: menuItems.filter(i => i.category === 'pizza').length },
    { id: 'starters_sides', label: 'Starters & Sides', count: menuItems.filter(i => i.category === 'starters_sides').length },
    { id: 'pasta', label: 'Pasta', count: menuItems.filter(i => i.category === 'pasta').length },
    { id: 'beverages', label: 'Juices & Shakes & Hot', count: menuItems.filter(i => i.category === 'beverages').length }
  ];

  // Available sub-categories for current category selection
  const availableSubCategories = useMemo(() => {
    const relevantItems = selectedCategory === 'all'
      ? menuItems
      : menuItems.filter(i => i.category === selectedCategory);
    
    const set = new Set<string>();
    relevantItems.forEach(i => {
      if (i.subCategory) set.add(i.subCategory);
    });
    return Array.from(set);
  }, [menuItems, selectedCategory]);

  const filteredItems = useMemo(() => {
    const list = menuItems.filter(item => {
      const matchCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchSubCategory = selectedSubCategory === 'all' || item.subCategory === selectedSubCategory;
      const matchSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.subCategory && item.subCategory.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchDiet =
        dietFilter === 'all'
          ? true
          : dietFilter === 'veg'
          ? item.isVeg
          : !item.isVeg;

      const matchUnder100 = !under100Only || item.price <= 100;

      return matchCategory && matchSubCategory && matchSearch && matchDiet && matchUnder100;
    });

    if (sortBy === 'price_asc') {
      return [...list].sort((a, b) => a.price - b.price);
    }
    if (sortBy === 'price_desc') {
      return [...list].sort((a, b) => b.price - a.price);
    }
    return list;
  }, [menuItems, selectedCategory, selectedSubCategory, searchQuery, dietFilter, under100Only, sortBy]);

  const handleCategorySelect = (catId: string) => {
    setSelectedCategory(catId);
    setSelectedSubCategory('all');
  };

  const handleQtyChange = (itemId: string, delta: number) => {
    setQuantities(prev => {
      const current = prev[itemId] || 1;
      const next = Math.max(1, current + delta);
      return { ...prev, [itemId]: next };
    });
  };

  const handleAdd = async (item: MenuItem) => {
    const qty = quantities[item.id] || 1;
    const res = await addToCart(item.id, qty);
    if (res.success) {
      setAddedItemNotice(`Added ${qty}x ${item.name} to shared cart!`);
      setTimeout(() => setAddedItemNotice(null), 2500);
      setQuantities(prev => ({ ...prev, [item.id]: 1 }));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Late-Night Flyer Notice Banner */}
      <div className="bg-gradient-to-r from-[#202020] via-[#2A231F] to-[#202020] rounded-3xl p-5 sm:p-7 text-white shadow-xl relative overflow-hidden border border-[#FF7A1A]/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF7A1A]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF7A1A]/20 border border-[#FF7A1A]/40 text-xs font-bold text-[#FF9E4A]">
              <span className="w-2 h-2 rounded-full bg-[#FF7A1A] animate-ping" />
              <span>Official Late-Night Food Delivery Notice</span>
              <span className="text-white/40">·</span>
              <span>Grains and Gossips Cafe</span>
            </div>
            
            <h1 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              Exact Grains &amp; Gossip Late-Night Menu
            </h1>
            
            <p className="text-xs sm:text-sm text-white/80 max-w-2xl leading-relaxed">
              Every single dish, exact price, and category matching the official late-night flyer delivered to Hostel Reception, Staff Quarters &amp; Villas.
            </p>

            {/* Flyer Quick Highlights */}
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 pt-2 text-xs text-white/70">
              <div className="flex items-center gap-1.5 font-medium">
                <Clock className="w-3.5 h-3.5 text-[#FF7A1A]" />
                <span>Timings: <strong className="text-white">9:30 PM – 3:00 AM</strong></span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Contact: <strong className="text-white">+91 99809 25507</strong></span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <Package className="w-3.5 h-3.5 text-amber-400" />
                <span>Packing: <strong className="text-white">₹10 / Container</strong></span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <Truck className="w-3.5 h-3.5 text-sky-400" />
                <span>Delivery: <strong className="text-emerald-400">Free to Hostel</strong></span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
            <button
              onClick={() => setIsFlyerModalOpen(true)}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-2xl border border-white/20 transition-all flex items-center justify-center gap-2 backdrop-blur-md shadow-sm"
            >
              <FileText className="w-4 h-4 text-[#FF7A1A]" />
              <span>View Scanned Menu Flyer</span>
            </button>

            {activeGroup && (
              <button
                onClick={() => setIsCartOpen(true)}
                className="px-4 py-2.5 bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] hover:brightness-105 active:scale-95 text-white text-xs font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-md"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Group Cart (₹{activeGroup.totalAmount})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Active Group Status Pill if active */}
      {activeGroup && (
        <div className="bg-[#FFF9F3] border border-[#FF7A1A]/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FF7A1A]/10 text-[#FF7A1A] flex items-center justify-center font-black shrink-0">
              ₹
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-[#202020]">{activeGroup.name}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#FF7A1A]/15 text-[#FF7A1A] uppercase">
                  Room {activeGroup.creatorRoom}
                </span>
              </div>
              <p className="text-xs text-[#202020]/70 mt-0.5">
                Pool with roommates to meet the minimum threshold! Currently at{' '}
                <strong className="text-[#202020]">₹{activeGroup.totalAmount}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-right">
              <span className="text-xs font-semibold text-[#202020]/60">Status: </span>
              <span className={`text-xs font-extrabold ${activeGroup.totalAmount >= 300 ? 'text-emerald-600' : 'text-[#FF7A1A]'}`}>
                {activeGroup.totalAmount >= 300 ? '✓ Checkout Unlocked' : `₹${300 - activeGroup.totalAmount} remaining`}
              </span>
            </div>
            <button
              onClick={() => setIsCartOpen(true)}
              className="px-3.5 py-1.5 bg-[#202020] hover:bg-black text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5"
            >
              <span>View Cart</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Filter & Navigation Section */}
      <div className="bg-white rounded-3xl border border-[#202020]/10 p-5 sm:p-6 shadow-xs space-y-5">
        
        {/* Category Tabs */}
        <div>
          <div className="text-xs font-bold text-[#202020]/60 uppercase tracking-wider mb-2.5 flex items-center justify-between">
            <span>Menu Categories</span>
            <span className="text-[11px] font-medium text-[#202020]/50">Prices are including GST</span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-thin">
            {categories.map(cat => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`px-4 py-2.5 text-xs font-extrabold rounded-2xl transition-all whitespace-nowrap shrink-0 flex items-center gap-2 border ${
                    isSelected
                      ? 'bg-[#202020] text-white border-[#202020] shadow-sm'
                      : 'bg-[#FFF9F3] text-[#202020]/80 border-[#202020]/10 hover:border-[#FF7A1A]/40 hover:bg-[#FFF4E8]'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-[#202020]/10 text-[#202020]/70'
                    }`}
                  >
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Sub-Category Filter Chips (if more than 1 in current category) */}
        {availableSubCategories.length > 1 && (
          <div className="pt-2 border-t border-[#202020]/5">
            <div className="text-[11px] font-bold text-[#202020]/50 uppercase tracking-wider mb-2">
              Section Breakdown
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              <button
                onClick={() => setSelectedSubCategory('all')}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap shrink-0 ${
                  selectedSubCategory === 'all'
                    ? 'bg-[#FF7A1A] text-white shadow-xs'
                    : 'bg-[#FFF9F3] text-[#202020]/70 hover:bg-[#202020]/5'
                }`}
              >
                All Sections
              </button>
              {availableSubCategories.map(sub => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubCategory(sub)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap shrink-0 ${
                    selectedSubCategory === sub
                      ? 'bg-[#FF7A1A] text-white shadow-xs'
                      : 'bg-[#FFF9F3] text-[#202020]/70 hover:bg-[#202020]/5'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Search, Diet Filter, Budget Filter & Sorting */}
        <div className="pt-4 border-t border-[#202020]/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-[#202020]/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search dishes (e.g. Schezwan, Tikka, Cappacino, Fries)..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs bg-[#FFF9F3] border border-[#202020]/15 rounded-xl focus:outline-none focus:border-[#FF7A1A] font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#202020]/40 hover:text-[#202020]"
              >
                ✕
              </button>
            )}
          </div>

          {/* Quick Filter Controls */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            
            {/* Diet Switcher */}
            <div className="inline-flex items-center p-1 bg-[#FFF9F3] border border-[#202020]/15 rounded-xl text-xs font-bold">
              <button
                onClick={() => setDietFilter('all')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  dietFilter === 'all' ? 'bg-[#202020] text-white' : 'text-[#202020]/70 hover:text-[#202020]'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setDietFilter('veg')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                  dietFilter === 'veg' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-700 hover:text-emerald-800'
                }`}
              >
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>Veg</span>
              </button>
              <button
                onClick={() => setDietFilter('non-veg')}
                className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                  dietFilter === 'non-veg' ? 'bg-red-600 text-white shadow-xs' : 'text-red-700 hover:text-red-800'
                }`}
              >
                <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
                <span>Non-Veg</span>
              </button>
            </div>

            {/* Under ₹100 Quick Filter */}
            <button
              onClick={() => setUnder100Only(!under100Only)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${
                under100Only
                  ? 'bg-[#FF7A1A] text-white border-[#FF7A1A] shadow-xs'
                  : 'bg-white text-[#202020]/80 border-[#202020]/15 hover:border-[#FF7A1A]/40'
              }`}
            >
              <Tag className="w-3 h-3" />
              <span>Under ₹100</span>
            </button>

            {/* Sorting Dropdown */}
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="px-3 py-1.5 text-xs font-bold bg-[#FFF9F3] border border-[#202020]/15 rounded-xl focus:outline-none focus:border-[#FF7A1A] text-[#202020]"
            >
              <option value="default">Sort: Default</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
            </select>

          </div>
        </div>

      </div>

      {/* Floating Add Notice Toast */}
      {addedItemNotice && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#202020] text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs font-semibold border border-white/10 animate-bounce">
          <Check className="w-4 h-4 text-[#10B981]" />
          <span>{addedItemNotice}</span>
          <button
            onClick={() => setIsCartOpen(true)}
            className="ml-2 font-bold text-[#FF7A1A] underline hover:text-[#FFA14A]"
          >
            Open Cart →
          </button>
        </div>
      )}

      {/* Search Result Count */}
      <div className="flex items-center justify-between text-xs text-[#202020]/60 px-1 font-medium">
        <div>
          Showing <strong className="text-[#202020]">{filteredItems.length}</strong> items from Grains &amp; Gossip Late-Night Menu
          {under100Only && <span className="ml-1 text-[#FF7A1A] font-bold">(Budget ≤ ₹100)</span>}
        </div>
        <button
          onClick={() => setIsFlyerModalOpen(true)}
          className="text-[#FF7A1A] hover:underline font-bold flex items-center gap-1"
        >
          <span>Verify with Scanned Flyer</span>
          <ExternalLink className="w-3 h-3" />
        </button>
      </div>

      {/* Menu Cards Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-3xl border border-[#202020]/10 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-[#FF7A1A]/10 text-[#FF7A1A] mx-auto flex items-center justify-center font-bold">
            🍽️
          </div>
          <h3 className="text-base font-bold text-[#202020]">No menu items found</h3>
          <p className="text-xs text-[#202020]/60 max-w-sm mx-auto">
            Try adjusting your search query, clearing filters, or switching categories.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setSelectedSubCategory('all');
              setDietFilter('all');
              setUnder100Only(false);
            }}
            className="px-4 py-2 bg-[#202020] text-white text-xs font-bold rounded-xl"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => {
            const qty = quantities[item.id] || 1;
            const userItemInCart = userCartItems.find(ci => ci.menuItemId === item.id);

            return (
              <div
                key={item.id}
                className="bg-white rounded-3xl border border-[#202020]/10 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1"
              >
                {/* Product Photo Container */}
                <div className="relative h-48 w-full bg-[#202020]/5 overflow-hidden">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Veg / Non-Veg Indicator & Sub-Category Overlay */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 flex-wrap">
                    <div
                      className={`w-4 h-4 bg-white/95 backdrop-blur-xs rounded-xs flex items-center justify-center border shadow-xs ${
                        item.isVeg ? 'border-emerald-600' : 'border-red-600'
                      }`}
                      title={item.isVeg ? 'Vegetarian' : 'Non-Vegetarian'}
                    >
                      <div
                        className={`w-2 h-2 rounded-full ${
                          item.isVeg ? 'bg-emerald-600' : 'bg-red-600'
                        }`}
                      />
                    </div>

                    {item.subCategory && (
                      <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 bg-black/75 text-white backdrop-blur-xs rounded-md">
                        {item.subCategory}
                      </span>
                    )}
                  </div>

                  {/* Preparation Time Overlay */}
                  <div className="absolute bottom-3 right-3 text-[10px] font-mono font-bold text-white/95 bg-black/75 backdrop-blur-xs px-2.5 py-0.5 rounded-md flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#FF7A1A]" />
                    <span>{item.preparationTimeMins} mins</span>
                  </div>

                  {/* Tags */}
                  {item.tags && item.tags[0] && (
                    <div className="absolute top-3 right-3 text-[10px] font-bold text-[#FF7A1A] bg-white/95 backdrop-blur-xs px-2 py-0.5 rounded-md shadow-xs border border-[#FF7A1A]/20">
                      {item.tags[0]}
                    </div>
                  )}
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="font-heading font-extrabold text-base text-[#202020] leading-snug group-hover:text-[#FF7A1A] transition-colors">
                        {item.name}
                      </h3>
                      <div className="px-3 py-1 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl shrink-0">
                        <span className="font-mono tabular-nums font-black text-base text-[#202020]">
                          ₹{item.price}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-[#202020]/65 mt-2 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Card Action Row */}
                  <div className="mt-5 pt-3.5 border-t border-[#202020]/5 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      
                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-1 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl p-1">
                        <button
                          type="button"
                          onClick={() => handleQtyChange(item.id, -1)}
                          className="w-6 h-6 flex items-center justify-center rounded-lg text-[#202020]/70 hover:text-[#202020] hover:bg-[#202020]/10 transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-mono tabular-nums font-bold text-xs px-2 min-w-[20px] text-center">
                          {qty}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleQtyChange(item.id, 1)}
                          className="w-6 h-6 flex items-center justify-center rounded-lg text-[#202020]/70 hover:text-[#202020] hover:bg-[#202020]/10 transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Add to Cart Button */}
                      <button
                        type="button"
                        onClick={() => handleAdd(item)}
                        className="flex-1 py-2.5 px-3 bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] hover:brightness-105 active:scale-95 text-white rounded-xl text-xs font-bold font-heading transition-all flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add (₹{item.price * qty})</span>
                      </button>

                    </div>

                    {/* In Cart Indicator */}
                    {userItemInCart && (
                      <div className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1 pt-1">
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>You already have {userItemInCart.quantity} in group cart (₹{userItemInCart.price * userItemInCart.quantity})</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Official Flyer Lightbox Modal */}
      {isFlyerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1C1C1C] text-white rounded-3xl max-w-4xl w-full border border-white/10 overflow-hidden shadow-2xl relative my-8 animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-5 sm:p-6 bg-[#252525] border-b border-white/10 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-heading font-black text-lg text-white">
                    Official Grains and Gossips Flyer
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 bg-[#FF7A1A]/20 text-[#FF9E4A] font-bold rounded-md">
                    Verified Menu
                  </span>
                </div>
                <p className="text-xs text-white/60 mt-0.5">
                  Photographed menu circular with delivery guidelines and all 58 items
                </p>
              </div>

              <button
                onClick={() => setIsFlyerModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body: Flyer Image + Key Points */}
            <div className="p-5 sm:p-6 grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
              
              {/* High-res Image Preview */}
              <div className="bg-black/50 rounded-2xl overflow-hidden border border-white/10 relative group">
                <img
                  src={OFFICIAL_MENU_NOTICE.flyerImagePath}
                  alt="Official Grains and Gossips Late Night Menu Flyer"
                  className="w-full h-auto max-h-[560px] object-contain rounded-2xl mx-auto"
                />
                <a
                  href={OFFICIAL_MENU_NOTICE.flyerImagePath}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute bottom-3 right-3 bg-black/80 hover:bg-black text-white text-[11px] font-bold px-3 py-1.5 rounded-xl border border-white/20 flex items-center gap-1.5 transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#FF7A1A]" />
                  <span>Open Full Image</span>
                </a>
              </div>

              {/* Flyer Notice Breakdown */}
              <div className="space-y-4">
                <div className="bg-[#2A231F] border border-[#FF7A1A]/30 rounded-2xl p-4 space-y-3">
                  <div className="text-xs font-black uppercase text-[#FF7A1A] tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Circular Highlights</span>
                  </div>

                  <div className="space-y-2.5 text-xs text-white/80">
                    <div className="flex items-start gap-2.5">
                      <Phone className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Order Contact</div>
                        <div>+91 99809 25507</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-[#FF7A1A] shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Late-Night Delivery Timings</div>
                        <div>9:30 PM – 3:00 AM (Every night)</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <ShoppingBag className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Minimum Order Value</div>
                        <div>₹350/- (BiteTogether pools Tower 3 orders so you only pay for your items!)</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Package className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Packing Charges</div>
                        <div>₹10 per container</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Truck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Delivery Charges</div>
                        <div>Free to Hostel Reception, Staff Quarters &amp; Villas</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <Clock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="font-bold text-white">Estimated Delivery Time</div>
                        <div>Minimum 30 minutes to collection desk</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#252525] rounded-2xl p-4 border border-white/10 text-xs text-white/70 space-y-2">
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#FF7A1A]" />
                    <span>How BiteTogether Works with Grains &amp; Gossip</span>
                  </div>
                  <p className="leading-relaxed">
                    Instead of a single student having to spend ₹350 when they only want a ₹119 Paneer Tikka Sandwich or ₹29 Masala Tea, BiteTogether combines everyone&apos;s food into one shared cart. Checkout unlocks automatically as soon as the combined total crosses ₹300/₹350.
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setIsFlyerModalOpen(false)}
                    className="w-full py-3 bg-[#FF7A1A] hover:bg-[#FF8A2A] text-white font-heading font-bold text-xs rounded-xl transition-all shadow-md"
                  >
                    Back to Interactive Menu
                  </button>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
