import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Plus,
  Minus,
  Trash2,
  Lock,
  Unlock,
  Share2,
  Check,
  Copy,
  Users,
  ShieldAlert,
  ArrowRight,
  Info,
  Clock,
  PlusCircle
} from 'lucide-react';

export const SharedCartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    activeGroup,
    activeGroupCartItems,
    activeGroupParticipants,
    currentUser,
    updateCartItemQty,
    removeCartItem,
    lockAndInitiateCheckout,
    extendGroupDeadline
  } = useApp();

  const [copiedLink, setCopiedLink] = useState(false);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeRemainingStr, setTimeRemainingStr] = useState<string>('25m 00s');
  const [isDeadlineExpired, setIsDeadlineExpired] = useState<boolean>(false);
  const [isExtending, setIsExtending] = useState<boolean>(false);

  useEffect(() => {
    if (!activeGroup?.deadline) return;

    const calculateTime = () => {
      const deadlineMs = new Date(activeGroup.deadline).getTime();
      const now = Date.now();
      const diffMs = deadlineMs - now;

      if (diffMs <= 0) {
        setIsDeadlineExpired(true);
        setTimeRemainingStr('00m 00s (Closing soon)');
        return;
      }

      setIsDeadlineExpired(false);
      const totalSecs = Math.floor(diffMs / 1000);
      const mins = Math.floor(totalSecs / 60);
      const secs = totalSecs % 60;
      setTimeRemainingStr(`${mins}m ${secs.toString().padStart(2, '0')}s`);
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [activeGroup?.deadline]);

  if (!isCartOpen) return null;

  const totalAmount = activeGroup ? activeGroup.totalAmount : 0;
  const minThreshold = activeGroup ? activeGroup.minThreshold : 300;
  const progressPercent = Math.min(100, Math.round((totalAmount / minThreshold) * 100));
  const remainingAmount = Math.max(0, minThreshold - totalAmount);
  const isThresholdMet = totalAmount >= minThreshold;
  const isCartFrozen = activeGroup?.status !== 'collecting' && activeGroup?.status !== 'threshold_met';

  // Group items by participant
  const itemsByUser = activeGroupParticipants.map(participant => {
    const userItems = activeGroupCartItems.filter(item => item.userId === participant.userId);
    const subtotal = userItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    return {
      participant,
      userItems,
      subtotal,
      isCurrentUser: participant.userId === currentUser.id
    };
  });

  // Calculate current user's individual share
  const currentUserShare = itemsByUser.find(g => g.isCurrentUser)?.subtotal || 0;

  const handleCopyInvite = () => {
    if (!activeGroup) return;
    const shareUrl = `${window.location.origin}/#group-${activeGroup.code}`;
    navigator.clipboard?.writeText(
      `Join my late-night Grains & Gossip order on BiteTogether! Group Code: ${activeGroup.code} (Tower 3) -> ${shareUrl}`
    );
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleCheckoutClick = async () => {
    setErrorNotice(null);
    setIsSubmitting(true);
    const result = await lockAndInitiateCheckout();
    setIsSubmitting(false);
    if (!result.success) {
      setErrorNotice(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#202020]/60 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-lg bg-[#FFF9F3] shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-[#202020]/10 bg-white">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
                    Shared Group Cart
                  </span>
                  <span className="text-xs text-[#202020]/40">·</span>
                  <span className="text-xs text-[#202020]/60 font-mono">
                    {activeGroup?.code || 'T3-CART'}
                  </span>
                </div>
                <h2 className="font-heading text-lg font-bold text-[#202020]">
                  {activeGroup?.name || 'Grains & Gossip Order'}
                </h2>
              </div>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-lg transition-colors"
                aria-label="Close cart drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Share Group Code Pill & Link */}
            {activeGroup && (
              <div className="mt-3 flex items-center justify-between gap-2 p-2 bg-[#FFF9F3] border border-[#202020]/10 rounded-lg text-xs">
                <div className="flex items-center gap-2 text-[#202020]/80">
                  <Users className="w-3.5 h-3.5 text-[#FF7A1A]" />
                  <span>
                    Host: <strong className="text-[#202020]">{activeGroup.creatorName}</strong> (Rm {activeGroup.creatorRoom})
                  </span>
                </div>
                <button
                  onClick={handleCopyInvite}
                  className="px-2.5 py-1 bg-white hover:bg-[#202020]/5 border border-[#202020]/15 rounded text-[11px] font-medium text-[#202020] transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-3 h-3 text-[#10B981]" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-3 h-3 text-[#FF7A1A]" />
                      <span>Share Code</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Live Checkout Time & Deadline Bar */}
            {activeGroup && (
              <div className={`mt-2.5 px-3 py-1.5 rounded-xl border flex items-center justify-between text-xs ${
                isDeadlineExpired ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-[#FFF4E8] border-[#FF7A1A]/20 text-[#202020]'
              }`}>
                <div className="flex items-center gap-1.5 font-medium">
                  <Clock className={`w-3.5 h-3.5 ${isDeadlineExpired ? 'text-amber-600 animate-pulse' : 'text-[#FF7A1A]'}`} />
                  <span>Checkout window: <strong className="font-mono">{timeRemainingStr}</strong></span>
                </div>
                <button
                  onClick={async () => {
                    setIsExtending(true);
                    await extendGroupDeadline(15);
                    setIsExtending(false);
                  }}
                  disabled={isExtending}
                  className="text-[11px] font-bold text-[#FF7A1A] hover:underline flex items-center gap-1"
                >
                  <PlusCircle className="w-3 h-3" />
                  <span>+15m</span>
                </button>
              </div>
            )}

            {/* ₹300 Minimum Rule Progress Meter */}
            <div className={`mt-4 p-4 rounded-2xl border transition-all ${
              isThresholdMet 
                ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-400/20 shadow-xs' 
                : 'bg-white border-[#202020]/10 shadow-xs'
            }`}>
              <div className="flex items-center justify-between mb-2 text-xs">
                <span className="font-bold text-[#202020] flex items-center gap-1.5">
                  {isThresholdMet ? (
                    <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                      <Unlock className="w-3 h-3" />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-[#FF7A1A]/15 text-[#FF7A1A] flex items-center justify-center">
                      <Lock className="w-3 h-3" />
                    </div>
                  )}
                  <span>{isThresholdMet ? 'Checkout Unlocked!' : '₹300 Minimum Threshold'}</span>
                </span>
                <span className="font-mono tabular-nums font-extrabold text-sm text-[#202020]">
                  ₹{totalAmount} <span className="text-xs font-normal text-[#202020]/50">/ ₹300</span>
                </span>
              </div>

              {/* Progress Bar with Shimmer */}
              <div className="w-full h-3 bg-[#202020]/10 rounded-full overflow-hidden relative">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    isThresholdMet 
                      ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' 
                      : 'bg-gradient-to-r from-[#FF7A1A] via-[#FF6A00] to-[#E04400] animate-shimmer'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {/* Status Message */}
              <div className="mt-2 text-xs flex items-center justify-between">
                {isThresholdMet ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    ✓ Threshold reached! Order unlocked for all roommates.
                  </span>
                ) : (
                  <span className="text-[#202020]/75">
                    Need <strong className="text-[#FF7A1A] font-mono font-bold">₹{remainingAmount}</strong> more to unlock cafe checkout
                  </span>
                )}
                <span className="text-[11px] text-[#202020]/60 font-mono font-bold">
                  {progressPercent}%
                </span>
              </div>
            </div>

            {/* Error notice if server rejected */}
            {errorNotice && (
              <div className="mt-3 p-2.5 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                <span>{errorNotice}</span>
              </div>
            )}

            {isCartFrozen && (
              <div className="mt-3 p-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg text-xs flex items-start gap-2">
                <Lock className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <span>
                  <strong>Cart is locked:</strong> Orders are frozen during payment. No items can be edited or removed.
                </span>
              </div>
            )}
          </div>

          {/* Cart Content: Individual Participant Sections */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {activeGroupCartItems.length === 0 ? (
              <div className="text-center py-12 px-4">
                <div className="w-12 h-12 rounded-full bg-[#FF7A1A]/10 text-[#FF7A1A] flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-base text-[#202020]">Cart is empty</h3>
                <p className="text-xs text-[#202020]/60 max-w-xs mx-auto mt-1">
                  Add items from the Grains &amp; Gossip menu to help reach the ₹300 shared goal!
                </p>
              </div>
            ) : (
              itemsByUser.map(({ participant, userItems, subtotal, isCurrentUser }) => {
                if (userItems.length === 0) return null;

                return (
                  <div
                    key={participant.userId}
                    className={`p-3.5 rounded-xl border transition-all ${
                      isCurrentUser
                        ? 'bg-white border-[#FF7A1A]/40 shadow-xs ring-1 ring-[#FF7A1A]/20'
                        : 'bg-white/80 border-[#202020]/10'
                    }`}
                  >
                    {/* Roommate Header */}
                    <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-[#202020]/5">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            isCurrentUser
                              ? 'bg-[#FF7A1A] text-white'
                              : 'bg-[#202020]/10 text-[#202020]'
                          }`}
                        >
                          {participant.userName.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-xs text-[#202020]">
                              {participant.userName}
                            </span>
                            {isCurrentUser && (
                              <span className="text-[10px] font-bold text-[#FF7A1A] uppercase tracking-wider">
                                (You)
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-[#202020]/50 block">
                            Tower 3 · Room {participant.roomNumber}
                          </span>
                        </div>
                      </div>

                      {/* Participant Subtotal */}
                      <div className="text-right">
                        <span className="text-[10px] text-[#202020]/50 uppercase tracking-wider block">
                          Their Subtotal
                        </span>
                        <span className="font-mono tabular-nums font-bold text-xs text-[#202020]">
                          ₹{subtotal}
                        </span>
                      </div>
                    </div>

                    {/* Participant Items List */}
                    <div className="space-y-2">
                      {userItems.map(item => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between text-xs py-1"
                        >
                          <div className="flex-1 pr-2">
                            <div className="font-medium text-[#202020] leading-snug">
                              {item.itemName}
                            </div>
                            <div className="text-[11px] text-[#202020]/60 font-mono">
                              ₹{item.price} × {item.quantity} = ₹{item.price * item.quantity}
                            </div>
                            {item.specialInstructions && (
                              <div className="text-[10px] text-[#202020]/50 italic">
                                Note: {item.specialInstructions}
                              </div>
                            )}
                          </div>

                          {/* Controls: ONLY for current user's items */}
                          {isCurrentUser && !isCartFrozen ? (
                            <div className="flex items-center gap-1.5 shrink-0 bg-[#FFF9F3] border border-[#202020]/10 rounded-lg p-1">
                              <button
                                onClick={() => updateCartItemQty(item.id, item.quantity - 1)}
                                className="w-5 h-5 flex items-center justify-center rounded text-[#202020]/70 hover:bg-[#202020]/10 hover:text-[#202020] transition-colors"
                                title="Decrease quantity"
                              >
                                {item.quantity === 1 ? (
                                  <Trash2 className="w-3 h-3 text-red-500" />
                                ) : (
                                  <Minus className="w-3 h-3" />
                                )}
                              </button>
                              <span className="font-mono font-semibold text-xs px-1 tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateCartItemQty(item.id, item.quantity + 1)}
                                className="w-5 h-5 flex items-center justify-center rounded text-[#202020]/70 hover:bg-[#202020]/10 hover:text-[#202020] transition-colors"
                                title="Increase quantity"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="text-[10px] text-[#202020]/40 font-mono shrink-0">
                              Qty: {item.quantity}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {!isCurrentUser && (
                      <div className="mt-2 pt-2 border-t border-[#202020]/5 text-[10px] text-[#202020]/50 flex items-center gap-1">
                        <Info className="w-3 h-3" />
                        <span>Only {participant.userName} can modify their items.</span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Checkout Action */}
          <div className="p-4 sm:p-5 border-t border-[#202020]/10 bg-white space-y-3">
            {/* Calculation Breakdown */}
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-[#202020]/70">
                <span>Combined Group Total</span>
                <span className="font-mono tabular-nums font-semibold text-[#202020]">
                  ₹{totalAmount}
                </span>
              </div>
              <div className="flex items-center justify-between font-semibold text-[#202020] text-sm pt-1 border-t border-[#202020]/5">
                <div>
                  <span>Your Individual Payable</span>
                  <span className="block text-[10px] text-[#202020]/50 font-normal">
                    (You pay strictly for your own items)
                  </span>
                </div>
                <span className="font-mono tabular-nums font-bold text-base text-[#FF7A1A]">
                  ₹{currentUserShare}
                </span>
              </div>
            </div>

            {/* Primary Action Button */}
            {isThresholdMet ? (
              <button
                onClick={handleCheckoutClick}
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 rounded-2xl font-heading font-extrabold text-sm text-white flex items-center justify-center gap-2 transition-all shadow-md bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] hover:brightness-105 active:scale-[0.99] ring-2 ring-[#FF7A1A]/20"
              >
                <Unlock className="w-4 h-4" />
                <span>
                  {isCartFrozen
                    ? `Proceed to Checkout & Payments (₹${totalAmount})`
                    : currentUserShare > 0
                    ? `Lock Cart & Pay Your ₹${currentUserShare}`
                    : `Lock Cart & Open Checkout (₹${totalAmount})`}
                </span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>
            ) : (
              <button
                disabled
                className="w-full py-3.5 px-4 rounded-2xl font-heading font-medium text-xs sm:text-sm bg-[#202020]/10 text-[#202020]/50 flex items-center justify-center gap-2 cursor-not-allowed"
              >
                <Lock className="w-4 h-4" />
                <span>Checkout Locked · ₹{remainingAmount} more needed</span>
              </button>
            )}

            <div className="text-center text-[10px] text-[#202020]/50">
              Exclusively for Tower 3 · Fixed Grains &amp; Gossip ₹300 cart condition
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
