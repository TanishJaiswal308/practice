import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  QrCode,
  Smartphone,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
  Receipt,
  Users,
  ArrowRight,
  Clock,
  PlusCircle,
  Sparkles,
  Info
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    activeGroup,
    userCartItems,
    activeGroupParticipants,
    currentUser,
    submitPayment,
    placeOrderWithCafe,
    setCurrentTab,
    extendGroupDeadline
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'qr' | 'razorpay_demo'>('upi');
  const [upiIdInput, setUpiIdInput] = useState<string>('9876543210@okaxis');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationStep, setVerificationStep] = useState<string>('');
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [txnRef, setTxnRef] = useState<string>('');
  const [extendingDeadline, setExtendingDeadline] = useState<boolean>(false);
  const [timeRemainingStr, setTimeRemainingStr] = useState<string>('25m 00s');
  const [isDeadlineExpired, setIsDeadlineExpired] = useState<boolean>(false);

  // Live countdown timer for the checkout deadline
  useEffect(() => {
    if (!activeGroup?.deadline) return;

    const calculateTime = () => {
      const deadlineMs = new Date(activeGroup.deadline).getTime();
      const now = Date.now();
      const diffMs = deadlineMs - now;

      if (diffMs <= 0) {
        setIsDeadlineExpired(true);
        setTimeRemainingStr('00m 00s (Closing)');
        return;
      }

      setIsDeadlineExpired(false);
      const totalSecs = Math.floor(diffMs / 1000);
      const mins = Math.floor(totalSecs / 60);
      const secs = totalSecs % 60;
      setTimeRemainingStr(`${mins}m ${secs.toString().padStart(2, '0')}s`);
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [activeGroup?.deadline]);

  if (!isCheckoutOpen || !activeGroup) return null;

  // Calculate individual payable
  const userSubtotal = userCartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const packagingFee = 0; // Transparent: ₹0 hostel discount
  const finalAmount = userSubtotal + packagingFee;
  const hasUserItems = userCartItems.length > 0;

  // Check if current user is already marked paid
  const currentParticipant = activeGroupParticipants.find(p => p.userId === currentUser.id);
  const isAlreadyPaid = (currentParticipant?.paymentStatus === 'paid' && currentParticipant?.totalIndividualAmount > 0) || paymentSuccess;

  // Check group payment readiness across all participants with items
  const participantsWithOrders = activeGroupParticipants.filter(p => p.totalIndividualAmount > 0);
  const paidCount = participantsWithOrders.filter(
    p => p.paymentStatus === 'paid' || (p.userId === currentUser.id && isAlreadyPaid)
  ).length;
  const allPaid = participantsWithOrders.length > 0 && paidCount === participantsWithOrders.length;

  const handleInitiatePayment = () => {
    if (finalAmount <= 0) return;
    setIsVerifying(true);
    setVerificationStep('Initiating secure UPI session...');

    setTimeout(() => {
      setVerificationStep('Verifying Tower 3 transaction with Grains & Gossip...');
    }, 900);

    setTimeout(async () => {
      const generatedRef = `UPI-T3-${Date.now().toString().slice(-6)}`;
      setTxnRef(generatedRef);
      await submitPayment(finalAmount, paymentMethod, generatedRef);
      setIsVerifying(false);
      setPaymentSuccess(true);
    }, 1800);
  };

  const handlePlaceFinalOrder = async () => {
    const result = await placeOrderWithCafe();
    if (result.success) {
      setIsCheckoutOpen(false);
      setCurrentTab('tracking');
    }
  };

  const handleExtendDeadline = async () => {
    setExtendingDeadline(true);
    await extendGroupDeadline(15);
    setExtendingDeadline(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#202020]/65 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FFF9F3] rounded-3xl max-w-lg w-full border border-[#202020]/10 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#202020]/10 bg-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#FF7A1A] uppercase tracking-wider">
              <span>Tower 3 Checkout</span>
              <span className="text-[#202020]/30">·</span>
              <span className="text-[#202020]/60 font-mono">{activeGroup.code}</span>
            </div>
            <h2 className="font-heading text-lg sm:text-xl font-extrabold text-[#202020]">
              Pay For Your Food Only
            </h2>
          </div>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Checkout Time & Deadline Banner */}
        <div className={`px-4 sm:px-5 py-2.5 border-b flex items-center justify-between text-xs transition-colors ${
          isDeadlineExpired 
            ? 'bg-amber-50 border-amber-200 text-amber-900' 
            : 'bg-[#FFF4E8] border-[#FF7A1A]/20 text-[#202020]'
        }`}>
          <div className="flex items-center gap-2">
            <Clock className={`w-4 h-4 ${isDeadlineExpired ? 'text-amber-600 animate-pulse' : 'text-[#FF7A1A]'}`} />
            <div>
              <span className="font-semibold">Checkout Window: </span>
              <span className="font-mono font-bold">{timeRemainingStr}</span>
              {isDeadlineExpired && <span className="text-amber-700 ml-1 font-bold">(Grace Period Active)</span>}
            </div>
          </div>

          <button
            onClick={handleExtendDeadline}
            disabled={extendingDeadline}
            className="px-2.5 py-1 bg-white hover:bg-[#FF7A1A]/10 text-[#FF7A1A] border border-[#FF7A1A]/30 rounded-lg text-[11px] font-bold transition-all shadow-2xs flex items-center gap-1"
            title="Add 15 minutes to allow roommates to complete payment"
          >
            <PlusCircle className="w-3 h-3" />
            <span>+15 Mins</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* User Food Breakdown */}
          {hasUserItems ? (
            <div className="p-4 bg-white border border-[#202020]/10 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#202020]/5 text-xs text-[#202020]/60">
                <span className="font-bold flex items-center gap-1.5 text-[#202020]">
                  <Receipt className="w-3.5 h-3.5 text-[#FF7A1A]" />
                  {currentUser.name} (Room {currentUser.roomNumber})
                </span>
                <span>Your Selected Food</span>
              </div>

              <div className="space-y-2 text-xs">
                {userCartItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center py-0.5">
                    <div className="flex-1 pr-2">
                      <span className="font-semibold text-[#202020]">{item.itemName}</span>
                      <span className="text-[#202020]/50 ml-1.5">×{item.quantity}</span>
                    </div>
                    <span className="font-mono tabular-nums font-bold text-[#202020]">
                      ₹{item.price * item.quantity}
                    </span>
                  </div>
                ))}

                <div className="pt-2 border-t border-[#202020]/5 space-y-1">
                  <div className="flex justify-between text-[#202020]/60 text-[11px]">
                    <span>Items Subtotal</span>
                    <span className="font-mono tabular-nums font-semibold">₹{userSubtotal}</span>
                  </div>
                  <div className="flex justify-between text-[#202020]/60 text-[11px]">
                    <span>Late-Night Delivery to Tower 3</span>
                    <span className="text-[#10B981] font-bold">FREE (₹0)</span>
                  </div>
                  <div className="flex justify-between font-black text-sm text-[#202020] pt-1.5 border-t border-[#202020]/5">
                    <span>Your Net Payable Amount</span>
                    <span className="font-mono tabular-nums text-base text-[#FF7A1A]">
                      ₹{finalAmount}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Host/Roommate Spectator Mode (No items) */
            <div className="p-4 bg-white border border-[#202020]/10 rounded-2xl text-xs space-y-2">
              <div className="flex items-center gap-2 font-bold text-[#202020]">
                <Info className="w-4 h-4 text-[#FF7A1A]" />
                <span>Host / Roommate Monitoring Mode</span>
              </div>
              <p className="text-[#202020]/70 leading-relaxed">
                You haven&apos;t added individual food items to this cart. You can review and monitor other roommates&apos; payments below, and dispatch the order to Grains &amp; Gossip once ready.
              </p>
            </div>
          )}

          {/* Payment Method Selector (Only for user with items who hasn't paid) */}
          {hasUserItems && !isAlreadyPaid && (
            <div className="space-y-3">
              <label className="block text-xs font-bold text-[#202020] uppercase tracking-wider">
                Select Payment Mode (UPI / QR / Razorpay)
              </label>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-[#FF7A1A] bg-white ring-2 ring-[#FF7A1A]/20 shadow-xs'
                      : 'border-[#202020]/10 bg-white/60 hover:bg-white'
                  }`}
                >
                  <Smartphone className="w-5 h-5 text-[#FF7A1A] mb-1.5" />
                  <div className="font-bold text-xs text-[#202020]">UPI Apps</div>
                  <div className="text-[10px] text-[#202020]/60">GPay, PhonePe, Paytm</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('qr')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'qr'
                      ? 'border-[#FF7A1A] bg-white ring-2 ring-[#FF7A1A]/20 shadow-xs'
                      : 'border-[#202020]/10 bg-white/60 hover:bg-white'
                  }`}
                >
                  <QrCode className="w-5 h-5 text-[#FF7A1A] mb-1.5" />
                  <div className="font-bold text-xs text-[#202020]">Scan QR</div>
                  <div className="text-[10px] text-[#202020]/60">Instant Camera Scan</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('razorpay_demo')}
                  className={`p-3 rounded-2xl border text-left transition-all ${
                    paymentMethod === 'razorpay_demo'
                      ? 'border-[#FF7A1A] bg-white ring-2 ring-[#FF7A1A]/20 shadow-xs'
                      : 'border-[#202020]/10 bg-white/60 hover:bg-white'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-[#FF7A1A] mb-1.5" />
                  <div className="font-bold text-xs text-[#202020]">Razorpay</div>
                  <div className="text-[10px] text-[#202020]/60">Cards / Netbanking</div>
                </button>
              </div>

              {/* Dynamic Payment Detail Card */}
              {paymentMethod === 'upi' && (
                <div className="p-3.5 bg-white border border-[#202020]/10 rounded-2xl space-y-2 text-xs">
                  <label className="block text-[11px] font-semibold text-[#202020]/70">
                    Verify Student VPA / UPI ID
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={upiIdInput}
                      onChange={e => setUpiIdInput(e.target.value)}
                      placeholder="e.g. yourname@okaxis"
                      className="flex-1 px-3 py-2 bg-[#FFF9F3] border border-[#202020]/15 rounded-xl text-xs font-mono focus:outline-none focus:border-[#FF7A1A]"
                    />
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-[#202020]/60">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
                    <span>Payee: Grains &amp; Gossip (Tower 3 Late-Night Order)</span>
                  </div>
                </div>
              )}

              {paymentMethod === 'qr' && (
                <div className="p-4 bg-white border border-[#202020]/10 rounded-2xl text-center space-y-2">
                  <div className="inline-block p-2 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl">
                    <div className="w-32 h-32 mx-auto bg-white flex flex-col items-center justify-center border border-dashed border-[#202020]/20 p-2">
                      <QrCode className="w-24 h-24 text-[#202020]" />
                      <span className="font-mono text-[10px] font-bold text-[#FF7A1A] mt-1">₹{finalAmount}</span>
                    </div>
                  </div>
                  <div className="text-xs font-bold text-[#202020]">
                    Scan using any UPI App (GPay / PhonePe / Paytm / BHIM)
                  </div>
                  <div className="text-[11px] text-[#202020]/60">
                    UPI VPA: <span className="font-mono text-[#202020] font-bold">grainsandgossip@icici</span> · Payable: ₹{finalAmount}
                  </div>
                </div>
              )}

              {paymentMethod === 'razorpay_demo' && (
                <div className="p-3.5 bg-white border border-[#202020]/10 rounded-2xl text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#202020]">Razorpay Integration Architecture</span>
                    <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded-md text-[10px] font-mono font-bold">
                      Verified Ready
                    </span>
                  </div>
                  <p className="text-[11px] text-[#202020]/70 leading-relaxed">
                    Razorpay Standard Checkout with webhook signature verification ready for production keys.
                  </p>
                </div>
              )}

              {/* Verified Gateway Processing State */}
              {isVerifying ? (
                <div className="p-4 bg-[#FF7A1A]/10 border border-[#FF7A1A]/20 rounded-2xl text-center space-y-2">
                  <Loader2 className="w-6 h-6 animate-spin text-[#FF7A1A] mx-auto" />
                  <div className="text-xs font-bold text-[#202020]">
                    {verificationStep}
                  </div>
                  <div className="text-[10px] text-[#202020]/60">
                    Validating transaction reference with banking network...
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleInitiatePayment}
                  className="w-full py-3.5 px-4 bg-gradient-to-r from-[#FF7A1A] to-[#FF5500] hover:brightness-105 active:scale-95 text-white font-heading font-extrabold text-sm rounded-2xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify &amp; Pay ₹{finalAmount}</span>
                </button>
              )}
            </div>
          )}

          {/* User Paid Confirmation Card */}
          {hasUserItems && isAlreadyPaid && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-[#10B981] mx-auto" />
              <div className="font-heading font-black text-base text-emerald-900">
                Your Payment is Completed!
              </div>
              <p className="text-xs text-emerald-800">
                Paid <strong className="font-mono font-black">₹{finalAmount}</strong>. Reference:{' '}
                <span className="font-mono font-bold">{txnRef || 'UPI-PAID'}</span>
              </p>
            </div>
          )}

          {/* Roommate Payment Roster */}
          <div className="p-4 bg-white border border-[#202020]/10 rounded-2xl space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-[#202020]">
              <span className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#FF7A1A]" />
                Roommate Payment Status
              </span>
              <span className="font-mono tabular-nums text-xs bg-[#FFF9F3] px-2 py-0.5 rounded-lg border border-[#202020]/10">
                {paidCount} / {participantsWithOrders.length} Paid
              </span>
            </div>

            <div className="space-y-2">
              {participantsWithOrders.map(p => {
                const isPaid = p.paymentStatus === 'paid' || (p.userId === currentUser.id && isAlreadyPaid);
                return (
                  <div
                    key={p.userId}
                    className="flex items-center justify-between text-xs py-2 px-3 rounded-xl bg-[#FFF9F3] border border-[#202020]/5"
                  >
                    <div>
                      <span className="font-bold text-[#202020]">{p.userName}</span>
                      <span className="text-[#202020]/50 ml-1.5 text-[11px]">(Room {p.roomNumber})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono tabular-nums font-bold text-[#202020]">
                        ₹{p.totalIndividualAmount}
                      </span>
                      {isPaid ? (
                        <span className="text-[#10B981] font-extrabold text-[11px] flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" /> Paid
                        </span>
                      ) : (
                        <span className="text-amber-700 font-bold text-[11px] bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                          Pending
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-[#202020]/10 bg-white">
          {allPaid || isAlreadyPaid || !hasUserItems ? (
            <button
              onClick={handlePlaceFinalOrder}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-[#202020] to-[#303030] hover:from-black hover:to-[#202020] active:scale-95 text-white font-heading font-extrabold text-sm rounded-2xl transition-all shadow-md flex items-center justify-center gap-2"
            >
              <span>Dispatch Order to Grains &amp; Gossip Kitchen</span>
              <ArrowRight className="w-4 h-4 text-[#FF7A1A]" />
            </button>
          ) : (
            <div className="text-center text-xs text-[#202020]/60 py-1">
              Complete your payment above to dispatch the order to Grains &amp; Gossip.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
