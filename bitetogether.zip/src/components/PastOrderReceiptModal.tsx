import React, { useState } from 'react';
import { GroupOrder, CartItem, Profile } from '../types';
import {
  X,
  Receipt,
  CheckCircle2,
  Calendar,
  MapPin,
  UtensilsCrossed,
  ShieldCheck,
  CreditCard,
  RotateCcw,
  Copy,
  Check,
  Download,
  Users
} from 'lucide-react';

interface PastOrderReceiptModalProps {
  group: GroupOrder | null;
  isOpen: boolean;
  onClose: () => void;
  onReorder: (group: GroupOrder) => void;
  cartItems: CartItem[];
  currentUser: Profile;
}

export const PastOrderReceiptModal: React.FC<PastOrderReceiptModalProps> = ({
  group,
  isOpen,
  onClose,
  onReorder,
  cartItems,
  currentUser
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !group) return null;

  // Filter items purchased by the current student in this specific group order
  const studentItems = cartItems.filter(
    item => item.groupId === group.id && item.userId === currentUser.id
  );

  // All items in this group order
  const allGroupItems = cartItems.filter(item => item.groupId === group.id);

  // Financial calculations
  const studentSubtotal = studentItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
  const packagingFee = 0; // Transparent zero late-night surcharge
  const studentTotalPaid = studentSubtotal + packagingFee;
  const groupTotalAmount = group.totalAmount || allGroupItems.reduce((s, i) => s + i.price * i.quantity, 0);

  // Late-night solo avoidance savings
  const soloSurchargeAvoided = Math.max(0, 300 - studentSubtotal);

  // Roommates in this group
  const otherRoommates = Array.from(
    new Set(allGroupItems.filter(i => i.userId !== currentUser.id).map(i => `${i.userName} (Rm ${i.roomNumber})`))
  );

  const formattedDate = new Date(group.createdAt).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  const formattedTime = new Date(group.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit'
  });

  const receiptRefId = `REC-T3-GG-${group.code}-${group.cafeTokenNumber || '2849'}`;
  const upiTxnId = `UPI-NPCI-${group.code}-${group.id.slice(-4)}`;

  const handleCopyTextSlip = () => {
    const textSlip = `========================================
BITETOGETHER · TOWER 3 HOSTEL RECEIPT
Cafe: Grains and Gossip
Receipt No: ${receiptRefId}
Date: ${formattedDate} at ${formattedTime}
Token: #${group.cafeTokenNumber || 'GG-2849'}
Pickup: ${group.pickupPoint}
----------------------------------------
STUDENT DETAILS:
Name: ${currentUser.name}
Room: Tower 3, Room ${currentUser.roomNumber}
Student ID: ${currentUser.studentId}
Email: ${currentUser.email}
----------------------------------------
YOUR ITEMIZED ITEMS:
${studentItems.map(i => `- ${i.itemName} (x${i.quantity}) : ₹${i.price * i.quantity}`).join('\n')}
----------------------------------------
Items Subtotal: ₹${studentSubtotal}
Hostel Packing Fee: ₹0
TOTAL PAID BY YOU: ₹${studentTotalPaid}
Payment Method: UPI / QR (Ref: ${upiTxnId})
Status: Paid & Verified
----------------------------------------
GROUP ORDER SUMMARY:
Group: ${group.name} (${group.code})
Combined Group Total: ₹${groupTotalAmount}
Solo Surcharge Avoided: ₹${soloSurchargeAvoided}
========================================`;

    navigator.clipboard?.writeText(textSlip);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#202020]/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-[#202020]/10 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Top Bar */}
        <div className="p-4 sm:p-5 border-b border-[#202020]/10 bg-[#FFF9F3] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#FF7A1A] text-white flex items-center justify-center shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#FF7A1A] uppercase tracking-wider">
                <span>Official Itemized Receipt</span>
                <span className="text-[#202020]/30">·</span>
                <span className="font-mono text-[#202020]/60">{group.code}</span>
              </div>
              <h2 className="font-heading text-lg font-bold text-[#202020]">
                Grains &amp; Gossip Cafe Order
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#202020]/50 hover:text-[#202020] hover:bg-[#202020]/5 rounded-lg transition-colors"
            aria-label="Close receipt modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 text-xs text-[#202020]">
          
          {/* Receipt Top Metadata Banner */}
          <div className="p-4 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-[11px] text-[#202020]/60">
                Receipt #{receiptRefId}
              </span>
              <span className="text-[#10B981] font-semibold text-[11px] flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Fulfilled &amp; Paid
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#202020]/5 text-[11px]">
              <div>
                <span className="text-[#202020]/50 block">Cafe Pickup Token</span>
                <span className="font-mono font-bold text-sm text-[#FF7A1A]">
                  #{group.cafeTokenNumber || 'GG-2849'}
                </span>
              </div>
              <div>
                <span className="text-[#202020]/50 block">Delivered At</span>
                <span className="font-medium text-[#202020] truncate block">
                  {group.pickupPoint}
                </span>
              </div>
              <div>
                <span className="text-[#202020]/50 block">Order Timestamp</span>
                <span className="font-medium text-[#202020]">
                  {formattedDate} · {formattedTime}
                </span>
              </div>
              <div>
                <span className="text-[#202020]/50 block">Hostel Tower</span>
                <span className="font-medium text-[#202020]">
                  Tower 3 Resident Wing
                </span>
              </div>
            </div>
          </div>

          {/* Student Billing Details */}
          <div className="p-3.5 bg-white border border-[#202020]/10 rounded-xl space-y-1">
            <div className="text-[10px] font-semibold text-[#FF7A1A] uppercase tracking-wider">
              Student Billing Identity
            </div>
            <div className="flex items-center justify-between font-semibold text-sm text-[#202020]">
              <span>{currentUser.name}</span>
              <span className="font-mono text-xs font-normal text-[#202020]/70">
                ID: {currentUser.studentId}
              </span>
            </div>
            <div className="text-[11px] text-[#202020]/60">
              Tower 3 · Room {currentUser.roomNumber} · {currentUser.email}
            </div>
          </div>

          {/* ITEM PURCHASED SECTION */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-[#202020]">
              <span className="flex items-center gap-1.5">
                <UtensilsCrossed className="w-3.5 h-3.5 text-[#FF7A1A]" />
                Items Purchased by {currentUser.name}
              </span>
              <span className="font-mono text-[11px] text-[#202020]/60">
                {studentItems.length} item(s) in this order
              </span>
            </div>

            {studentItems.length === 0 ? (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-center">
                <p className="font-medium">
                  You participated in this group order, but did not have personal food items billed in this cart.
                </p>
                <p className="text-[11px] text-amber-800 mt-1">
                  You may have acted as the group coordinator or room host.
                </p>
              </div>
            ) : (
              <div className="border border-[#202020]/10 rounded-xl overflow-hidden divide-y divide-[#202020]/5 bg-white">
                <div className="px-3 py-2 bg-[#FFF9F3] text-[11px] font-semibold text-[#202020]/70 grid grid-cols-12 gap-2">
                  <span className="col-span-7">Item Description</span>
                  <span className="col-span-2 text-center">Qty</span>
                  <span className="col-span-3 text-right">Amount</span>
                </div>

                {studentItems.map(item => (
                  <div
                    key={item.id}
                    className="px-3 py-2.5 grid grid-cols-12 gap-2 items-center hover:bg-[#FFF9F3]/40 transition-colors"
                  >
                    <div className="col-span-7 space-y-0.5">
                      <div className="font-semibold text-xs text-[#202020] leading-snug">
                        {item.itemName}
                      </div>
                      <div className="text-[10px] text-[#202020]/50 font-mono">
                        ₹{item.price} per item
                      </div>
                      {item.specialInstructions && (
                        <div className="text-[10px] text-[#202020]/50 italic">
                          Note: {item.specialInstructions}
                        </div>
                      )}
                    </div>

                    <div className="col-span-2 text-center font-mono font-medium text-xs text-[#202020]">
                      ×{item.quantity}
                    </div>

                    <div className="col-span-3 text-right font-mono tabular-nums font-bold text-xs text-[#202020]">
                      ₹{item.price * item.quantity}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Student Itemized Financial Breakdown */}
          <div className="p-4 bg-[#FFF9F3] border border-[#202020]/10 rounded-xl space-y-2">
            <div className="flex justify-between text-[#202020]/70 text-xs">
              <span>Your Selected Items Subtotal</span>
              <span className="font-mono tabular-nums font-semibold text-[#202020]">
                ₹{studentSubtotal}
              </span>
            </div>

            <div className="flex justify-between text-[#202020]/70 text-xs">
              <span>Hostel Late-Night Packaging &amp; Delivery</span>
              <span className="text-[#10B981] font-semibold">FREE (₹0)</span>
            </div>

            <div className="pt-2 border-t border-[#202020]/10 flex justify-between items-center text-sm font-bold text-[#202020]">
              <div>
                <span>Net Total Paid by You</span>
                <span className="text-[10px] text-[#202020]/50 block font-normal">
                  (Strictly your food, no equal-split burden)
                </span>
              </div>
              <span className="font-mono tabular-nums text-lg text-[#FF7A1A]">
                ₹{studentTotalPaid}
              </span>
            </div>
          </div>

          {/* Group Context & Savings Banner */}
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Tower 3 BiteTogether Pool Benefit</span>
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              By pooling into &quot;{group.name}&quot; (combined group total: <strong className="font-mono">₹{groupTotalAmount}</strong>), you avoided Grains &amp; Gossip&apos;s ₹300 solo order constraint and saved <strong className="font-mono">₹{soloSurchargeAvoided}</strong>!
            </p>
            {otherRoommates.length > 0 && (
              <div className="text-[10px] text-emerald-700 pt-1 border-t border-emerald-200/60 flex items-center gap-1">
                <Users className="w-3 h-3 shrink-0" />
                <span className="truncate">Pooled with: {otherRoommates.join(', ')}</span>
              </div>
            )}
          </div>

          {/* Payment Proof Details */}
          <div className="p-3.5 bg-white border border-[#202020]/10 rounded-xl space-y-1 text-[11px] text-[#202020]/70">
            <div className="font-semibold text-xs text-[#202020] flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-[#FF7A1A]" />
              Payment Verification Record
            </div>
            <div className="flex justify-between pt-1">
              <span>Payment Mode:</span>
              <span className="font-medium text-[#202020]">UPI / QR (Instant Settlement)</span>
            </div>
            <div className="flex justify-between">
              <span>Transaction Ref:</span>
              <span className="font-mono text-[#202020]">{upiTxnId}</span>
            </div>
            <div className="flex justify-between">
              <span>Status:</span>
              <span className="text-[#10B981] font-medium">Completed &amp; Settled to Cafe Merchant</span>
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-[#202020]/10 bg-white flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleCopyTextSlip}
            className="w-full sm:w-auto px-3.5 py-2 bg-[#FFF9F3] hover:bg-[#202020]/5 border border-[#202020]/15 rounded-xl text-xs font-semibold text-[#202020] transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Receipt Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#202020]/60" />
                <span>Copy Receipt Summary</span>
              </>
            )}
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2">
            {studentItems.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  onReorder(group);
                  onClose();
                }}
                className="flex-1 sm:flex-initial px-4 py-2 bg-[#FF7A1A] hover:bg-[#e86b12] text-white rounded-xl text-xs font-heading font-bold transition-all shadow-md flex items-center justify-center gap-1.5 ring-2 ring-[#FF7A1A]/20"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reorder Items (₹{studentTotalPaid})</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#202020] hover:bg-[#333] text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Done
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
