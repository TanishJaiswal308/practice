import { Profile, GroupOrder, GroupParticipant, CartItem, Notification, OrderStatusHistory } from '../types';

export const DEMO_USERS: Profile[] = [
  {
    id: 'u-rohan',
    name: 'Rohan Verma',
    studentId: '2023CSB1042',
    email: 'rohan.v@hostel.edu',
    hostelTower: 'Tower 3',
    roomNumber: '314',
    phone: '+91 98765 43210',
    createdAt: '2026-09-01T10:00:00Z'
  },
  {
    id: 'u-priya',
    name: 'Priya Nair',
    studentId: '2024DES0819',
    email: 'priya.n@hostel.edu',
    hostelTower: 'Tower 3',
    roomNumber: '302',
    phone: '+91 98765 12345',
    createdAt: '2026-09-01T11:00:00Z'
  },
  {
    id: 'u-aryan',
    name: 'Aryan Sharma',
    studentId: '2023EEB1104',
    email: 'aryan.s@hostel.edu',
    hostelTower: 'Tower 3',
    roomNumber: '314',
    phone: '+91 98765 67890',
    createdAt: '2026-09-01T12:00:00Z'
  },
  {
    id: 'u-tanvi',
    name: 'Tanvi Gupta',
    studentId: '2022MEB0941',
    email: 'tanvi.g@hostel.edu',
    hostelTower: 'Tower 3',
    roomNumber: '320',
    phone: '+91 98765 99887',
    createdAt: '2026-09-01T13:00:00Z'
  },
  {
    id: 'u-kabir',
    name: 'Kabir Mehta',
    studentId: '2025ECO0412',
    email: 'kabir.m@hostel.edu',
    hostelTower: 'Tower 3',
    roomNumber: '308',
    phone: '+91 98765 55443',
    createdAt: '2026-09-01T14:00:00Z'
  }
];

export const INITIAL_GROUPS: GroupOrder[] = [
  {
    id: 'g-active-1',
    code: 'T3-MUNCH',
    name: 'Floor 3 Post-Mess Munchies',
    cafeName: 'Grains and Gossip',
    creatorId: 'u-rohan',
    creatorName: 'Rohan Verma',
    creatorRoom: '314',
    deadline: new Date(Date.now() + 28 * 60 * 1000).toISOString(), // 28 minutes left
    participantLimit: 6,
    status: 'collecting',
    minThreshold: 300,
    totalAmount: 218, // ₹82 to go!
    pickupPoint: 'Tower 3 Ground Security Desk',
    createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    estimatedDeliveryMins: 25
  },
  {
    id: 'g-active-2',
    code: 'T3-NIGHT',
    name: 'Midnight Caffeine & Brownie Run',
    cafeName: 'Grains and Gossip',
    creatorId: 'u-tanvi',
    creatorName: 'Tanvi Gupta',
    creatorRoom: '320',
    deadline: new Date(Date.now() + 45 * 60 * 1000).toISOString(),
    participantLimit: 4,
    status: 'threshold_met',
    minThreshold: 300,
    totalAmount: 347, // Threshold exceeded!
    pickupPoint: 'Tower 3 Floor 3 Lounge',
    createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    estimatedDeliveryMins: 30
  },
  {
    id: 'g-past-1',
    code: 'T3-YESTER',
    name: 'Study Jam Late Night Bites',
    cafeName: 'Grains and Gossip',
    creatorId: 'u-aryan',
    creatorName: 'Aryan Sharma',
    creatorRoom: '314',
    deadline: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
    status: 'completed',
    minThreshold: 300,
    totalAmount: 446,
    pickupPoint: 'Tower 3 Ground Security Desk',
    createdAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString(),
    cafeTokenNumber: 'GG-2849',
    estimatedDeliveryMins: 25
  },
  {
    id: 'g-past-2',
    code: 'T3-HACK',
    name: 'Midsem Hackathon Fuel',
    cafeName: 'Grains and Gossip',
    creatorId: 'u-rohan',
    creatorName: 'Rohan Verma',
    creatorRoom: '314',
    deadline: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    status: 'completed',
    minThreshold: 300,
    totalAmount: 366,
    pickupPoint: 'Tower 3 Floor 3 Lounge',
    createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000 - 30 * 60 * 1000).toISOString(),
    cafeTokenNumber: 'GG-2710',
    estimatedDeliveryMins: 25
  },
  {
    id: 'g-past-3',
    code: 'T3-MATCH',
    name: 'Weekend Match Screening Snacks',
    cafeName: 'Grains and Gossip',
    creatorId: 'u-priya',
    creatorName: 'Priya Nair',
    creatorRoom: '302',
    deadline: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    status: 'completed',
    minThreshold: 300,
    totalAmount: 636,
    pickupPoint: 'Tower 3 Ground Security Desk',
    createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000 - 45 * 60 * 1000).toISOString(),
    cafeTokenNumber: 'GG-2598',
    estimatedDeliveryMins: 30
  }
];

export const INITIAL_PARTICIPANTS: GroupParticipant[] = [
  // Group 1
  {
    id: 'p-1',
    groupId: 'g-active-1',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 0
  },
  {
    id: 'p-2',
    groupId: 'g-active-1',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    joinedAt: new Date(Date.now() - 12 * 60 * 1000).toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 119
  },
  {
    id: 'p-3',
    groupId: 'g-active-1',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 99
  },

  // Group 2
  {
    id: 'p-4',
    groupId: 'g-active-2',
    userId: 'u-tanvi',
    userName: 'Tanvi Gupta',
    roomNumber: '320',
    joinedAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 268
  },
  {
    id: 'p-5',
    groupId: 'g-active-2',
    userId: 'u-kabir',
    userName: 'Kabir Mehta',
    roomNumber: '308',
    joinedAt: new Date(Date.now() - 18 * 60 * 1000).toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 79
  },

  // Past Group 1: Study Jam (Rohan, Aryan, Priya)
  {
    id: 'p-p1-1',
    groupId: 'g-past-1',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 228
  },
  {
    id: 'p-p1-2',
    groupId: 'g-past-1',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 99
  },
  {
    id: 'p-p1-3',
    groupId: 'g-past-1',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    joinedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 119
  },

  // Past Group 2: Hackathon Fuel (Rohan, Tanvi, Kabir)
  {
    id: 'p-p2-1',
    groupId: 'g-past-2',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 188
  },
  {
    id: 'p-p2-2',
    groupId: 'g-past-2',
    userId: 'u-tanvi',
    userName: 'Tanvi Gupta',
    roomNumber: '320',
    joinedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 119
  },
  {
    id: 'p-p2-3',
    groupId: 'g-past-2',
    userId: 'u-kabir',
    userName: 'Kabir Mehta',
    roomNumber: '308',
    joinedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 59
  },

  // Past Group 3: Weekend Match (Priya, Tanvi, Rohan, Aryan)
  {
    id: 'p-p3-1',
    groupId: 'g-past-3',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    joinedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 199
  },
  {
    id: 'p-p3-2',
    groupId: 'g-past-3',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 288
  },
  {
    id: 'p-p3-3',
    groupId: 'g-past-3',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    joinedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
    paymentStatus: 'paid',
    totalIndividualAmount: 149
  }
];

export const INITIAL_CART_ITEMS: CartItem[] = [
  // Group 1: Priya has 1 Paneer Tikka Sandwich (₹119)
  {
    id: 'ci-1',
    groupId: 'g-active-1',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    menuItemId: 'gg-sw-1',
    itemName: 'PANEER TIKKA SANDWICH',
    price: 119,
    quantity: 1,
    specialInstructions: 'Extra grilled and mint chutney please',
    addedAt: new Date(Date.now() - 11 * 60 * 1000).toISOString()
  },
  // Group 1: Aryan has Honey Chilli Potato (₹99)
  {
    id: 'ci-2',
    groupId: 'g-active-1',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    menuItemId: 'gg-vs-2',
    itemName: 'HONEY CHILLI POTATO',
    price: 99,
    quantity: 1,
    addedAt: new Date(Date.now() - 7 * 60 * 1000).toISOString()
  },

  // Group 2: Tanvi has Brownie Milk Shake + Juicy Cheese Burger
  {
    id: 'ci-3',
    groupId: 'g-active-2',
    userId: 'u-tanvi',
    userName: 'Tanvi Gupta',
    roomNumber: '320',
    menuItemId: 'gg-bev-5',
    itemName: 'BROWNIE MILK SHAKE',
    price: 129,
    quantity: 1,
    addedAt: new Date(Date.now() - 22 * 60 * 1000).toISOString()
  },
  {
    id: 'ci-4',
    groupId: 'g-active-2',
    userId: 'u-tanvi',
    userName: 'Tanvi Gupta',
    roomNumber: '320',
    menuItemId: 'gg-bg-2',
    itemName: 'JUICY CHEESE BURGER',
    price: 139,
    quantity: 1,
    addedAt: new Date(Date.now() - 20 * 60 * 1000).toISOString()
  },
  {
    id: 'ci-5',
    groupId: 'g-active-2',
    userId: 'u-kabir',
    userName: 'Kabir Mehta',
    roomNumber: '308',
    menuItemId: 'gg-sd-2',
    itemName: 'PERI PERI FRIES',
    price: 79,
    quantity: 1,
    addedAt: new Date(Date.now() - 17 * 60 * 1000).toISOString()
  },

  // PAST ORDER 1 ITEMS (Total: ₹446)
  {
    id: 'ci-p1-1',
    groupId: 'g-past-1',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-bg-2',
    itemName: 'JUICY CHEESE BURGER',
    price: 139,
    quantity: 1,
    addedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p1-2',
    groupId: 'g-past-1',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-bev-4',
    itemName: 'PINEAPPLE JUICE',
    price: 89,
    quantity: 1,
    addedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p1-3',
    groupId: 'g-past-1',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    menuItemId: 'gg-sd-3',
    itemName: 'CHEESE FRIES',
    price: 99,
    quantity: 1,
    addedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p1-4',
    groupId: 'g-past-1',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    menuItemId: 'gg-sw-1',
    itemName: 'PANEER TIKKA SANDWICH',
    price: 119,
    quantity: 1,
    addedAt: new Date(Date.now() - 25 * 3600 * 1000).toISOString()
  },

  // PAST ORDER 2 ITEMS (Total: ₹366)
  {
    id: 'ci-p2-1',
    groupId: 'g-past-2',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-rn-1',
    itemName: 'BURNED CHILLY GARLIC FRIED RICE / NOODLES',
    price: 159,
    quantity: 1,
    addedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p2-2',
    groupId: 'g-past-2',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-hot-3',
    itemName: 'MASALA TEA',
    price: 29,
    quantity: 1,
    addedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p2-3',
    groupId: 'g-past-2',
    userId: 'u-tanvi',
    userName: 'Tanvi Gupta',
    roomNumber: '320',
    menuItemId: 'gg-vs-1',
    itemName: 'CHILLI PANEER',
    price: 119,
    quantity: 1,
    addedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p2-4',
    groupId: 'g-past-2',
    userId: 'u-kabir',
    userName: 'Kabir Mehta',
    roomNumber: '308',
    menuItemId: 'gg-bev-1',
    itemName: 'WATER MELON JUICE',
    price: 59,
    quantity: 1,
    addedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
  },

  // PAST ORDER 3 ITEMS (Total: ₹636)
  {
    id: 'ci-p3-1',
    groupId: 'g-past-3',
    userId: 'u-priya',
    userName: 'Priya Nair',
    roomNumber: '302',
    menuItemId: 'gg-pz-2',
    itemName: 'MARGARITTA 8" PIZZA',
    price: 199,
    quantity: 1,
    addedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p3-2',
    groupId: 'g-past-3',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-bg-3',
    itemName: 'JUICY CHICKEN BURGER',
    price: 159,
    quantity: 1,
    addedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p3-3',
    groupId: 'g-past-3',
    userId: 'u-rohan',
    userName: 'Rohan Verma',
    roomNumber: '314',
    menuItemId: 'gg-bev-5',
    itemName: 'BROWNIE MILK SHAKE',
    price: 129,
    quantity: 1,
    addedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
  },
  {
    id: 'ci-p3-4',
    groupId: 'g-past-3',
    userId: 'u-aryan',
    userName: 'Aryan Sharma',
    roomNumber: '314',
    menuItemId: 'gg-nvs-3',
    itemName: 'PERI PERI CHICKEN POP CORN',
    price: 149,
    quantity: 1,
    addedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'n-1',
    userId: 'u-rohan',
    groupId: 'g-active-1',
    title: 'Aryan joined your group!',
    message: 'Aryan (Room 314) added Honey Chilli Potato (₹99). Current group total: ₹218.',
    type: 'food_added',
    isRead: false,
    createdAt: new Date(Date.now() - 7 * 60 * 1000).toISOString()
  },
  {
    id: 'n-2',
    userId: 'u-rohan',
    groupId: 'g-active-1',
    title: '₹82 remaining to unlock checkout',
    message: 'Only ₹82 needed to reach Grains & Gossip ₹300 minimum threshold.',
    type: 'info',
    isRead: true,
    createdAt: new Date(Date.now() - 10 * 60 * 1000).toISOString()
  },
  {
    id: 'n-3',
    userId: 'u-rohan',
    groupId: 'g-past-1',
    title: 'Food picked up yesterday',
    message: 'Order #GG-2849 was picked up by Aryan at Ground Security Desk.',
    type: 'food_ready',
    isRead: true,
    createdAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString()
  }
];

export const INITIAL_STATUS_HISTORY: OrderStatusHistory[] = [
  {
    id: 'sh-1',
    groupId: 'g-active-1',
    status: 'collecting',
    note: 'Group created by Rohan (Room 314). Waiting for items to reach ₹300 minimum threshold.',
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString()
  },
  {
    id: 'sh-2',
    groupId: 'g-active-2',
    status: 'threshold_met',
    note: 'Minimum threshold ₹300 achieved (Total: ₹323). Checkout is now unlocked for all members.',
    timestamp: new Date(Date.now() - 16 * 60 * 1000).toISOString()
  }
];
