import { MenuItem } from '../types';

export const OFFICIAL_MENU_NOTICE = {
  cafeName: 'Grains & Gossip',
  phone: '+91 99809 25507',
  deliveryTimings: '9:30 PM – 3:00 AM',
  minimumOrderValue: 350,
  packingChargesPerContainer: 10,
  deliveryCharges: 'Free',
  deliveryLocation: 'Hostel Reception, Staff Quarters & villas',
  estimatedDeliveryTime: 'Minimum 30 minutes',
  flyerImagePath: '/assets/aistudio/WhatsApp_Image_2026-11-05_at_10.19.47_PM_f4b7063d.jpeg'
};

export const GRAINS_AND_GOSSIP_MENU: MenuItem[] = [
  // ==========================================
  // RICE / NOODLES (VEG)
  // ==========================================
  {
    id: 'gg-rn-1',
    name: 'BURNED CHILLY GARLIC FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Veg)',
    description: 'Wok-tossed rice or noodles with crisp golden burnt garlic, green chilies, bell peppers, and scallions.',
    price: 159,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Hostel Bestseller', 'Wok Tossed']
  },
  {
    id: 'gg-rn-2',
    name: 'CORN & BELL PEPPER RICE/NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Veg)',
    description: 'Sweet golden corn kernels, crunchy tri-color bell peppers, wok-tossed with aromatic herbs.',
    price: 159,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Mild & Crispy']
  },
  {
    id: 'gg-rn-3',
    name: 'PANEER FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Veg)',
    description: 'Tender cottage cheese cubes tossed with oriental spices, fragrant basmati rice or hakka noodles.',
    price: 169,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['High Protein Veg']
  },
  {
    id: 'gg-rn-4',
    name: 'SCHEZWAN FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Veg)',
    description: 'Fiery in-house red schezwan chili paste wok-fried with crisp garden vegetables and spring onions.',
    price: 159,
    isVeg: true,
    spicyLevel: 3,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Spicy']
  },

  // ==========================================
  // RICE / NOODLES (NON VEG)
  // ==========================================
  {
    id: 'gg-rn-5',
    name: 'CHILLY GARLIC EGG FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Fluffy scrambled eggs wok-tossed with roasted burnt garlic and crushed hot chili peppers.',
    price: 179,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Egg Special']
  },
  {
    id: 'gg-rn-6',
    name: 'SCHEZWAN EGG FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Spicy wok-fried egg rice or noodles infused with authentic Sichuan pepper and chili sauce.',
    price: 179,
    isVeg: false,
    spicyLevel: 3,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Spicy Egg']
  },
  {
    id: 'gg-rn-7',
    name: 'STIR FRIED EGG RICE/NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Classic mild seasoned stir-fried egg and diced veggies tossed in light soy and sesame oil.',
    price: 179,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Classic']
  },
  {
    id: 'gg-rn-8',
    name: 'CHILLY GARLIC CHICKEN FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Juicy spiced shredded chicken, charred garlic, and crushed red chilies tossed on high flame.',
    price: 209,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Student Favorite']
  },
  {
    id: 'gg-rn-9',
    name: 'SCHEZWAN CHICKEN FRIED RICE / NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Tender chicken pieces and crisp veggies tossed in spicy, tangy homemade Schezwan sauce.',
    price: 209,
    isVeg: false,
    spicyLevel: 3,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Chef Pick']
  },
  {
    id: 'gg-rn-10',
    name: 'STIR FRIED CHICKEN RICE/NOODLES',
    category: 'rice_noodles',
    subCategory: 'Rice / Noodles (Non Veg)',
    description: 'Golden chicken chunks stir-fried with seasonal vegetables and premium soy seasoning.',
    price: 209,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Non-Spicy Chicken']
  },

  // ==========================================
  // VEG BURGERS
  // ==========================================
  {
    id: 'gg-bg-1',
    name: 'CLASSIC VEG BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Veg)',
    description: 'Crispy herb potato patty, sliced tomatoes, onions, crunchy iceberg lettuce, and cafe mayo in a soft bun.',
    price: 119,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 12,
    tags: ['Value Bite']
  },
  {
    id: 'gg-bg-2',
    name: 'JUICY CHEESE BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Veg)',
    description: 'Crispy veggie patty blanketed with melted yellow cheddar cheese slice, caramelized onion relish, and secret sauce.',
    price: 139,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 12,
    tags: ['Top Rated']
  },

  // ==========================================
  // NON VEG BURGERS
  // ==========================================
  {
    id: 'gg-bg-3',
    name: 'JUICY CHICKEN BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Non Veg)',
    description: 'Tender seasoned chicken patty grilled to juicy perfection with lettuce, sliced pickles, and spicy cafe sauce.',
    price: 159,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Must Try']
  },
  {
    id: 'gg-bg-4',
    name: 'BBQ CHICKEN BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Non Veg)',
    description: 'Grilled chicken patty glazed in smoky hickory BBQ sauce with caramelized red onions and lettuce.',
    price: 169,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Smoky BBQ']
  },
  {
    id: 'gg-bg-5',
    name: 'CHICKEN CHEESE BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Non Veg)',
    description: 'Savory chicken patty layered with melted cheese, creamy garlic dressing, and crisp garden toppings.',
    price: 169,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Cheese Melt']
  },
  {
    id: 'gg-bg-6',
    name: 'GRILLED CHICKEN BURGER',
    category: 'burgers',
    subCategory: 'Burgers (Non Veg)',
    description: 'Herb-marinated whole chicken breast grilled on fire, served with dijonnaise and crisp lettuce on a toasted bun.',
    price: 169,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_artisan_burger_1793732218667.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Flame Grilled']
  },

  // ==========================================
  // VEG PIZZAS
  // ==========================================
  {
    id: 'gg-pz-1',
    name: 'SPICY PANNER TIKKA PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Veg)',
    description: 'Tandoori-marinated paneer chunks, sliced red onions, green bell peppers, and mozzarella with tikka sauce.',
    price: 269,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Hostel Hit']
  },
  {
    id: 'gg-pz-2',
    name: 'MARGARITTA',
    category: 'pizza',
    subCategory: 'Pizzas (Veg)',
    description: 'Classic Italian style tomato herb reduction, melted bubbly mozzarella, olive oil drizzle, and fresh basil.',
    price: 199,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Classic Italian', 'Under ₹200']
  },
  {
    id: 'gg-pz-3',
    name: 'GARDEN FRESH CLASSIC PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Veg)',
    description: 'Crisp bell peppers, sweet corn, black olives, sliced onions, and juicy tomatoes with mozzarella blend.',
    price: 269,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Loaded Veg']
  },
  {
    id: 'gg-pz-4',
    name: 'CHEESE CORN PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Veg)',
    description: 'Sweet American corn, generous mozzarella and cheddar blend, and aromatic Italian herbs.',
    price: 259,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Kids & Students']
  },
  {
    id: 'gg-pz-5',
    name: 'VEG CHEESE GARLIC PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Veg)',
    description: 'Roasted garlic butter base, double cheese blend, diced peppers, and oregano flakes.',
    price: 229,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Garlic Lovers']
  },

  // ==========================================
  // NON VEG PIZZAS
  // ==========================================
  {
    id: 'gg-pz-6',
    name: 'DESI CHICKEN TIKKA PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Non Veg)',
    description: 'Spicy roasted chicken tikka cubes, red onion rings, capsicum, and stringy melted mozzarella cheese.',
    price: 349,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 20,
    tags: ['Bestseller']
  },
  {
    id: 'gg-pz-7',
    name: 'BBQ CHICKEN PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Non Veg)',
    description: 'Hickory smoked BBQ chicken, sweet caramelized onions, roasted peppers, and blend of mozzarella & gouda.',
    price: 349,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 20,
    tags: ['Smoky Delight']
  },
  {
    id: 'gg-pz-8',
    name: 'GRILLED CHICKEN PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Non Veg)',
    description: 'Tender herb grilled chicken, sun-ripened tomatoes, jalapenos, and mozzarella on stone-baked crust.',
    price: 369,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 20,
    tags: ['Chef Signature']
  },
  {
    id: 'gg-pz-9',
    name: 'PERI PERI CHICKEN PIZZA',
    category: 'pizza',
    subCategory: 'Pizzas (Non Veg)',
    description: 'Fiery bird’s eye peri-peri spiced chicken, sliced paprika, red chilies, and melted cheese.',
    price: 359,
    isVeg: false,
    spicyLevel: 3,
    imageUrl: '/src/assets/images/menu_woodfired_pizza_1793733551264.jpg',
    available: true,
    preparationTimeMins: 20,
    tags: ['Extra Spicy']
  },

  // ==========================================
  // VEG SANDWICHES
  // ==========================================
  {
    id: 'gg-sw-1',
    name: 'PANEER TIKKA SANDWICH',
    category: 'sandwiches',
    subCategory: 'Sandwiches (Veg)',
    description: 'Spiced cottage cheese tikka cubes, mint mayo, crunchy capsicum and onions in toasted bread.',
    price: 119,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/menu_grilled_sandwich_1793732219426.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Under ₹120']
  },
  {
    id: 'gg-sw-2',
    name: 'JUICY VEG CHEESE SANWICH',
    category: 'sandwiches',
    subCategory: 'Sandwiches (Veg)',
    description: 'Triple layer toasted sandwich loaded with sliced cucumbers, tomatoes, bell peppers, and melted cheese.',
    price: 119,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_grilled_sandwich_1793732219426.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Cheesy Classic']
  },
  {
    id: 'gg-sw-3',
    name: 'GRILLED VEG SANDWICH',
    category: 'sandwiches',
    subCategory: 'Sandwiches (Veg)',
    description: 'Golden grill-pressed sandwich with spiced veggie filling, tangy mint chutney, and butter.',
    price: 119,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/menu_grilled_sandwich_1793732219426.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Crispy Grill']
  },

  // ==========================================
  // NON VEG SANDWICHES
  // ==========================================
  {
    id: 'gg-sw-4',
    name: 'EGG MAYO SANDWICH',
    category: 'sandwiches',
    subCategory: 'Sandwiches (Non Veg)',
    description: 'Boiled eggs mashed with creamy black pepper mayo, crisp lettuce, and butter in soft toasted slices.',
    price: 119,
    isVeg: false,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_grilled_sandwich_1793732219426.jpg',
    available: true,
    preparationTimeMins: 8,
    tags: ['Protein Breakfast & Late Night']
  },
  {
    id: 'gg-sw-5',
    name: 'DESI CHICKEN TIKKA S/W',
    category: 'sandwiches',
    subCategory: 'Sandwiches (Non Veg)',
    description: 'Flavorsome tandoori spiced chicken pieces, pickled onions, and spicy coriander mayo grilled crisp.',
    price: 159,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/menu_grilled_sandwich_1793732219426.jpg',
    available: true,
    preparationTimeMins: 12,
    tags: ['Desi Flavor']
  },

  // ==========================================
  // VEG FRIES & NACHOS / SIDES
  // ==========================================
  {
    id: 'gg-sd-1',
    name: 'FRENCH FRIES',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Crispy salted golden potato french fries served hot with cafe dipping sauce.',
    price: 69,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_loaded_truffle_fries_1793733551201.jpg',
    available: true,
    preparationTimeMins: 8,
    tags: ['Budget Pick', 'Under ₹70']
  },
  {
    id: 'gg-sd-2',
    name: 'PERI PERI FRIES',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Golden fries generously dusted with spicy African peri-peri chili seasoning.',
    price: 79,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/menu_loaded_truffle_fries_1793733551201.jpg',
    available: true,
    preparationTimeMins: 8,
    tags: ['Hostel Bestseller']
  },
  {
    id: 'gg-sd-3',
    name: 'CHEESE FRIES',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Hot crispy fries smothered in creamy melted cheddar cheese sauce.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_loaded_truffle_fries_1793733551201.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Cheesy Craving']
  },
  {
    id: 'gg-sd-4',
    name: 'NACHOS',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Crunchy golden corn tortilla nachos served with zesty salsa dip.',
    price: 119,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 6,
    tags: ['Crunchy']
  },
  {
    id: 'gg-sd-5',
    name: 'CHEESEY NACHOS',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Loaded corn nachos drenched in hot creamy cheese sauce and topped with salsa & jalapenos.',
    price: 129,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 8,
    tags: ['Party Favorite']
  },
  {
    id: 'gg-sd-6',
    name: 'POTATO WEDGES',
    category: 'starters_sides',
    subCategory: 'Fries & Nachos (Veg)',
    description: 'Thick herb-seasoned crispy potato wedges served with seasoned garlic mayo dip.',
    price: 79,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 8,
    tags: ['Rustic Potato']
  },

  // ==========================================
  // VEG STARTERS
  // ==========================================
  {
    id: 'gg-vs-1',
    name: 'CHILLI PANEER',
    category: 'starters_sides',
    subCategory: 'Veg Starters',
    description: 'Crisp batter-fried cottage cheese cubes tossed in spicy soy-chili sauce with capsicum and onions.',
    price: 119,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 12,
    tags: ['Indo-Chinese']
  },
  {
    id: 'gg-vs-2',
    name: 'HONEY CHILLI POTATO',
    category: 'starters_sides',
    subCategory: 'Veg Starters',
    description: 'Crisp fried potato fingers glazed in sweet honey, hot chili garlic sauce, and toasted sesame seeds.',
    price: 99,
    isVeg: true,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Sweet & Spicy']
  },
  {
    id: 'gg-vs-3',
    name: 'CHEESE CORN NUGGEST',
    category: 'starters_sides',
    subCategory: 'Veg Starters',
    description: 'Golden crispy fried nuggets with molten cheese and sweet corn center.',
    price: 109,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Molten Cheese']
  },
  {
    id: 'gg-vs-4',
    name: 'CHEESE CORN FINGER',
    category: 'starters_sides',
    subCategory: 'Veg Starters',
    description: 'Breadcrumb-crusted crunchy fingers stuffed with melting cheese, herbs, and sweet corn.',
    price: 109,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Snack Pick']
  },

  // ==========================================
  // NON VEG STARTERS
  // ==========================================
  {
    id: 'gg-nvs-1',
    name: 'CHICKEN NUGGETS',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Juicy tender minced chicken bites coated in crispy breadcrumbs, served with cafe dip.',
    price: 149,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Classic Bites']
  },
  {
    id: 'gg-nvs-2',
    name: 'GOSSIP FRIED CHICKEN',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Chef special ultra-crispy southern style marinated fried chicken with secret spice rub.',
    price: 149,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Cafe Special']
  },
  {
    id: 'gg-nvs-3',
    name: 'PERI PERI CHICKEN POP CORN',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Bite-sized crunchy chicken poppers tossed in hot peri-peri seasoning. Perfect late-night study munchies.',
    price: 149,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 10,
    tags: ['Study Fuel']
  },
  {
    id: 'gg-nvs-4',
    name: 'BBQ CHICKEN WINGS',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Crispy fried wings tossed in rich smoky barbecue glaze, sprinkled with sesame.',
    price: 159,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Smoky Wings']
  },
  {
    id: 'gg-nvs-5',
    name: 'CHICKEN LOLIPOP',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Crispy frenched chicken drumettes marinated in spicy Chinese sauces and fried crisp.',
    price: 159,
    isVeg: false,
    spicyLevel: 2,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Hostel Classic']
  },
  {
    id: 'gg-nvs-6',
    name: 'MASALA OMLETTE',
    category: 'starters_sides',
    subCategory: 'Non Veg Starters',
    description: 'Double egg fluffy omelette folded with chopped onions, green chilies, coriander, and Indian spices.',
    price: 59,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 6,
    tags: ['Late Night Comfort', 'Under ₹60']
  },

  // ==========================================
  // PASTA
  // ==========================================
  {
    id: 'gg-pa-1',
    name: 'VEG PASTA IN WHITE AND RED SAUCE',
    category: 'pasta',
    subCategory: 'Pasta',
    description: 'Penne pasta tossed in pink blend of rich creamy bechamel & tangy Italian pomodoro with garden veggies.',
    price: 169,
    isVeg: true,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 15,
    tags: ['Creamy & Tangy']
  },
  {
    id: 'gg-pa-2',
    name: 'CHICKEN PASTA IN WHITE AND RED SAUCE',
    category: 'pasta',
    subCategory: 'Pasta',
    description: 'Tender chicken cubes and penne pasta simmered in creamy mixed sauce with herbs and parmesan.',
    price: 209,
    isVeg: false,
    spicyLevel: 1,
    imageUrl: '/src/assets/images/hero_cafe_spread_1793732218121.jpg',
    available: true,
    preparationTimeMins: 18,
    tags: ['Italian Comfort']
  },

  // ==========================================
  // FRESH JUICY JOY (BEVERAGES & SHAKES)
  // ==========================================
  {
    id: 'gg-bev-1',
    name: 'WATER MELON JUICE',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Cold-pressed fresh watermelon juice, light, hydrating, and naturally refreshing.',
    price: 59,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 4,
    tags: ['Fresh Juice', 'Under ₹60']
  },
  {
    id: 'gg-bev-2',
    name: 'FRESH LIME',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Zesty squeezed lemon with water/soda, mint leaves, and sweet or salted touch.',
    price: 39,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 3,
    tags: ['Refreshing', 'Lowest Price']
  },
  {
    id: 'gg-bev-3',
    name: 'APPLE JUICE',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Pure chilled juice pressed from crisp apples with no added preservatives.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 4,
    tags: ['Pure Juice']
  },
  {
    id: 'gg-bev-4',
    name: 'PINEAPPLE',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Fresh tropical pineapple juice with a sweet-tangy punch and pinch of chaat masala.',
    price: 89,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 4,
    tags: ['Tropical']
  },
  {
    id: 'gg-bev-5',
    name: 'BROWNIE MILK SHAKE',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Decadent chocolate brownie blended with rich whole milk, chocolate ice cream, and chocolate fudge.',
    price: 129,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 5,
    tags: ['Thick Shake', 'Dessert Shake']
  },
  {
    id: 'gg-bev-6',
    name: 'CHOCOLATE MILK SHAKE',
    category: 'beverages',
    subCategory: 'Fresh Juicy Joy',
    description: 'Creamy cold chocolate shake with rich cocoa and chocolate drizzle.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 4,
    tags: ['Classic Shake']
  },

  // ==========================================
  // PICK-ME-UP (HOT BEVERAGES & COFFEE)
  // ==========================================
  {
    id: 'gg-hot-1',
    name: 'CAPPACINO',
    category: 'beverages',
    subCategory: 'Pick-Me-Up',
    description: 'Freshly brewed espresso shot topped with equal parts steamed milk and thick velvety micro-foam.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 5,
    tags: ['Caffeine Kick']
  },
  {
    id: 'gg-hot-2',
    name: 'CAFE LATE',
    category: 'beverages',
    subCategory: 'Pick-Me-Up',
    description: 'Smooth double espresso shot poured into silky steamed milk with a delicate foam layer.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 5,
    tags: ['Smooth Coffee']
  },
  {
    id: 'gg-hot-3',
    name: 'MASALA TEA',
    category: 'beverages',
    subCategory: 'Pick-Me-Up',
    description: 'Freshly boiled Assam tea infused with crushed ginger, cardamom, cloves, and milk.',
    price: 29,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 4,
    tags: ['Hostel Life Essential', '₹29 Only']
  },
  {
    id: 'gg-hot-4',
    name: 'HOT CHOCOLATE COFFE',
    category: 'beverages',
    subCategory: 'Pick-Me-Up',
    description: 'Rich Belgian hot cocoa blended with an espresso shot (Mocha style) topped with chocolate dust.',
    price: 99,
    isVeg: true,
    spicyLevel: 0,
    imageUrl: '/src/assets/images/menu_chilled_beverages_1793732219280.jpg',
    available: true,
    preparationTimeMins: 5,
    tags: ['Late Night Comfort']
  }
];
