import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { RoommateSwitcher } from './components/RoommateSwitcher';
import { LateNightBanner } from './components/LateNightBanner';
import { HomeView } from './components/HomeView';
import { GroupsView } from './components/GroupsView';
import { MenuView } from './components/MenuView';
import { OrderTrackerView } from './components/OrderTrackerView';
import { StudentDashboard } from './components/StudentDashboard';
import { SharedCartDrawer } from './components/SharedCartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { CreateGroupModal } from './components/CreateGroupModal';
import { Tower3AuthModal } from './components/Tower3AuthModal';
import { NotificationsModal } from './components/NotificationsModal';

const AppContent: React.FC = () => {
  const { currentTab, setCurrentTab } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#FFF9F3] text-[#202020] selection:bg-[#FF7A1A]/20 selection:text-[#FF7A1A]">
      {/* Roommate Switcher Prototype Bar */}
      <RoommateSwitcher />

      {/* Primary Top Bar Contract */}
      <Header />

      {/* Contextual Late-Night Mess Closure Alert */}
      <LateNightBanner />

      {/* Main Tab Content */}
      <main className="flex-1">
        {currentTab === 'home' && <HomeView />}
        {currentTab === 'groups' && <GroupsView />}
        {currentTab === 'menu' && <MenuView />}
        {currentTab === 'tracking' && <OrderTrackerView />}
        {currentTab === 'dashboard' && <StudentDashboard />}
      </main>

      {/* Modals & Slide-over Panels */}
      <SharedCartDrawer />
      <CheckoutModal />
      <CreateGroupModal />
      <Tower3AuthModal />
      <NotificationsModal />

      {/* Footer (Anti-slop compliant: quiet, truthful, no fake engines) */}
      <footer className="bg-white border-t border-[#202020]/10 py-8 px-4 text-xs text-[#202020]/60">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-heading font-bold text-sm text-[#202020]">BiteTogether</span>
            <span>·</span>
            <span>Tower 3 Hostel Exclusive</span>
            <span>·</span>
            <span>Grains &amp; Gossip Late-Night Hub</span>
          </div>

          <div className="flex items-center gap-4 text-[#202020]/75">
            <button
              onClick={() => setCurrentTab('home')}
              className="hover:text-[#FF7A1A] transition-colors"
            >
              Explore
            </button>
            <button
              onClick={() => setCurrentTab('menu')}
              className="hover:text-[#FF7A1A] transition-colors"
            >
              Menu
            </button>
            <button
              onClick={() => setCurrentTab('groups')}
              className="hover:text-[#FF7A1A] transition-colors"
            >
              Groups
            </button>
            <button
              onClick={() => setCurrentTab('tracking')}
              className="hover:text-[#FF7A1A] transition-colors"
            >
              Order Status
            </button>
          </div>

          <div className="text-[11px] text-[#202020]/40">
            Hostel Mess Closes 9:00 PM · Cafe Minimum ₹300 Rule Enforced
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
