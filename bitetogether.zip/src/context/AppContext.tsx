import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  Profile,
  GroupOrder,
  GroupParticipant,
  CartItem,
  Notification,
  OrderStatusHistory,
  OrderStatus,
  MenuItem
} from '../types';
import { GRAINS_AND_GOSSIP_MENU } from '../data/mockMenu';
import {
  DEMO_USERS,
  INITIAL_GROUPS,
  INITIAL_PARTICIPANTS,
  INITIAL_CART_ITEMS,
  INITIAL_NOTIFICATIONS,
  INITIAL_STATUS_HISTORY
} from '../data/initialData';

interface AppContextType {
  currentUser: Profile;
  allUsers: Profile[];
  switchUser: (userId: string) => void;
  registerStudent: (name: string, studentId: string, email: string, roomNumber: string) => Promise<boolean>;
  
  groups: GroupOrder[];
  activeGroupId: string | null;
  setActiveGroupId: (id: string | null) => void;
  activeGroup: GroupOrder | undefined;
  
  cartItems: CartItem[];
  activeGroupCartItems: CartItem[];
  userCartItems: CartItem[];
  participants: GroupParticipant[];
  activeGroupParticipants: GroupParticipant[];
  
  menuItems: MenuItem[];
  notifications: Notification[];
  statusHistory: OrderStatusHistory[];
  
  // Modals & Panels
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isCreateGroupOpen: boolean;
  setIsCreateGroupOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (open: boolean) => void;
  
  // Navigation
  currentTab: 'home' | 'groups' | 'menu' | 'tracking' | 'dashboard';
  setCurrentTab: (tab: 'home' | 'groups' | 'menu' | 'tracking' | 'dashboard') => void;
  
  // Group & Cart Operations
  createGroup: (name: string, deadlineMinutes: number, participantLimit?: number, pickupPoint?: string) => Promise<string | null>;
  joinGroup: (groupId: string) => Promise<{ success: boolean; message: string }>;
  addToCart: (menuItemId: string, quantity?: number, specialInstructions?: string) => Promise<{ success: boolean; message: string }>;
  updateCartItemQty: (itemId: string, quantity: number) => Promise<{ success: boolean; message: string }>;
  removeCartItem: (itemId: string) => Promise<{ success: boolean; message: string }>;
  
  // Checkout & Payment
  lockAndInitiateCheckout: () => Promise<{ success: boolean; message: string }>;
  submitPayment: (amount: number, method: 'upi' | 'qr' | 'razorpay_demo', ref?: string) => Promise<{ success: boolean; message: string }>;
  placeOrderWithCafe: () => Promise<{ success: boolean; message: string; token?: string }>;
  progressOrderStatus: (nextStatus: OrderStatus) => Promise<{ success: boolean; message: string }>;
  extendGroupDeadline: (additionalMinutes?: number) => Promise<boolean>;
  
  // Notifications
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  unreadNotificationsCount: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Demo current user starts as Rohan Verma (Room 314)
  const [allUsers, setAllUsers] = useState<Profile[]>(() => {
    const saved = localStorage.getItem('bt_users');
    return saved ? JSON.parse(saved) : DEMO_USERS;
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const saved = localStorage.getItem('bt_current_user_id');
    return saved || DEMO_USERS[0].id;
  });

  const currentUser = useMemo(() => {
    return allUsers.find(u => u.id === currentUserId) || allUsers[0];
  }, [allUsers, currentUserId]);

  const [groups, setGroups] = useState<GroupOrder[]>(() => {
    const saved = localStorage.getItem('bt_groups');
    return saved ? JSON.parse(saved) : INITIAL_GROUPS;
  });

  const [activeGroupId, setActiveGroupId] = useState<string | null>(() => {
    return 'g-active-1'; // Default to Floor 3 Munchies order
  });

  const [participants, setParticipants] = useState<GroupParticipant[]>(() => {
    const saved = localStorage.getItem('bt_participants');
    return saved ? JSON.parse(saved) : INITIAL_PARTICIPANTS;
  });

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('bt_cart');
    return saved ? JSON.parse(saved) : INITIAL_CART_ITEMS;
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('bt_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [statusHistory, setStatusHistory] = useState<OrderStatusHistory[]>(() => {
    const saved = localStorage.getItem('bt_history');
    return saved ? JSON.parse(saved) : INITIAL_STATUS_HISTORY;
  });

  const [menuItems] = useState<MenuItem[]>(GRAINS_AND_GOSSIP_MENU);

  // UI state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState<'home' | 'groups' | 'menu' | 'tracking' | 'dashboard'>('home');

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('bt_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem('bt_current_user_id', currentUserId);
  }, [currentUserId]);

  useEffect(() => {
    localStorage.setItem('bt_groups', JSON.stringify(groups));
  }, [groups]);

  useEffect(() => {
    localStorage.setItem('bt_participants', JSON.stringify(participants));
  }, [participants]);

  useEffect(() => {
    localStorage.setItem('bt_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  useEffect(() => {
    localStorage.setItem('bt_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('bt_history', JSON.stringify(statusHistory));
  }, [statusHistory]);

  // Active Group Computed State
  const activeGroup = useMemo(() => {
    return groups.find(g => g.id === activeGroupId);
  }, [groups, activeGroupId]);

  const activeGroupCartItems = useMemo(() => {
    if (!activeGroupId) return [];
    return cartItems.filter(item => item.groupId === activeGroupId);
  }, [cartItems, activeGroupId]);

  const userCartItems = useMemo(() => {
    if (!activeGroupId) return [];
    return cartItems.filter(item => item.groupId === activeGroupId && item.userId === currentUser.id);
  }, [cartItems, activeGroupId, currentUser.id]);

  const activeGroupParticipants = useMemo(() => {
    if (!activeGroupId) return [];
    return participants.filter(p => p.groupId === activeGroupId);
  }, [participants, activeGroupId]);

  // Recalculate totals whenever cart changes
  const refreshTotals = useCallback((groupId: string) => {
    setGroups(prevGroups => {
      return prevGroups.map(group => {
        if (group.id !== groupId) return group;
        const items = cartItems.filter(i => i.groupId === groupId);
        const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
        let status = group.status;
        if (status === 'collecting' && total >= group.minThreshold) {
          status = 'threshold_met';
        } else if (status === 'threshold_met' && total < group.minThreshold) {
          status = 'collecting';
        }
        return {
          ...group,
          totalAmount: total,
          status
        };
      });
    });

    setParticipants(prevParticipants => {
      return prevParticipants.map(part => {
        if (part.groupId !== groupId) return part;
        const pItems = cartItems.filter(i => i.groupId === groupId && i.userId === part.userId);
        const subtotal = pItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
        return {
          ...part,
          totalIndividualAmount: subtotal
        };
      });
    });
  }, [cartItems]);

  // Try fetching from server on mount
  useEffect(() => {
    async function loadServerState() {
      try {
        const res = await fetch('/api/groups');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            setGroups(data);
          }
        }
      } catch {
        // Fallback to local state is already active
      }
    }
    loadServerState();
  }, []);

  // Switch User
  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
  };

  // Register new Tower 3 student
  const registerStudent = async (name: string, studentId: string, email: string, roomNumber: string): Promise<boolean> => {
    const newUser: Profile = {
      id: `u-${Date.now()}`,
      name,
      studentId,
      email,
      hostelTower: 'Tower 3',
      roomNumber,
      createdAt: new Date().toISOString()
    };

    setAllUsers(prev => [...prev, newUser]);
    setCurrentUserId(newUser.id);

    try {
      await fetch('/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, studentId, email, roomNumber })
      });
    } catch {
      // Offline fallback
    }

    return true;
  };

  // Create Group
  const createGroup = async (
    name: string,
    deadlineMinutes: number,
    participantLimit?: number,
    pickupPoint?: string
  ): Promise<string | null> => {
    const newGroup: GroupOrder = {
      id: `g-${Date.now()}`,
      code: `T3-${Math.floor(1000 + Math.random() * 9000)}`,
      name: name || `${currentUser.name}'s Late-Night Order`,
      cafeName: 'Grains and Gossip',
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      creatorRoom: currentUser.roomNumber,
      deadline: new Date(Date.now() + deadlineMinutes * 60 * 1000).toISOString(),
      participantLimit: participantLimit || 6,
      status: 'collecting',
      minThreshold: 300,
      totalAmount: 0,
      pickupPoint: pickupPoint || `Tower 3 Room ${currentUser.roomNumber} / Security Desk`,
      createdAt: new Date().toISOString(),
      estimatedDeliveryMins: 25
    };

    const creatorPart: GroupParticipant = {
      id: `p-${Date.now()}`,
      groupId: newGroup.id,
      userId: currentUser.id,
      userName: currentUser.name,
      roomNumber: currentUser.roomNumber,
      joinedAt: new Date().toISOString(),
      paymentStatus: 'pending',
      totalIndividualAmount: 0
    };

    const newHistory: OrderStatusHistory = {
      id: `sh-${Date.now()}`,
      groupId: newGroup.id,
      status: 'collecting',
      note: `Group created by ${currentUser.name} (Room ${currentUser.roomNumber}). Deadline: ${deadlineMinutes} minutes.`,
      timestamp: new Date().toISOString()
    };

    setGroups(prev => [newGroup, ...prev]);
    setParticipants(prev => [...prev, creatorPart]);
    setStatusHistory(prev => [...prev, newHistory]);
    setActiveGroupId(newGroup.id);

    // Call server
    try {
      await fetch('/api/groups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newGroup.name,
          creatorId: currentUser.id,
          deadlineMinutes,
          participantLimit,
          pickupPoint: newGroup.pickupPoint
        })
      });
    } catch {
      // Local state is already updated
    }

    return newGroup.id;
  };

  // Join Group
  const joinGroup = async (groupId: string): Promise<{ success: boolean; message: string }> => {
    const targetGroup = groups.find(g => g.id === groupId);
    if (!targetGroup) return { success: false, message: 'Group not found' };

    if (targetGroup.status !== 'collecting' && targetGroup.status !== 'threshold_met') {
      return { success: false, message: 'This group is locked for checkout and cannot accept new members.' };
    }

    const existing = participants.find(p => p.groupId === groupId && p.userId === currentUser.id);
    if (existing) {
      setActiveGroupId(groupId);
      return { success: true, message: `You are already part of "${targetGroup.name}"` };
    }

    const currentCount = participants.filter(p => p.groupId === groupId).length;
    if (targetGroup.participantLimit && currentCount >= targetGroup.participantLimit) {
      return { success: false, message: `Group has reached maximum limit of ${targetGroup.participantLimit} students.` };
    }

    const newPart: GroupParticipant = {
      id: `p-${Date.now()}`,
      groupId: targetGroup.id,
      userId: currentUser.id,
      userName: currentUser.name,
      roomNumber: currentUser.roomNumber,
      joinedAt: new Date().toISOString(),
      paymentStatus: 'pending',
      totalIndividualAmount: 0
    };

    setParticipants(prev => [...prev, newPart]);
    setActiveGroupId(groupId);

    // Notify creator
    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        userId: targetGroup.creatorId,
        groupId: targetGroup.id,
        title: 'New roommate joined!',
        message: `${currentUser.name} (Room ${currentUser.roomNumber}) joined your group order.`,
        type: 'group_joined',
        isRead: false,
        createdAt: new Date().toISOString()
      },
      ...prev
    ]);

    try {
      await fetch(`/api/groups/${groupId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id })
      });
    } catch {
      // Local state is set
    }

    return { success: true, message: `Joined "${targetGroup.name}"!` };
  };

  // Add Item to Shared Cart
  const addToCart = async (
    menuItemId: string,
    quantity: number = 1,
    specialInstructions?: string
  ): Promise<{ success: boolean; message: string }> => {
    if (!activeGroupId) {
      return { success: false, message: 'Please select or join a group order first.' };
    }

    const group = groups.find(g => g.id === activeGroupId);
    if (!group) return { success: false, message: 'Group not found' };

    // Freeze Check
    if (group.status !== 'collecting' && group.status !== 'threshold_met') {
      return { success: false, message: 'Cart is frozen during checkout. No modifications allowed.' };
    }

    const menuItem = menuItems.find(m => m.id === menuItemId);
    if (!menuItem) return { success: false, message: 'Item not found in Grains & Gossip menu' };

    // Ensure user is in participant list
    const isParticipant = participants.some(p => p.groupId === activeGroupId && p.userId === currentUser.id);
    if (!isParticipant) {
      const newPart: GroupParticipant = {
        id: `p-${Date.now()}`,
        groupId: activeGroupId,
        userId: currentUser.id,
        userName: currentUser.name,
        roomNumber: currentUser.roomNumber,
        joinedAt: new Date().toISOString(),
        paymentStatus: 'pending',
        totalIndividualAmount: 0
      };
      setParticipants(prev => [...prev, newPart]);
    }

    // Check if item already exists for this user
    setCartItems(prev => {
      const existing = prev.find(
        i => i.groupId === activeGroupId && i.userId === currentUser.id && i.menuItemId === menuItemId
      );

      let updated: CartItem[];
      if (existing) {
        updated = prev.map(i =>
          i.id === existing.id
            ? { ...i, quantity: i.quantity + quantity, specialInstructions: specialInstructions || i.specialInstructions }
            : i
        );
      } else {
        const newItem: CartItem = {
          id: `ci-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          groupId: activeGroupId,
          userId: currentUser.id,
          userName: currentUser.name,
          roomNumber: currentUser.roomNumber,
          menuItemId,
          itemName: menuItem.name,
          price: menuItem.price,
          quantity,
          specialInstructions,
          addedAt: new Date().toISOString()
        };
        updated = [...prev, newItem];
      }

      // Calculate new group total
      const groupItems = updated.filter(i => i.groupId === activeGroupId);
      const newTotal = groupItems.reduce((sum, i) => sum + i.price * i.quantity, 0);

      // Check if threshold reached
      setGroups(gList =>
        gList.map(g => {
          if (g.id !== activeGroupId) return g;
          const status = newTotal >= g.minThreshold ? 'threshold_met' : 'collecting';
          return { ...g, totalAmount: newTotal, status };
        })
      );

      // Update participant individual totals
      setParticipants(pList =>
        pList.map(p => {
          if (p.groupId !== activeGroupId) return p;
          const pSub = groupItems
            .filter(i => i.userId === p.userId)
            .reduce((s, i) => s + i.price * i.quantity, 0);
          return { ...p, totalIndividualAmount: pSub };
        })
      );

      return updated;
    });

    // Server call
    try {
      await fetch(`/api/groups/${activeGroupId}/cart`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          menuItemId,
          quantity,
          specialInstructions
        })
      });
    } catch {
      // Local handled
    }

    return { success: true, message: `Added ${quantity}x ${menuItem.name} to shared cart` };
  };

  // Update Item Quantity (Server validates ownership)
  const updateCartItemQty = async (itemId: string, quantity: number): Promise<{ success: boolean; message: string }> => {
    const item = cartItems.find(i => i.id === itemId);
    if (!item) return { success: false, message: 'Item not found' };

    // Business rule: Student can edit ONLY their own items
    if (item.userId !== currentUser.id) {
      return { success: false, message: 'Authorization error: You cannot edit food items added by another student.' };
    }

    const group = groups.find(g => g.id === item.groupId);
    if (group && group.status !== 'collecting' && group.status !== 'threshold_met') {
      return { success: false, message: 'Cart is frozen during checkout.' };
    }

    setCartItems(prev => {
      let updated: CartItem[];
      if (quantity <= 0) {
        updated = prev.filter(i => i.id !== itemId);
      } else {
        updated = prev.map(i => (i.id === itemId ? { ...i, quantity } : i));
      }

      // Re-evaluate group total
      const groupItems = updated.filter(i => i.groupId === item.groupId);
      const newTotal = groupItems.reduce((sum, i) => sum + i.price * i.quantity, 0);

      setGroups(gList =>
        gList.map(g => {
          if (g.id !== item.groupId) return g;
          const status = newTotal >= g.minThreshold ? 'threshold_met' : 'collecting';
          return { ...g, totalAmount: newTotal, status };
        })
      );

      setParticipants(pList =>
        pList.map(p => {
          if (p.groupId !== item.groupId) return p;
          const pSub = groupItems
            .filter(i => i.userId === p.userId)
            .reduce((s, i) => s + i.price * i.quantity, 0);
          return { ...p, totalIndividualAmount: pSub };
        })
      );

      return updated;
    });

    try {
      await fetch(`/api/groups/${item.groupId}/cart/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, quantity })
      });
    } catch {
      // Handled
    }

    return { success: true, message: 'Cart updated' };
  };

  // Remove Cart Item
  const removeCartItem = async (itemId: string): Promise<{ success: boolean; message: string }> => {
    const item = cartItems.find(i => i.id === itemId);
    if (!item) return { success: false, message: 'Item not found' };

    if (item.userId !== currentUser.id) {
      return { success: false, message: 'Authorization error: You cannot remove another student\'s food item.' };
    }

    return updateCartItemQty(itemId, 0);
  };

  // Lock & Initiate Checkout (Enforcing ₹300 Rule with Client Cart Sync)
  const lockAndInitiateCheckout = async (): Promise<{ success: boolean; message: string }> => {
    if (!activeGroupId) return { success: false, message: 'No active group selected' };
    const group = groups.find(g => g.id === activeGroupId);
    if (!group) return { success: false, message: 'Group not found' };

    // If already locked or paid, proceed to checkout modal immediately
    if (group.status === 'checkout_locked' || group.status === 'paid' || group.status === 'placed') {
      setIsCheckoutOpen(true);
      return { success: true, message: 'Checkout is active!' };
    }

    const items = cartItems.filter(i => i.groupId === activeGroupId);
    const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);

    // SERVER & CLIENT VALIDATION: Must reach ₹300 minimum
    if (total < group.minThreshold) {
      const remaining = group.minThreshold - total;
      return {
        success: false,
        message: `Minimum order value ₹${group.minThreshold} not reached! You still need ₹${remaining} to unlock checkout.`
      };
    }

    // Freeze cart and update status locally
    setGroups(prev =>
      prev.map(g =>
        g.id === activeGroupId
          ? { ...g, status: 'checkout_locked', lockedAt: new Date().toISOString(), totalAmount: total }
          : g
      )
    );

    setStatusHistory(prev => [
      ...prev,
      {
        id: `sh-${Date.now()}`,
        groupId: activeGroupId,
        status: 'checkout_locked',
        note: `Checkout locked! Cart frozen at ₹${total}. Group members are now paying their individual shares.`,
        timestamp: new Date().toISOString()
      }
    ]);

    try {
      await fetch(`/api/groups/${activeGroupId}/lock-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cartItems: items, totalAmount: total })
      });
    } catch {
      // Local fallback active
    }

    setIsCheckoutOpen(true);
    return { success: true, message: 'Shared cart locked! Proceeding to individual payment.' };
  };

  // Extend Group Deadline (Allows more time during checkout)
  const extendGroupDeadline = async (additionalMinutes: number = 15): Promise<boolean> => {
    if (!activeGroupId) return false;
    const group = groups.find(g => g.id === activeGroupId);
    if (!group) return false;

    const currentDeadline = new Date(group.deadline).getTime();
    const baseTime = currentDeadline > Date.now() ? currentDeadline : Date.now();
    const newDeadline = new Date(baseTime + additionalMinutes * 60 * 1000).toISOString();

    setGroups(prev =>
      prev.map(g => (g.id === activeGroupId ? { ...g, deadline: newDeadline } : g))
    );

    try {
      await fetch(`/api/groups/${activeGroupId}/extend-deadline`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ additionalMinutes })
      });
    } catch {
      // Handled
    }
    return true;
  };

  // Submit Payment (Simulated verified gateway / UPI / QR)
  const submitPayment = async (
    amount: number,
    method: 'upi' | 'qr' | 'razorpay_demo',
    ref?: string
  ): Promise<{ success: boolean; message: string }> => {
    if (!activeGroupId) return { success: false, message: 'No active group' };

    const txnRef = ref || `TXN-UPI-${Date.now().toString().slice(-6)}`;

    // Mark current user as paid
    setParticipants(prev =>
      prev.map(p =>
        p.groupId === activeGroupId && p.userId === currentUser.id
          ? { ...p, paymentStatus: 'paid' }
          : p
      )
    );

    // Add status history
    setStatusHistory(prev => [
      ...prev,
      {
        id: `sh-${Date.now()}`,
        groupId: activeGroupId,
        status: 'checkout_locked',
        note: `${currentUser.name} (Room ${currentUser.roomNumber}) paid ₹${amount} via ${method.toUpperCase()} (${txnRef}).`,
        timestamp: new Date().toISOString()
      }
    ]);

    // Check if everyone is paid
    const currentGroupParts = participants.filter(
      p => p.groupId === activeGroupId && (p.userId === currentUser.id ? true : p.totalIndividualAmount > 0)
    );
    const otherUnpaid = currentGroupParts.filter(p => p.userId !== currentUser.id && p.paymentStatus !== 'paid');

    if (otherUnpaid.length === 0) {
      setGroups(prev =>
        prev.map(g => (g.id === activeGroupId ? { ...g, status: 'paid' } : g))
      );
    }

    try {
      await fetch(`/api/groups/${activeGroupId}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          amount,
          paymentMethod: method,
          transactionRef: txnRef
        })
      });
    } catch {
      // Fallback works
    }

    return { success: true, message: `Payment of ₹${amount} confirmed! Reference: ${txnRef}` };
  };

  // Place Cafe Order with Grains and Gossip
  const placeOrderWithCafe = async (): Promise<{ success: boolean; message: string; token?: string }> => {
    if (!activeGroupId) return { success: false, message: 'No group' };

    const token = `GG-${Math.floor(1000 + Math.random() * 9000)}`;

    setGroups(prev =>
      prev.map(g =>
        g.id === activeGroupId
          ? { ...g, status: 'placed', cafeTokenNumber: token }
          : g
      )
    );

    setStatusHistory(prev => [
      ...prev,
      {
        id: `sh-${Date.now()}`,
        groupId: activeGroupId,
        status: 'placed',
        note: `Order sent to Grains and Gossip! Cafe Token: #${token}. Preparing in 25 mins.`,
        timestamp: new Date().toISOString()
      }
    ]);

    // Add notification
    setNotifications(prev => [
      {
        id: `notif-${Date.now()}`,
        userId: currentUser.id,
        groupId: activeGroupId,
        title: 'Order Placed with Cafe!',
        message: `Grains & Gossip received your order. Pickup Token: #${token}`,
        type: 'order_placed',
        isRead: false,
        createdAt: new Date().toISOString()
      },
      ...prev
    ]);

    try {
      await fetch(`/api/groups/${activeGroupId}/place-order`, { method: 'POST' });
    } catch {
      // Handled
    }

    return { success: true, message: 'Order submitted to Grains & Gossip!', token };
  };

  // Progress Order Status (Tracking simulation)
  const progressOrderStatus = async (nextStatus: OrderStatus): Promise<{ success: boolean; message: string }> => {
    if (!activeGroupId) return { success: false, message: 'No group' };

    const notes: Record<string, string> = {
      preparing: 'Grains & Gossip kitchen is now grilling & preparing your food.',
      ready_pickup: 'Food has arrived at Tower 3 Ground Security Desk! Come collect.',
      completed: 'All items picked up by roommates. Enjoy your late-night meal!'
    };

    setGroups(prev =>
      prev.map(g => (g.id === activeGroupId ? { ...g, status: nextStatus } : g))
    );

    setStatusHistory(prev => [
      ...prev,
      {
        id: `sh-${Date.now()}`,
        groupId: activeGroupId,
        status: nextStatus,
        note: notes[nextStatus] || `Status updated to ${nextStatus}`,
        timestamp: new Date().toISOString()
      }
    ]);

    try {
      await fetch(`/api/groups/${activeGroupId}/progress-status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nextStatus, note: notes[nextStatus] })
      });
    } catch {
      // Handled
    }

    return { success: true, message: `Status updated to ${nextStatus}` };
  };

  // Notification methods
  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, isRead: true } : n)));
    try {
      fetch(`/api/notifications/${id}/read`, { method: 'POST' });
    } catch {
      // Handled
    }
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const unreadNotificationsCount = useMemo(() => {
    return notifications.filter(n => n.userId === currentUser.id && !n.isRead).length;
  }, [notifications, currentUser.id]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        allUsers,
        switchUser,
        registerStudent,
        groups,
        activeGroupId,
        setActiveGroupId,
        activeGroup,
        cartItems,
        activeGroupCartItems,
        userCartItems,
        participants,
        activeGroupParticipants,
        menuItems,
        notifications,
        statusHistory,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isCreateGroupOpen,
        setIsCreateGroupOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isNotificationsOpen,
        setIsNotificationsOpen,
        currentTab,
        setCurrentTab,
        createGroup,
        joinGroup,
        addToCart,
        updateCartItemQty,
        removeCartItem,
        lockAndInitiateCheckout,
        submitPayment,
        placeOrderWithCafe,
        progressOrderStatus,
        extendGroupDeadline,
        markNotificationRead,
        markAllNotificationsRead,
        unreadNotificationsCount
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
