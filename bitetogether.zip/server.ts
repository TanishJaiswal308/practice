import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  Profile,
  GroupOrder,
  GroupParticipant,
  CartItem,
  Payment,
  Notification,
  OrderStatusHistory,
  MenuItem
} from './src/types';
import { GRAINS_AND_GOSSIP_MENU } from './src/data/mockMenu';
import {
  DEMO_USERS,
  INITIAL_GROUPS,
  INITIAL_PARTICIPANTS,
  INITIAL_CART_ITEMS,
  INITIAL_NOTIFICATIONS,
  INITIAL_STATUS_HISTORY
} from './src/data/initialData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database Store for Tower 3 BiteTogether
let users: Profile[] = [...DEMO_USERS];
let groups: GroupOrder[] = [...INITIAL_GROUPS];
let participants: GroupParticipant[] = [...INITIAL_PARTICIPANTS];
let cartItems: CartItem[] = [...INITIAL_CART_ITEMS];
let payments: Payment[] = [];
let notifications: Notification[] = [...INITIAL_NOTIFICATIONS];
let statusHistory: OrderStatusHistory[] = [...INITIAL_STATUS_HISTORY];
const menuItems: MenuItem[] = [...GRAINS_AND_GOSSIP_MENU];

// Helper to recalculate and validate group total
function recalculateGroupTotal(groupId: string): number {
  const items = cartItems.filter(item => item.groupId === groupId);
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const group = groups.find(g => g.id === groupId);
  if (group) {
    group.totalAmount = total;
    // Update participant totals
    participants.forEach(p => {
      if (p.groupId === groupId) {
        const pItems = items.filter(i => i.userId === p.userId);
        p.totalIndividualAmount = pItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
      }
    });

    // Auto-update status if still collecting/threshold
    if (group.status === 'collecting' && total >= group.minThreshold) {
      group.status = 'threshold_met';
      statusHistory.push({
        id: `sh-${Date.now()}`,
        groupId,
        status: 'threshold_met',
        note: `Threshold met! Cart reached ₹${total} (minimum ₹${group.minThreshold}). Checkout unlocked.`,
        timestamp: new Date().toISOString()
      });
      // Notify members
      const groupParts = participants.filter(p => p.groupId === groupId);
      groupParts.forEach(p => {
        notifications.unshift({
          id: `notif-${Date.now()}-${p.userId}`,
          userId: p.userId,
          groupId,
          title: '🎉 ₹300 Threshold Reached!',
          message: `The group cart reached ₹${total}! Checkout is now unlocked.`,
          type: 'threshold_reached',
          isRead: false,
          createdAt: new Date().toISOString()
        });
      });
    } else if (group.status === 'threshold_met' && total < group.minThreshold) {
      group.status = 'collecting';
    }
  }

  return total;
}

// -----------------------------------------------------------------------------
// API ROUTES
// -----------------------------------------------------------------------------

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'BiteTogether Tower 3 Server', time: new Date().toISOString() });
});

// Menu
app.get('/api/menu', (_req: Request, res: Response) => {
  res.json({ cafe: 'Grains and Gossip', items: menuItems });
});

// Users
app.get('/api/users', (_req: Request, res: Response) => {
  res.json(users);
});

app.post('/api/users/register', (req: Request, res: Response) => {
  const { name, studentId, email, roomNumber } = req.body;
  if (!name || !studentId || !email || !roomNumber) {
    res.status(400).json({ error: 'Missing required fields for Tower 3 student registration' });
    return;
  }
  const newUser: Profile = {
    id: `u-${Date.now()}`,
    name,
    studentId,
    email,
    hostelTower: 'Tower 3',
    roomNumber: roomNumber.toString(),
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  res.status(201).json(newUser);
});

// Groups List
app.get('/api/groups', (_req: Request, res: Response) => {
  // Enrich with participant count & current total
  const enriched = groups.map(g => {
    recalculateGroupTotal(g.id);
    const count = participants.filter(p => p.groupId === g.id).length;
    return {
      ...g,
      participantCount: count
    };
  });
  res.json(enriched);
});

// Group Details
app.get('/api/groups/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const group = groups.find(g => g.id === id || g.code.toLowerCase() === id.toLowerCase());
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  recalculateGroupTotal(group.id);
  const groupParticipants = participants.filter(p => p.groupId === group.id);
  const groupCart = cartItems.filter(ci => ci.groupId === group.id);
  const groupPayments = payments.filter(pm => pm.groupId === group.id);
  const history = statusHistory.filter(sh => sh.groupId === group.id);

  res.json({
    group,
    participants: groupParticipants,
    cartItems: groupCart,
    payments: groupPayments,
    history
  });
});

// Create Group
app.post('/api/groups', (req: Request, res: Response) => {
  const { name, creatorId, deadlineMinutes = 30, participantLimit = 6, pickupPoint } = req.body;

  const creator = users.find(u => u.id === creatorId);
  if (!creator) {
    res.status(400).json({ error: 'Valid Tower 3 student profile required to create a group' });
    return;
  }

  const code = `T3-${Math.floor(1000 + Math.random() * 9000)}`;
  const newGroup: GroupOrder = {
    id: `g-${Date.now()}`,
    code,
    name: name || `${creator.name}'s Late-Night Order`,
    cafeName: 'Grains and Gossip', // Business rule: cafe fixed to Grains and Gossip
    creatorId: creator.id,
    creatorName: creator.name,
    creatorRoom: creator.roomNumber,
    deadline: new Date(Date.now() + deadlineMinutes * 60 * 1000).toISOString(),
    participantLimit: Number(participantLimit) || 6,
    status: 'collecting',
    minThreshold: 300, // Business rule: ₹300 fixed
    totalAmount: 0,
    pickupPoint: pickupPoint || `Tower 3 Room ${creator.roomNumber} or Security Desk`,
    createdAt: new Date().toISOString(),
    estimatedDeliveryMins: 25
  };

  groups.unshift(newGroup);

  // Add creator as first participant
  const creatorPart: GroupParticipant = {
    id: `p-${Date.now()}`,
    groupId: newGroup.id,
    userId: creator.id,
    userName: creator.name,
    roomNumber: creator.roomNumber,
    joinedAt: new Date().toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 0
  };
  participants.push(creatorPart);

  statusHistory.push({
    id: `sh-${Date.now()}`,
    groupId: newGroup.id,
    status: 'collecting',
    note: `Group created by ${creator.name} (Room ${creator.roomNumber}). Deadline: ${deadlineMinutes} minutes.`,
    timestamp: new Date().toISOString()
  });

  res.status(201).json(newGroup);
});

// Join Group
app.post('/api/groups/:id/join', (req: Request, res: Response) => {
  const { id } = req.params;
  const { userId } = req.body;

  const group = groups.find(g => g.id === id || g.code.toLowerCase() === id.toLowerCase());
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  if (group.status !== 'collecting' && group.status !== 'threshold_met') {
    res.status(400).json({ error: 'This group is locked for checkout and cannot accept new members' });
    return;
  }

  const user = users.find(u => u.id === userId);
  if (!user) {
    res.status(400).json({ error: 'Invalid student profile' });
    return;
  }

  // Prevent duplicate participation
  const existing = participants.find(p => p.groupId === group.id && p.userId === user.id);
  if (existing) {
    res.json({ message: 'Already a participant in this group', participant: existing });
    return;
  }

  // Check limit
  const currentCount = participants.filter(p => p.groupId === group.id).length;
  if (group.participantLimit && currentCount >= group.participantLimit) {
    res.status(400).json({ error: `Group order reached maximum limit of ${group.participantLimit} students` });
    return;
  }

  const newPart: GroupParticipant = {
    id: `p-${Date.now()}`,
    groupId: group.id,
    userId: user.id,
    userName: user.name,
    roomNumber: user.roomNumber,
    joinedAt: new Date().toISOString(),
    paymentStatus: 'pending',
    totalIndividualAmount: 0
  };
  participants.push(newPart);

  // Notify creator
  notifications.unshift({
    id: `notif-${Date.now()}`,
    userId: group.creatorId,
    groupId: group.id,
    title: 'New roommate joined!',
    message: `${user.name} (Room ${user.roomNumber}) joined your group order "${group.name}".`,
    type: 'group_joined',
    isRead: false,
    createdAt: new Date().toISOString()
  });

  res.status(201).json(newPart);
});

// Add Item to Shared Cart
app.post('/api/groups/:id/cart', (req: Request, res: Response) => {
  const { id } = req.params;
  const { userId, menuItemId, quantity = 1, specialInstructions } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  // Business Rule: Freeze cart during checkout
  if (group.status !== 'collecting' && group.status !== 'threshold_met') {
    res.status(403).json({ error: 'Cart is frozen for checkout and payments. No modifications allowed.' });
    return;
  }

  const user = users.find(u => u.id === userId);
  if (!user) {
    res.status(400).json({ error: 'User not found' });
    return;
  }

  // Ensure user is in group
  let participant = participants.find(p => p.groupId === group.id && p.userId === user.id);
  if (!participant) {
    participant = {
      id: `p-${Date.now()}`,
      groupId: group.id,
      userId: user.id,
      userName: user.name,
      roomNumber: user.roomNumber,
      joinedAt: new Date().toISOString(),
      paymentStatus: 'pending',
      totalIndividualAmount: 0
    };
    participants.push(participant);
  }

  const menuItem = menuItems.find(m => m.id === menuItemId);
  if (!menuItem) {
    res.status(400).json({ error: 'Menu item not found' });
    return;
  }

  // Check if user already has this item in cart
  const existingCartItem = cartItems.find(
    ci => ci.groupId === group.id && ci.userId === user.id && ci.menuItemId === menuItem.id
  );

  if (existingCartItem) {
    existingCartItem.quantity += Number(quantity);
    if (specialInstructions) existingCartItem.specialInstructions = specialInstructions;
  } else {
    const newCartItem: CartItem = {
      id: `ci-${Date.now()}`,
      groupId: group.id,
      userId: user.id,
      userName: user.name,
      roomNumber: user.roomNumber,
      menuItemId: menuItem.id,
      itemName: menuItem.name,
      price: menuItem.price,
      quantity: Number(quantity),
      specialInstructions: specialInstructions || undefined,
      addedAt: new Date().toISOString()
    };
    cartItems.push(newCartItem);
  }

  const newTotal = recalculateGroupTotal(group.id);

  // Notify other group members
  const others = participants.filter(p => p.groupId === group.id && p.userId !== user.id);
  others.forEach(p => {
    notifications.unshift({
      id: `notif-${Date.now()}-${p.userId}`,
      userId: p.userId,
      groupId: group.id,
      title: 'Item added to group cart',
      message: `${user.name} added ${menuItem.name}. Current total: ₹${newTotal}/₹300.`,
      type: 'food_added',
      isRead: false,
      createdAt: new Date().toISOString()
    });
  });

  res.status(200).json({
    cartItems: cartItems.filter(ci => ci.groupId === group.id),
    totalAmount: newTotal,
    status: group.status
  });
});

// Update Item Quantity (Server validates ownership!)
app.patch('/api/groups/:id/cart/:itemId', (req: Request, res: Response) => {
  const { id, itemId } = req.params;
  const { userId, quantity } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  // Freeze check
  if (group.status !== 'collecting' && group.status !== 'threshold_met') {
    res.status(403).json({ error: 'Cart is frozen during checkout. Cannot modify quantities.' });
    return;
  }

  const item = cartItems.find(ci => ci.id === itemId && ci.groupId === id);
  if (!item) {
    res.status(404).json({ error: 'Cart item not found' });
    return;
  }

  // Business Rule: Student can edit ONLY their own items
  if (item.userId !== userId) {
    res.status(403).json({ error: 'Authorization error: You cannot edit items ordered by another student.' });
    return;
  }

  const newQty = Number(quantity);
  if (newQty <= 0) {
    cartItems = cartItems.filter(ci => ci.id !== itemId);
  } else {
    item.quantity = newQty;
  }

  const newTotal = recalculateGroupTotal(group.id);
  res.json({
    cartItems: cartItems.filter(ci => ci.groupId === group.id),
    totalAmount: newTotal,
    status: group.status
  });
});

// Remove Item from Cart (Server validates ownership!)
app.delete('/api/groups/:id/cart/:itemId', (req: Request, res: Response) => {
  const { id, itemId } = req.params;
  const { userId } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  // Freeze check
  if (group.status !== 'collecting' && group.status !== 'threshold_met') {
    res.status(403).json({ error: 'Cart is frozen during checkout.' });
    return;
  }

  const item = cartItems.find(ci => ci.id === itemId && ci.groupId === id);
  if (!item) {
    res.status(404).json({ error: 'Cart item not found' });
    return;
  }

  // Business Rule: Student can remove ONLY their own items
  if (item.userId !== userId) {
    res.status(403).json({ error: 'Authorization error: You cannot remove another student\'s food item.' });
    return;
  }

  cartItems = cartItems.filter(ci => ci.id !== itemId);
  const newTotal = recalculateGroupTotal(group.id);

  res.json({
    cartItems: cartItems.filter(ci => ci.groupId === group.id),
    totalAmount: newTotal,
    status: group.status
  });
});

// Lock Cart & Initiate Checkout (Enforces Server-Side ₹300 Rule with Client Cart Sync!)
app.post('/api/groups/:id/lock-checkout', (req: Request, res: Response) => {
  const { id } = req.params;
  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  // If already locked or paid, return success directly
  if (group.status === 'checkout_locked' || group.status === 'paid' || group.status === 'placed') {
    res.json({
      group,
      totalAmount: group.totalAmount,
      status: group.status,
      message: 'Checkout is active for this group.'
    });
    return;
  }

  // Sync client cart items if provided
  if (Array.isArray(req.body?.cartItems) && req.body.cartItems.length > 0) {
    cartItems = cartItems.filter(ci => ci.groupId !== group.id).concat(req.body.cartItems);
  }

  const total = recalculateGroupTotal(group.id);
  const effectiveTotal = Math.max(total, Number(req.body?.totalAmount) || 0);

  // CRITICAL SERVER-SIDE VALIDATION: Must reach ₹300 minimum
  if (effectiveTotal < group.minThreshold) {
    res.status(400).json({
      error: `Minimum cart value of ₹${group.minThreshold} not reached. Current total is only ₹${effectiveTotal}. Remaining: ₹${group.minThreshold - effectiveTotal}.`
    });
    return;
  }

  group.totalAmount = effectiveTotal;
  // Freeze cart and move to checkout
  group.status = 'checkout_locked';
  group.lockedAt = new Date().toISOString();

  statusHistory.push({
    id: `sh-${Date.now()}`,
    groupId: group.id,
    status: 'checkout_locked',
    note: `Cart frozen at ₹${effectiveTotal} by host. Individual payments initiated for all members.`,
    timestamp: new Date().toISOString()
  });

  // Notify all participants with individual amounts
  const groupParts = participants.filter(p => p.groupId === group.id);
  groupParts.forEach(p => {
    notifications.unshift({
      id: `notif-${Date.now()}-${p.userId}`,
      userId: p.userId,
      groupId: group.id,
      title: 'Action required: Complete your payment',
      message: `Checkout has started for "${group.name}". Your share is ₹${p.totalIndividualAmount}. Please pay via UPI/QR.`,
      type: 'payment_pending',
      isRead: false,
      createdAt: new Date().toISOString()
    });
  });

  res.json({
    group,
    totalAmount: effectiveTotal,
    status: group.status,
    message: 'Cart locked. Proceeding to individual payment breakdown.'
  });
});

// Extend Group Deadline (When students need more time during checkout)
app.post('/api/groups/:id/extend-deadline', (req: Request, res: Response) => {
  const { id } = req.params;
  const { additionalMinutes = 15 } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  const currentDeadline = new Date(group.deadline).getTime();
  const baseTime = currentDeadline > Date.now() ? currentDeadline : Date.now();
  const newDeadline = new Date(baseTime + additionalMinutes * 60 * 1000).toISOString();
  group.deadline = newDeadline;

  statusHistory.push({
    id: `sh-${Date.now()}`,
    groupId: group.id,
    status: group.status,
    note: `Checkout deadline extended by ${additionalMinutes} minutes. New deadline: ${new Date(newDeadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
    timestamp: new Date().toISOString()
  });

  res.json({
    group,
    newDeadline,
    message: `Deadline extended by ${additionalMinutes} minutes.`
  });
});

// Process Individual Payment (Never blind success on single click)
app.post('/api/groups/:id/pay', (req: Request, res: Response) => {
  const { id } = req.params;
  const { userId, amount, paymentMethod = 'upi', transactionRef } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  let participant = participants.find(p => p.groupId === group.id && p.userId === userId);
  if (!participant) {
    const user = users.find(u => u.id === userId);
    participant = {
      id: `p-${Date.now()}`,
      groupId: group.id,
      userId,
      userName: user ? user.name : 'Tower 3 Student',
      roomNumber: user ? user.roomNumber : '314',
      joinedAt: new Date().toISOString(),
      paymentStatus: 'pending',
      totalIndividualAmount: Number(amount) || 0
    };
    participants.push(participant);
  }

  const payAmount = Number(amount) || 0;
  participant.totalIndividualAmount = Math.max(participant.totalIndividualAmount, payAmount);

  const ref = transactionRef || `UPI-TXN-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

  const paymentRecord: Payment = {
    id: `pay-${Date.now()}`,
    groupId: group.id,
    userId,
    userName: participant.userName,
    amount: payAmount,
    paymentMethod,
    status: 'paid',
    transactionRef: ref,
    paidAt: new Date().toISOString()
  };

  payments.push(paymentRecord);
  participant.paymentStatus = 'paid';

  // Check if ALL participants with items have paid
  const groupParticipants = participants.filter(p => p.groupId === group.id && p.totalIndividualAmount > 0);
  const allPaid = groupParticipants.length === 0 || groupParticipants.every(p => p.paymentStatus === 'paid');

  if (allPaid) {
    group.status = 'paid';
    statusHistory.push({
      id: `sh-${Date.now()}`,
      groupId: group.id,
      status: 'paid',
      note: 'All group participants have completed their individual payments. Ready to place order with Grains & Gossip.',
      timestamp: new Date().toISOString()
    });
  }

  res.json({
    payment: paymentRecord,
    participant,
    allPaid,
    groupStatus: group.status
  });
});

// Place Cafe Order with Grains and Gossip
app.post('/api/groups/:id/place-order', (req: Request, res: Response) => {
  const { id } = req.params;
  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  // Token for cafe pickup
  const token = `GG-${Math.floor(1000 + Math.random() * 9000)}`;
  group.cafeTokenNumber = token;
  group.status = 'placed';

  statusHistory.push({
    id: `sh-${Date.now()}`,
    groupId: group.id,
    status: 'placed',
    note: `Order successfully placed with Grains and Gossip! Cafe Token: #${token}. Food will be prepared shortly.`,
    timestamp: new Date().toISOString()
  });

  const groupParts = participants.filter(p => p.groupId === group.id);
  groupParts.forEach(p => {
    notifications.unshift({
      id: `notif-${Date.now()}-${p.userId}`,
      userId: p.userId,
      groupId: group.id,
      title: 'Order Placed with Grains & Gossip!',
      message: `Your group order is confirmed! Token #${token}. Estimated time: 25 mins.`,
      type: 'order_placed',
      isRead: false,
      createdAt: new Date().toISOString()
    });
  });

  res.json({
    group,
    token,
    status: group.status
  });
});

// Advance order status (For simulated live cafe tracking: placed -> preparing -> ready_pickup -> completed)
app.post('/api/groups/:id/progress-status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { nextStatus, note } = req.body;

  const group = groups.find(g => g.id === id);
  if (!group) {
    res.status(404).json({ error: 'Group order not found' });
    return;
  }

  group.status = nextStatus;

  const statusNotes: Record<string, string> = {
    preparing: 'Grains & Gossip cafe kitchen has started preparing your food items.',
    ready_pickup: `Food is ready and arrived at ${group.pickupPoint}. Tower 3 students can collect now!`,
    completed: 'Order marked fulfilled and received by roommates.'
  };

  const finalNote = note || statusNotes[nextStatus] || `Status updated to ${nextStatus}`;

  statusHistory.push({
    id: `sh-${Date.now()}`,
    groupId: group.id,
    status: nextStatus,
    note: finalNote,
    timestamp: new Date().toISOString()
  });

  // Notify members
  const groupParts = participants.filter(p => p.groupId === group.id);
  groupParts.forEach(p => {
    notifications.unshift({
      id: `notif-${Date.now()}-${p.userId}`,
      userId: p.userId,
      groupId: group.id,
      title: nextStatus === 'ready_pickup' ? '🍔 Food Ready for Pickup!' : `Order update: ${nextStatus}`,
      message: finalNote,
      type: nextStatus === 'ready_pickup' ? 'food_ready' : 'info',
      isRead: false,
      createdAt: new Date().toISOString()
    });
  });

  res.json({ group, status: group.status });
});

// Notifications
app.get('/api/notifications', (req: Request, res: Response) => {
  const { userId } = req.query;
  if (userId) {
    res.json(notifications.filter(n => n.userId === userId));
  } else {
    res.json(notifications);
  }
});

app.post('/api/notifications/:id/read', (req: Request, res: Response) => {
  const { id } = req.params;
  const notif = notifications.find(n => n.id === id);
  if (notif) notif.isRead = true;
  res.json({ success: true });
});

// -----------------------------------------------------------------------------
// VITE DEV SERVER INTEGRATION & LAUNCH
// -----------------------------------------------------------------------------

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> BiteTogether server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start BiteTogether server:', err);
  process.exit(1);
});
