<div align="center">

# BiteTogether

### *Don't order alone. Bite together.*

**Late-night group food ordering exclusively for Tower 3 hostel students — built to beat the ₹300 minimum cart limit at Grains & Gossip.**

[![Live Interactive Demo](https://img.shields.io/badge/🚀_Launch_Live_Interactive_Demo-FF7A1A?style=for-the-badge)](https://ais-pre-4grtzcgw7pz32fyi6y3x5a-105366210492.asia-northeast1.run.app)
[![Tower 3 Hostel Exclusive](https://img.shields.io/badge/Hostel-Tower_3_Exclusive-202020?style=for-the-badge)](#)
[![Grains & Gossip](https://img.shields.io/badge/Cafe-Grains_%26_Gossip-10B981?style=for-the-badge)](#)

<br />

<a href="https://ais-pre-4grtzcgw7pz32fyi6y3x5a-105366210492.asia-northeast1.run.app">
  <img src="src/assets/images/hero_cafe_spread_1793732218121.jpg" alt="BiteTogether - Grains and Gossip Late-Night Group Order Spread" width="100%" style="border-radius: 16px;" />
</a>

</div>

---

## 🌐 Live Interactive Demo

> **Note for GitHub Visitors:** GitHub's README viewer blocks inline `<iframe>` embeds for security, so click the interactive preview card below to launch the live full-stack application directly in your browser.

### 👉 [**Open Live Interactive BiteTogether App**](https://ais-pre-4grtzcgw7pz32fyi6y3x5a-105366210492.asia-northeast1.run.app)

### Interactive Walkthrough (Try These Flows Live!)
1. **Switch Between Tower 3 Roommates (Top Bar)**  
   Use the **Roommate Switcher** at the top of the app (`Rohan - Rm 314`, `Priya - Rm 302`, `Aryan - Rm 314`, `Tanvi - Rm 320`, `Kabir - Rm 308`) to simulate multiple hostel students collaborating in real time on the same shared cart.
2. **Browse All 58 Exact Grains & Gossip Menu Items**  
   Open **Grains & Gossip Menu**, filter by `Veg` / `Non-Veg` or `Under ₹100`, and click **View Scanned Menu Flyer** to compare every price directly with the official late-night hostel circular.
3. **Hit the ₹300 Threshold Together**  
   Add a ₹119 Paneer Tikka Sandwich or ₹29 Masala Tea into the shared group cart. Watch the progress meter unlock Checkout once combined roommate items cross **₹300**.
4. **Test Individual Checkout & Deadline Window**  
   Lock the shared cart, view your **strictly individual payable subtotal** (zero equal-split penalties), use the live countdown & `+15 Mins` window extension, complete simulated UPI/QR verification, and dispatch to the cafe.
5. **Track Live Preparation & Past Order Receipts**  
   Advance live cafe stages (`Collecting → Threshold Met → Cart Frozen → Paid → Placed → Preparing → Ready for Pickup → Completed`) in **Live Tracking**, and inspect itemized personal receipts in **Student Dashboard → Past Orders**.

---

## 💡 The Problem & Solution

- **The Problem:** The Tower 3 hostel mess closes at **9:00 PM**. Afterward, students rely on **Grains & Gossip** (9:30 PM – 3:00 AM), which requires a minimum cart value of **₹300 / ₹350**. A student who just wants a ₹69 plate of fries or ₹99 pasta is forced to over-order.
- **The BiteTogether Solution:** Tower 3 roommates start or join shared group orders using a short group code (e.g. `T3-MUNCH`), add their own snacks to one shared cart, unlock checkout automatically once the pooled total hits ₹300, and **pay strictly for their own items via UPI / QR**.

---

## ✨ Core Features

- **Tower 3 Exclusive Student Profiles & Demo Auth:** Sign in/register with student name, college ID, email, and Tower 3 room number.
- **Active Group Directory & Invite Codes:** Create groups with custom names, participant caps, pickup desks, and live countdown deadlines (`+15m` extension supported).
- **Exact Grains & Gossip Cafe Menu (58 Items):** Verbatim prices and sections including Rice/Noodles, Burgers, 8" Pizzas, Sandwiches, Fries & Nachos, Veg/Non-Veg Starters, Pasta, Fresh Juices/Shakes, and Hot Beverages—plus an in-app **Official Scanned Flyer Viewer**.
- **Owner-Protected Shared Cart:** Group cart breaks down items per roommate. Students can edit or delete **only their own items**, validated on both client and Express server.
- **Server-Validated ₹300 Rule & Cart Freezing:** Checkout remains locked below ₹300. Once unlocked and frozen (`checkout_locked`), cart modifications are blocked while roommates pay.
- **Individual UPI / QR / Razorpay-Ready Checkout:** Each student sees only their itemized food bill, pays individually, and tracks roommate payment statuses in real time.
- **7-Stage Live Order Tracker & Notifications:** Real-time notifications for joins, food additions, ₹300 threshold unlocked, pending payments, order placement (`#GG-XXXX` token), and pickup readiness.
- **Student Dashboard & Itemized Past Receipts:** View personal spending, late-night savings, active pools, and modal itemized receipts with 1-click reorder.

---

## 🧱 Tech Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend** | React 19, TypeScript, Vite 8, Tailwind CSS v4, Lucide Icons, Motion |
| **Backend API** | Node.js, Express 4 (`server.ts` serving Vite dev middlewares & REST API) |
| **Architecture Ready For** | Supabase Auth / PostgreSQL / Realtime + Razorpay Webhook Verification |

---

## 🚀 Run Locally

### Prerequisites
- Node.js 20+ (or Bun)

### Installation & Development Server
```bash
# 1. Install dependencies
npm install

# 2. Copy environment template (optional for local prototype)
cp .env.example .env

# 3. Start full-stack Express + Vite server on port 3000
npm run dev
```

Open **`http://localhost:3000`** in your browser.

### Production Build & Typecheck
```bash
# TypeScript typecheck
npm run lint

# Build production client bundle
npm run build
```

---

## 🔌 REST API Endpoints (`server.ts`)

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Server health check |
| `GET` | `/api/menu` | Official 58-item Grains & Gossip menu |
| `GET` | `/api/users` | Demo Tower 3 student profiles |
| `POST` | `/api/users/register` | Register a new Tower 3 student |
| `GET` | `/api/groups` | List active & past group orders with totals |
| `GET` | `/api/groups/:id` | Detailed group state, cart, payments & status history |
| `POST` | `/api/groups` | Create a new Tower 3 group order |
| `POST` | `/api/groups/:id/join` | Join an existing group (enforces limit & lock rules) |
| `POST` | `/api/groups/:id/cart` | Add item to shared cart |
| `PATCH` | `/api/groups/:id/cart/:itemId` | Update item quantity (owner-validated) |
| `DELETE` | `/api/groups/:id/cart/:itemId` | Remove item from cart (owner-validated) |
| `POST` | `/api/groups/:id/lock-checkout` | Enforce ₹300 threshold & freeze cart for payments |
| `POST` | `/api/groups/:id/extend-deadline` | Extend checkout deadline by 15 mins |
| `POST` | `/api/groups/:id/pay` | Record verified individual UPI/QR payment |
| `POST` | `/api/groups/:id/place-order` | Dispatch paid group order & generate `#GG-XXXX` token |
| `POST` | `/api/groups/:id/progress-status` | Advance live kitchen & delivery stages |
| `GET` | `/api/notifications` | Fetch notifications for a student |

---

## 📸 Visual Preview

<details>
<summary>Click to view Official Grains & Gossip Late-Night Menu Circular</summary>

<br />

<img src="public/assets/aistudio/WhatsApp_Image_2026-11-05_at_10.19.47_PM_f4b7063d.jpeg" alt="Official Grains and Gossips Late-Night Delivery Menu" width="520" />

</details>
